//
//  main.c
//  1-2
//
//  Created by 손명빈 on 2017. 8. 28..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>

int fact(int insert);

void main()
{
    int a,num;
    
    scanf("%d",&a);
    
    num = fact(a);
    
    printf("%d\n",num);
}

int fact(int insert)
{
    if(insert <= 1)
    {
        return 1;
    }
    
    else
    {
        return fact(insert-1) * insert;
        
    }
    
}
