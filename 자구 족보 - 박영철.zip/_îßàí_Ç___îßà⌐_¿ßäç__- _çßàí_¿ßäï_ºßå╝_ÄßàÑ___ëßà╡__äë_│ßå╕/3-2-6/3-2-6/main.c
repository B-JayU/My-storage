//
//  main.c
//  3-2-6
//
//  Created by 손명빈 on 2017. 9. 7..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>


typedef struct poly {
    int coef;
    int exp;
}Poly;

typedef struct node {
    Poly pdata;
    struct node* next;
}Node;
typedef Node* NodePointer;


NodePointer insertNode(NodePointer head, Poly data);

NodePointer readAndMakePoly();

void printPoly(NodePointer head);

NodePointer pmult(NodePointer ahead, NodePointer bhead);
NodePointer padd(NodePointer ahead, NodePointer bhead);

int main(void) {
    NodePointer ahead, bhead, addHead, multHead;
    
    printf("A 다항식을 입력하세요\n");
    ahead = readAndMakePoly();
    printf("B 다항식을 입력하세요\n");
    bhead = readAndMakePoly();
    
    printf("A 다항식: ");
    printPoly(ahead);
    printf("B 다항식: ");
    printPoly(bhead);
    
    addHead = padd(ahead, bhead);
    printf("덧셈결과 다항식: ");
    printPoly(addHead);
    
    multHead = pmult(ahead, bhead);
    printf("곱셈결과 다항식: ");
    printPoly(multHead);
    
    return 0;
}




int getExp(NodePointer node) {
    return node->pdata.exp;
}



int getCoef(NodePointer node) {
    return node->pdata.coef;
}


NodePointer readAndMakePoly() {
    NodePointer head = NULL;
    Poly pdata;
    
    scanf("%d %d", &pdata.coef, &pdata.exp);
    while (pdata.coef != -1 && pdata.exp != -1) {
        //-1 -1 을 입력하기 전까지 계속해서 입력받아서 poly만들기
        head = insertNode(head, pdata);
        
        scanf("%d %d", &pdata.coef, &pdata.exp);
    }
    
    return head;
}


void printPoly(NodePointer head) {
    NodePointer cur;
    
    for (cur = head; cur; cur = cur->next) {
        if (getExp(cur) != 0)
            printf("%dx^%d", getCoef(cur), getExp(cur));
        else
            printf("%d", getCoef(cur));
        if (cur->next)
            printf(" + ");
    }
    printf("\n");
}


NodePointer padd(NodePointer ahead, NodePointer bhead) {
    //linked list 형태를 가지고 있는 두 다항식을 더하는 함수
    NodePointer addHead = NULL;
    NodePointer acur, bcur;
    Poly addData;
    
    acur = ahead;
    bcur = bhead;
    
    while (acur && bcur) {
        if (getExp(acur) > getExp(bcur)) {
            addData.exp = getExp(acur);
            addData.coef = getCoef(acur);
            
            addHead = insertNode(addHead, addData);
            
            acur = acur->next;
        }
        else if (getExp(acur) == getExp(bcur)) {
            addData.exp = getExp(acur);
            addData.coef = getCoef(acur) + getCoef(bcur);
            
            addHead = insertNode(addHead, addData);
            
            acur = acur->next;
            bcur = bcur->next;
        }
        else {
            addData.exp = getExp(bcur);
            addData.coef = getCoef(bcur);
            
            addHead = insertNode(addHead, addData);
            
            bcur = bcur->next;
        }
    }
    
    //둘 중 하나가 덜 끝날을 수도 있음
    //a를 끝까지 확인해서 계산하도록 하기
    for (; acur; acur = acur->next) {
        addData.exp = getExp(acur);
        addData.coef = getCoef(acur);
        
        addHead = insertNode(addHead, addData);
    }
    
    //b를 끝까지 확인해서 계산하도록 하기
    for (; bcur; bcur = bcur->next) {
        addData.exp = getExp(bcur);
        addData.coef = getCoef(bcur);
        
        addHead = insertNode(addHead, addData);
    }
    
    return addHead;
}



NodePointer pmult(NodePointer ahead, NodePointer bhead) {
    //linked list 형태를 가지고 있는 두 다항식을 곱하는 함수
    NodePointer multHead = NULL;
    NodePointer acur, bcur;
    Poly multData;
    
    for (acur = ahead; acur; acur = acur->next) {
        for (bcur = bhead; bcur; bcur = bcur->next) {
            multData.exp = getExp(acur) + getExp(bcur);
            multData.coef = getCoef(acur) * getCoef(bcur);
            multHead = insertNode(multHead, multData);
        }
    }
    
    return multHead;
}



NodePointer insertNode(NodePointer head, Poly data) {
    //새로운 노드를 추가한 후 head를 반환하는 함수
    NodePointer cur, emptyNode;
    NodePointer newNode = (NodePointer)malloc(sizeof(Node));
    
    newNode->pdata = data;
    newNode->next = NULL;
    
    //head가 NULL일 때
    if (head == NULL) {
        return newNode;
    }
    
    //새로운 데이터의 exp가 head의 exp보다 클 경우
    if (getExp(head) < getExp(newNode)) {
        newNode->next = head;-
        return newNode;
    }
    
    //head의 exp가 새로운 데이터의 exp보다 더 클 경우
    for (cur = head; cur->next; cur = cur->next) {
        if (getExp(newNode) > getExp(cur->next)) {
            //newNode의 exp가 cur의 exp보다는 작지만 cur->next의 exp보다는 클 경우
            emptyNode = cur->next;
            cur->next = newNode;
            newNode->next = emptyNode;
            return head;
        }
        else if (getExp(newNode) == getExp(cur->next)) {
            //newNode의 exp가 cur의 exp보다는 작지만 cur->next의 exp와 같을 경우
            cur->next->pdata.coef += getCoef(newNode);
            free(newNode);
            
            if (getCoef(cur->next) == 0) {
                //cur->next가 0일 경우 노드를 삭제
                emptyNode = cur->next;
                cur->next = emptyNode->next;
                free(emptyNode);
            }
            
            return head;
        }
    }
    
    //for문을 빠져나왔다면 newNode의 exp가 제일 작은 경우
    cur->next = newNode;
    
    return head;
}
