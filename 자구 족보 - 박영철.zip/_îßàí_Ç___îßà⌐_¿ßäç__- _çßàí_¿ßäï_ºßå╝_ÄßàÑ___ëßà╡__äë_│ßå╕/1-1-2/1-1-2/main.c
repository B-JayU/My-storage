//
//  main.c
//  1-1-2
//
//  Created by 손명빈 on 2017. 8. 29..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <math.h>

void printSet(int size);

int main()
{
    int i;
    int size;
    int num,numcpy;
    int j,k;
    int line[100] = {0};
    
    scanf("%d",&size);
    
    num = pow(2,size);
    
    for(i=0; i<num; i++)
    {
        numcpy = i;
        
        for(k=0; k<num; k++)
        {
            line[k] = numcpy % 2;
            
            numcpy = numcpy/2;
        }

        printf("<");
        
        for(j=0; j<size; j++)
        {
            if(line[j] == 0)
                printf("true");
            
            if(line[j] == 1)
                printf("false");
            
            if(j != size-1)
                printf(",");
            
        }
        
        printf("> ");
        
    }
}

