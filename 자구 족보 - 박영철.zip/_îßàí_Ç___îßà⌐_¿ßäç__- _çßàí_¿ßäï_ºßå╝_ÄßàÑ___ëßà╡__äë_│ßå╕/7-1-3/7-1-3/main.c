//
//  main.c
//  7-1-3
//
//  Created by 손명빈 on 2017. 9. 19..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_LIST_SIZE 100

typedef struct
{
    int id;
    char name[20], address[50];
}element;

typedef struct a
{
    element data;
    int next;
    int prev;
}node;

void insert(node *, int *, int *);
void delete(node *, int *, int *);
void find(node *, int *, int *);
void read1(node *, int );

int main()
{
    node list_array[MAX_LIST_SIZE];
    
    int size=0;
    int first=0;
    
    while (1) {
        
        printf("i(삽입), d(삭제), f(탐색), r(전체 읽기), q(작업종료)를 선택하시오: \n");
        
        char ch;
        
        scanf(" %c", &ch);
        
        switch (ch)
        {
            case 'i':
                
                printf("삽입할 자료(학번, 이름, 주소)를 입력하시오. 종료시 학번 -1 :\n");
                insert(list_array, &size, &first);
                break;
            case 'd':
                
                printf("삭제할 자료의 학번을 입력하시오 :\n");
                delete(list_array, &size, &first);
                break;
            case 'f' :
                
                printf("탐색할 자료의 학번을 입력하시오 :\n");
                find(list_array, &size, &first);
                break;
            case 'r':
                
                read1(list_array, first);
                break;
            case 'q':
                
                return 0;
                
            default : printf("wrong input\n");
        }
    }
    
}

void insert(node *list, int *size, int *first)
{
    while(1)
    {
        int new;
        
        scanf("%d", &new);
        
        if(new==-1)
            return;
        
        list[++(*size)].data.id = new;
        
        scanf("%s", list[(*size)].data.name);
        
        fgets(list[(*size)].data.address, 50, stdin);
        
        int p = *first, q = *first;
        
        while(p)
        {
            if(list[p].data.id > list[*size].data.id)
                break;
            
            q=p;
            
            p=list[p].next;
        }
        
        if(p==*first)
        {
            list[*size].next=*first;
            (*first)=*size;
        }
        
        else
        {
            list[*size].next=p;
            list[q].next=*size;
        }
    }
}
void delete(node *list, int *size, int *first)
{
    int del;
    
    scanf("%d", &del);
   
    int p=*first, q=*first;
    
    while(p)
    {
        
        if(list[p].data.id == del)
            break;
        
        if(list[p].data.id > del)
        {
            printf("없는 자료형입니다\n");
            return;
        }
        q=p;
        
        p=list[p].next;
        
    }
    
    if (!p) {
        printf("없는 자료형입니다\n");
        return;
    }
    
    else if(p == *first)
    {
        printf("%d, %s,%s삭제\n", list[p].data.id, list[p].data.name, list[p].data.address);
        
        *first=list[*first].next;
        
        (*size)--; return;
    }
    
    else {
        printf("%d, %s,%s삭제\n", list[p].data.id, list[p].data.name, list[p].data.address);
        list[q].next=list[p].next;
        
        list[p].next=0;
        
        (*size)--;
    }
    
}
void read1(node *list, int first)
{
    int p=first;
    
    while(p)
    {
        printf("%d, %s,%s", list[p].data.id, list[p].data.name, list[p].data.address);
        p=list[p].next;
    }
}
void find(node *list, int *size, int *first)
{
    int target;
    
    int p=*first;
    
    scanf("%d", &target);

    while(list[p].data.id!=target)
        p=list[p].next;
    
    printf("%d, %s,%s", list[p].data.id, list[p].data.name, list[p].data.address);
}

