//
//  main.c
//  1-5-2
//
//  Created by 손명빈 on 2017. 8. 29..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <ctype.h>
#include <math.h>

void printPowerset(char line[], int size);
void func(int bit_arr[], int curidx, int num, int elementNum);

int main()
{
    char line[100] = {'0'};
    char line2[100] = {'0'};
    int num=0, r_num=0;
    int cnt;
    int i;
    
    
    while(1)
    {
        scanf("%c",&line[num]);
        
        if(line[num] == '{' || line[num] == '}')
            cnt++;
        
        if(cnt == 2)
            break;
        
        if(isdigit(line[num]) == 1 || isalpha(line[num]) == 1)
        {
            line2[r_num] = line[num];
            
            r_num++;
        }
            
        num++;
    
    }
    
    for(i=0; i<=r_num; i++)
    {
        func(line ,0 , i, r_num);
    }
    
}

void printPowerset(char line[], int size)
{
    int i,j;
    
    for(i=0; i<pow(size,2); i++)
    {
        printf("{");
        
        for(j=0; j<size; j++)
        {
            printf("%c",line[j]);
            
            if(size-1 == j)
                break;
            
            printf(",");
        }

        printf("}");
    }

}

void func(int bit_arr[], int curidx, int num, int elementNum)
{
    
    if (curidx >= num)
    {
        if(elementNum <= 0)
            printPowerset(bit_arr, num);
        
        return;
    }
    
    else
    {
        if (elementNum > 0)
        {
            bit_arr[curidx] = 1;
            func(bit_arr, curidx + 1, num, elementNum - 1);
        }
        
        bit_arr[curidx] = 0;
        func(bit_arr, curidx + 1, num, elementNum);
    }
}



//void func(char bit_arr[], int curIdx, int num)
//{
//    int i;
//    
//    if(curIdx >= num)
//    {
//        printPowerset(bit_arr,num);
//        return ;
//    }
//    
//    else
//    {
//        for(i=0; i<=1; i++)
//        {
//            bit_arr[curIdx] = i;
//            func(bit_arr,curIdx+1,num);
//        }
//}
//




































