//
//  main.c
//  run winner
//
//  Created by 손명빈 on 2017. 11. 9..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#define MAX_INT 100
#define RUN_SIZE 300

void print12(int ary[12]);
void print13(int ary[13]);
void setbtree(int find_num);
int selectNext(int run_num, int num);
int selectWinner(int rightChild, int leftChild);

int run0[RUN_SIZE], run1[RUN_SIZE], run2[RUN_SIZE], run3[RUN_SIZE];
int result[200];
int btree[16] = {0};

int main()
{
    int i = 0;
    
    FILE *f;
    
    f = fopen("txt.txt","r");
    
    while(!feof(f))
    {
        fscanf(f,"%d",&run0[i]);
        fscanf(f,"%d",&run1[i]);
        fscanf(f,"%d",&run2[i]);
        fscanf(f,"%d",&run3[i]);
        
        i++;
    }
    
    printf("run0 : ");
    print13(run0);
    
    printf("run1 : ");
    print13(run1);
    
    printf("run2 : ");
    print13(run2);
    
    printf("run3 : ");
    print13(run3);
    
    
    printf("\n");
    
    btree[8] = run0[0];
    btree[9] = run1[0];
    btree[10] = run2[0];
    btree[11] = run3[0];
    
    
    for(i=0; i<=100; i++)
    {
        btree[4] = selectWinner(btree[9], btree[8]);
        btree[5] = selectWinner(btree[11], btree[10]);
        btree[6] = selectWinner(btree[13], btree[12]);
        btree[7] = selectWinner(btree[15], btree[14]);
        
        btree[2] = selectWinner(btree[5], btree[4]);
        btree[3] = selectWinner(btree[7], btree[6]);
        
        btree[1] = selectWinner(btree[3], btree[2]);
        
        result[i] = btree[1];
        
        setbtree(btree[1]);
        
    }
    
    for(i=0; i<=100; i++)
        printf("%d ",result[i]);
}

void print12(int ary[12])
{
    int i;
    for(i=0; i<12; i++)
    {
        printf("%d ", ary[i]);
    }
    
    printf("\n");
}

void print13(int ary[13])
{
    int i;
    for(i=0; i<13; i++)
    {
        printf("%d ",ary[i]);
    }
    
    printf("\n");
    
}

void setbtree(int find_num)
{
    int i;
    int select;
    
    for(i=8; i<16; i++)
    {
        if(btree[i] == find_num)
        {
            select = i - 8;
            break;
        }
    }
    
    btree[i] = selectNext(select,find_num);
    
}

int selectNext(int run_num, int num)
{
    int nextnum = 0;
    int i;
    
    
    if(run_num == 0)
    {
        for(i=0; i<13; i++)
        {
            if(num == run0[i])
            {
                if(i != 12)
                {
                    nextnum = run0[i+1];
                    break;
                }
                
                else
                {
                    nextnum = MAX_INT;
                }
            }
        }
    }
    
    if(run_num == 1)
    {
        for(i=0; i<13; i++)
        {
            if(num == run1[i])
            {
                if(i != 12)
                {
                    nextnum = run1[i+1];
                    break;
                }
                
                else
                {
                    nextnum = MAX_INT;
                }
            }
        }
        
    }
    
    if(run_num == 2)
    {
        for(i=0; i<13; i++)
        {
            if(num == run2[i])
            {
                if(i != 12)
                {
                    nextnum = run2[i+1];
                    break;
                }
                
                else
                {
                    nextnum = MAX_INT;
                }
            }
        }
        
    }
    
    if(run_num == 3)
    {
        for(i=0; i<13; i++)
        {
            if(num == run3[i])
            {
                if(i != 12)
                {
                    nextnum = run3[i+1];
                    break;
                }
                
                else
                {
                    nextnum = MAX_INT;
                }
            }
        }
        
    }
    
    return nextnum;
}

int selectWinner(int rightChild, int leftChild)
{
    int parent;
    
    if(rightChild < leftChild)
        parent = rightChild;
    
    else
        parent = leftChild;
    
    return parent;
}









