//
//  main.c
//  10-2
//
//  Created by 손명빈 on 2017. 9. 28..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#define MAX_ARRAY_SIZE 200
#define MAX_ELEMENTS 200 /* maximum heap size+l */
#define HEAP_FULL(n) (n == MAX_ELEMENTS - 1)
#define HEAP_EMPTY(n) (!n)


typedef struct element
{
    int id;
    char name[20];
    char address[100];
}element;

element heap[MAX_ELEMENTS];
int current_size_ptr;
/* insert item into a max heap of current size *current_size_ptr */
void push(element item, int *current_size_ptr);
element pop(int *current_size_ptr);
element read1();

int main()
{
    int i;
    char fish;
    element temp;
    element print;
    
    printf("'학번 이름 주소' 순으로 입력하시오");

    for (i = 0; i<9; i++)
    {
        
        temp = read1();
        
        push(temp, &current_size_ptr);
    }
    
    for (i = 0; i < 9; i++)
    {
        printf("제일 작은 node를 삭제할까요?");
        scanf("%c%*c", &fish);
        
        if (fish == 'y')
        {
            print = pop(&current_size_ptr);
            printf("%d\n",print.id);
            printf("%s", print.name);
            printf("%s",print.address);
        }
        
        else
        {
            exit(0);
        }
    }
}

element pop(int *current_size_ptr)
{
    int parent, child;
    element item, temp;
    
    if (HEAP_EMPTY(*current_size_ptr))
    {
        fprintf(stderr, "The heap is empty\n");
        exit(0);
    }
    /* save value of the element with the highest key */
    item = heap[1]; // heap[0]이 아니고 heap[1]이 root node이다.
    /* use last elemet in heap to adjust heap */
    
    temp = heap[(*current_size_ptr)--];
    
    parent = 1;
    child = 2;
    
    while (child <= *current_size_ptr)
    {
        /* find the larger child of the current parent */
        if ((child < *current_size_ptr) && (heap[child].id < heap[child + 1].id))
            child++;
        
        if (temp.id >= heap[child].id)
            break;
        /* move to the next lower level */
        
        heap[parent] = heap[child];
        parent = child;
        child *= 2;
    }
    heap[parent] = temp;
    
    return item;
}

element read1()
{
    
    element new;
    
    scanf("%d%*c", &new.id);
    
    scanf("%s", new.name);
    fgets(new.address , 100, stdin);
    
    return new;
    
}

void push(element item, int *current_size_ptr)
{
    int i;
    
    i = ++(*current_size_ptr);
    
    while ((i != 1) && (item.id > heap[i / 2].id))
    {
        heap[i] = heap[i / 2];
        i /= 2;
    }
    heap[i] = item;
}
