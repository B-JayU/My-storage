//
//  main.c
//  기말 공부
//
//  Created by 손명빈 on 2017. 12. 3..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>

#define MAX_VERTEX 1000
#define VISITED 1001
#define NOT_VISITED 1000

#define TRUE 1
#define FALSE 0


//node struct
typedef struct node* NodePointer;
struct node {
    int vertex;
    struct node *link;
};
typedef struct node Node;


//adjLists. 나중에 동적으로 할당
NodePointer adjLists[MAX_VERTEX];

//각 노드가 방문했는지 아닌지를 1, 0으로 저장되어 있는 배열
int visited[MAX_VERTEX];

//motherVertex이면 1 아니면 0을 저장하는 배열
int motherVertex[MAX_VERTEX];



//adjLists에 관련된 함수
void initAdjLists(int vnum);

void deleteAdjLists(int vnum);

void findMotherVertex(int vnum);

void dfs(int v);

void insertEdge(int v1, int v2);

//visited 관련된 함수
void initVisited(int vnum);


//출력 함수
void printMotherVertex(char * fname, int vnum);

int main(int argc, char* argv[])
{
    int vertexNum, edgeNum, v1, v2, i=0;
    FILE* f1;
    
    if (argc != 3)
    {
        //인자의 수가 맞지않으면 종료
        fprintf(stderr, "인자의 수는 3개여야 합니다.");
        exit(1);
    }
    
    //인풋 파일 열기
    if ((f1 = fopen(argv[1], "r")) == NULL){
        printf("파일을 열지 못했습니다.");
        exit(1);
    }
    
    fscanf(f1, "%d %d", &vertexNum, &edgeNum);
    
    //vertex 갯수에 맞는 adjList 생성
    initAdjLists(vertexNum);
    
    //인풋 파일 읽어서 list에 정보 추가
    while (!feof(f1)) {
        fscanf(f1, "%d %d", &v1, &v2);
        insertEdge(v1, v2);
        i++;
    }
    fclose(f1);
    
    //인풋 파일에 있는 정보 갯수 확인
    if (i < edgeNum) {
        fprintf(stderr, "정보가 적습니다.");
        exit(1);
    }else if (edgeNum < i) {
        fprintf(stderr, "정보가 너무 많습니다.");
        fclose(f1);
        exit(1);
    }
    
    
    findMotherVertex(vertexNum);
    
    //motherVertex를 파일에다가 출력
    printMotherVertex(argv[2], vertexNum);
}



void initAdjLists(int vnum)
{
    int i;
    for (i = 0; i < vnum; i++)
        adjLists[i] = NULL;
}

void deleteAdjLists(int vnum)
{
    NodePointer search, next;
    int i;
    
    for (i = 0; i < vnum; i++) {
        for (search = adjLists[i]; search; search = next) {
            next = search->link;
            free(search);
        }
        free(adjLists[i]);
    }
    
    free(adjLists);
}

int isMotherVertex(int v, int vnum) {
    int i;
    
    for (i = 0; i < vnum; i++) {
        if (visited[i] == NOT_VISITED)
            return FALSE;
    }
    
    return TRUE;
}

void findMotherVertex(int vnum)
{
    int i;
    
    for (i = 0; i < vnum; i++) {
        initVisited(vnum);
        dfs(i);
        if (isMotherVertex(i, vnum))
            motherVertex[i] = TRUE;
    }
}

void dfs(int v)
{
    NodePointer search;
    
    if (visited[v] == VISITED) return;
    
    visited[v] = VISITED;
    
    for (search = adjLists[v]; search; search = search->link)
        dfs(search->vertex);
}


void insertEdge(int v1, int v2)
{
    NodePointer search, nodePointer = (NodePointer)malloc(sizeof(Node));
    
    nodePointer->vertex = v2;
    nodePointer->link = NULL;
    
    if (adjLists[v1] == NULL)
        adjLists[v1] = nodePointer;
    else {
        for (search = adjLists[v1]; search->link; search = search->link);
        search->link = nodePointer;
    }
}


int aidx;

int findVertex(int cur, int find, int arr[]) {
    NodePointer search;
    
    if (cur == find)
        return TRUE;
    
    
    if (visited[cur] == VISITED)	return FALSE;
    
    visited[cur] = VISITED;
    
    for (search = adjLists[cur]; search; search = search->link) {
        if (findVertex(search->vertex, find, arr)) {
            arr[aidx++] = search->vertex;
            return TRUE;
        }
    }
    
    return FALSE;
}


void printMotherVertex(char * fname, int vnum)
/*
 Mother Vertex들을 파일에다가 출력하는 함수
 */
{
    int i, j, k, arr[MAX_VERTEX];
    FILE* fp;
    
    if ((fp = fopen(fname, "w")) == NULL) {
        fprintf(stderr, "파일을 열 수 없습니다.");
        exit(1);
    }
    
    for (i = 0; i < vnum; i++) {
        if (motherVertex[i] == TRUE) {
            fprintf(fp, "motherVertex : %d \n", i);
            for (j = 0; j < vnum; j++) {
                initVisited(vnum);
                aidx = 0;
                findVertex(i, j, arr);
                
                fprintf(fp, "vertex %d 경로 : ", j);
                
                fprintf(fp, "%d ", i);
                
                for (k = aidx - 1; k >= 0; k-)
                    fprintf(fp, "%d ", arr[k]);
                
                fprintf(fp,"\n");
            }
        }
    }
    fclose(fp);
}



void initVisited(int vnum)
{
    int i;
    
    for (i = 0; i < vnum; i++)
        visited[i] = NOT_VISITED;
}
