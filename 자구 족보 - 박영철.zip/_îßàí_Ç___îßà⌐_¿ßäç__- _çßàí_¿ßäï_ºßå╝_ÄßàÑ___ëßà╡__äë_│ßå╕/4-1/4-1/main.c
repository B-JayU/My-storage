//
//  main.c
//  4-1
//
//  Created by 손명빈 on 2017. 9. 6..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <string.h>
#define max_string_size 100
#define max_pattern_size 100


int nfind(char *string, char *pat);


int main()
{
    
    FILE *f;
    int i;
    int temp = 0;
    
    char read[10000] = {0};
    
    char idx[100];
    int cnt=0;
    
    scanf("%s",idx);
    
    f = fopen("txt.txt","r");
    
    fgets(read, 10000, f);
    
    while(nfind(read,idx) != -1)
    {
        printf("%d ", nfind(read,idx));
        
        temp = nfind(read,idx);
        
        if(temp != -1)
        {
            for(i= temp; i<temp+40; i++)
                printf("%c",read[i]);
            read[temp] = '0';
            
            printf("\n");
        }
        
    }
    
    fclose(f);
    
}

int nfind(char *string, char *pat)
{ /* match the last character of pattern first, and then match from the beginning */
    int i, j, start = 0;
    unsigned long lasts = strlen(string)-1;
    unsigned long lastp = strlen(pat)-1;
    unsigned long endmatch = lastp;
    
    for (i = 0; endmatch <= lasts; endmatch++, start++)
    {
        if (string[endmatch] == pat[lastp])
        {
            for (j = 0, i = start; j < lastp && string[i] == pat[j]; i++,j++);
                if ( j == lastp)
                    return start; /* successful */
        }
    }
    return -1;
}
