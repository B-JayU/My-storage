//
//  main.c
//  4-1-2
//
//  Created by 손명빈 on 2017. 9. 6..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <string.h>
#define max_string_size 100
#define max_pattern_size 100

int failure[max_pattern_size];
char string[max_string_size];
char pat[max_pattern_size];

int nfind(char *string, char *pat);
char* swch(char *str, int num);
unsigned long pmatch(char *string, char *pat);
void fail(char *pat);


int main()
{
    
    FILE *f;
    unsigned long i;
    unsigned long temp = 0;
    
    char read[10000] = {0};
    
    char idx[100] = {0};
    
    scanf("%s",idx);
    
    f = fopen("txt.txt","r");
    
    fgets(read, 10000, f);
    
    fail(idx);
    
    while(pmatch(read,idx) != -1)
    {
        printf("%ld ", pmatch(read,idx));
        
        temp = pmatch(read,idx);
        
        if(temp != -1)
        {
            for(i= temp; i<temp+40; i++)
                printf("%c",read[i]);
            read[temp] = '0';
            
            printf("\n");
        }
        
    }
    
    fclose(f);
    
}

unsigned long pmatch(char *string, char *pat)
{ /* Knuth, Morris, Pratt string matching algorithm */
    int i = 0, j = 0;
    unsigned long lens= strlen(string);
    unsigned long lenp = strlen(pat);
    
    while ( i < lens && j < lenp )
    {
        if (string[i] == pat[j])
        {
            i++;
            j++;
        }
        
        else
        {
            if (j == 0)
                i++;
            else
                j = failure[j-1]+1;
        }
    }
    
    return ( (j == lenp) ? (i-lenp) : -1);
}



void fail(char *pat)
{
    unsigned long n = strlen(pat);
    int i = 0,j;
    
    failure[0] = -1;
    
    for (j=1; j < n; j++)
    {
        // decide failure[j]; (어디까지 최대로 같은가)
        i = failure[j-1]; // 바로 앞은 i 까지 같았다.
        while ((i>=0) && (pat[i+1] != pat[j]))
            i = failure[i];
        
        if (pat[i+1] == pat[j])
            failure[j] = i+1;
        
        else
            failure[j] = -1;
    }
}

