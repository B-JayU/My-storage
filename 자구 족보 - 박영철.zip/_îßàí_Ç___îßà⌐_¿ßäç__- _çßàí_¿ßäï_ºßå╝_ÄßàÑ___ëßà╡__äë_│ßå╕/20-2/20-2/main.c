//
//  main.c
//  20-2
//
//  Created by 손명빈 on 2017. 11. 23..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef struct node
{
    int data[2];
    struct node *next;
}node;

typedef struct
{
    int ld;
    node *Bucket_addr;
}nodepointer;

int get_mask (int gd);
int get_index(int key, int gd);
void printbin(int fish);
void printht();
void init_ht();

node *temp_bucket;
int gd = 2;

nodepointer *ht;

int main()
{
    int k, num;
    int temp;
    int j;
    
    init_ht();
    
    //첫번째 추가
    printf("추가할 자료를 입력하세요(종료 시 -1): \n");
    
    while (1)
    {
        scanf("%d", &num);
        
        if(num == -1)
            break;
        
        if(ht[get_index(num, gd)].Bucket_addr->data[0] == -1)
            ht[get_index(num, gd)].Bucket_addr->data[0] = num;
        
        else
            ht[get_index(num, gd)].Bucket_addr->data[1] = num;
    }
    
    printht();
    
    //두번째 추가
    printf("추가할 자료를 입력하세요(종료 시 -1): \n");
    
    while (1)
    {
        scanf("%d", &num);
        if(num == -1)
            break;
        
        if(ht[get_index(num, gd)].Bucket_addr->data[0] == -1)
            ht[get_index(num, gd)].Bucket_addr->data[0] = num;
        
        if(ht[get_index(num, gd)].Bucket_addr->data[1] == -1)
            ht[get_index(num, gd)].Bucket_addr->data[1] = num;
        
        if(ht[get_index(num, gd)].Bucket_addr->data[1] != -1)
        {
            ht[get_index(num, gd)].ld++;
            
            ht = (nodepointer *)realloc(ht,pow(2,++gd)*sizeof(nodepointer));
            
            temp = pow(2,gd-1);
            
            for (k = 0; k<temp; k++)
            {
                ht[k+temp] = ht[k];
            }
            
            
            temp_bucket = (node*)malloc(sizeof(node));
            temp_bucket->data[0] = -1;
            temp_bucket->data[1] = -1;
            
            ht[get_index(num, gd)].Bucket_addr = temp_bucket;
            ht[get_index(num, gd)].Bucket_addr->data[0] = num;
        }
        
    }
    
    printht();
    
    //세번째 추가
    printf("추가할 자료를 입력하세요(종료 시 -1): \n");

    while (1)
    {
        scanf("%d", &num);
        if(num == -1)
            break;
        
        
        if(ht[get_index(num, gd)].Bucket_addr->data[0] == -1)
            ht[get_index(num, gd)].Bucket_addr->data[0] = num;
        
        if(ht[get_index(num, gd)].Bucket_addr->data[1] == -1)
            ht[get_index(num, gd)].Bucket_addr->data[1] = num;
        
        if(ht[get_index(num, gd)].Bucket_addr->data[1] != -1)
        {
            ht[get_index(num, gd)].ld++;
            ht = (nodepointer *)realloc(ht,pow(2,++gd)*sizeof(nodepointer));
            int t = pow(2,gd-1);
            
            for (k = 0; k<t; k++)
                ht[k+t] = ht[k];
            
            temp_bucket = (node*)malloc(sizeof(node));
            temp_bucket->data[0] = -1;
            temp_bucket->data[1] = -1;
            
            ht[get_index(ht[get_index(num, gd)].Bucket_addr->data[1], gd)].Bucket_addr = temp_bucket;
            temp_bucket->data[0] = ht[get_index(num, gd)].Bucket_addr->data[1];
            
            ht[get_index(num, gd)].Bucket_addr->data[1] = num;
        }
        
    }
    
    printht();
    
    //첫번째 삭제
    printf("삭제할 자료를 입력하세요(종료 시 -1): \n");
    
    while (1)
    {
        scanf("%d", &num);
        if(num == -1)
            break;
        
        if(ht[get_index(num, gd)].Bucket_addr->data[0] == num)
            ht[get_index(num, gd)].Bucket_addr->data[0] = -1;
        
        if(ht[get_index(num, gd)].Bucket_addr->data[1] == num)
            ht[get_index(num, gd)].Bucket_addr->data[1] = -1;
        
        if(ht[get_index(num, gd)].Bucket_addr->data[1] == -1 && ht[get_index(num, gd)].Bucket_addr->data[0] == -1)
        {
            ht = (nodepointer *)realloc(ht,pow(2,--gd)*sizeof(nodepointer));
            
            for (int k =0; k<pow(2,gd); k++)
            {
                if (ht[k].ld == gd+1)
                    ht[k].ld--;
            }
        }
        
    }
    
    printht();
    
    
    //두번째 삭제
    printf("삭제할 자료를 입력하세요(종료 시 -1): \n");
    
    while (1)
    {
        scanf("%d", &num);
        
        if(num == -1)
            break;
        
        if(ht[get_index(num, gd)].Bucket_addr->data[0] == num)
            ht[get_index(num, gd)].Bucket_addr->data[0] = -1;
        
        if(ht[get_index(num, gd)].Bucket_addr->data[1] == num)
            ht[get_index(num, gd)].Bucket_addr->data[1] = -1;
        
        if (ht[get_index(num, gd)].Bucket_addr->data[0] == -1 && ht[get_index(num, gd)].Bucket_addr->data[1] == -1)
        {
            ht[get_index(num, gd)].Bucket_addr = ht[get_index(num, gd)+(int)pow(2,gd-1)].Bucket_addr;
            ht[get_index(num, gd)].ld--;
            
            ht[get_index(num, gd)+(int)pow(2,gd-1)].ld--;
            
            for (j=0; j<4; j++)
            {
                if (ht[get_index(num, gd)].ld >= gd)
                    break;
            }
            
            if (j == 4)
            {
                gd--;
                
                ht = (nodepointer *)realloc(ht, pow(2,gd)*sizeof(nodepointer));
            }
        }
        
    }
    
    printht();
    
}

int get_mask (int gd)
{
    int mask = 0x01;
    int count;
    
    for(count=1; count<gd; count++)
        mask = (mask << 1) + 0x01;
    
    
    return mask;
}

int get_index(int key, int gd)
{
    int index, mask;
    mask = get_mask(gd);
    index = key & mask;
    return index;
}

void printht ()
{
    int i;
    int cnt = 0;
    for (i =0; i<pow(2,gd); i++)
    {
        node *ptr = ht[i].Bucket_addr;
        while (1)
        {
            if (ptr == NULL)
                break;
            
            if (ptr != NULL)
            {
                printf("entry : ");
//                printbin(ht[i].Bucket_addr->data[0]);
                printbin(cnt++);
                printf(" local depth: ");
                printf("%d",ht[i].ld);
                
                printf(" bucket : ");
                printf("%d %d", ht[i].Bucket_addr->data[0], ht[i].Bucket_addr->data[1]);
                
                //
                ptr= ptr->next;
            }
        }
        printf("\n");
    }
}

void init_ht()
{
    int i;
    
    ht = (nodepointer *) malloc(4*sizeof(nodepointer));
    
    for (i=0; i<4; i++)
    {
        temp_bucket = (node*)malloc(sizeof(node));
        
        temp_bucket->data[0] = -1;
        temp_bucket->data[1] = -1;
        
        ht[i].ld = 2;
        ht[i].Bucket_addr = temp_bucket;
        
    }

}

void printbin(int fish)
{
    int i;
    
    for (i=gd-1; i >= 0; --i)
    {
        printf("%d", (fish >> i) & 1);
    }
}












