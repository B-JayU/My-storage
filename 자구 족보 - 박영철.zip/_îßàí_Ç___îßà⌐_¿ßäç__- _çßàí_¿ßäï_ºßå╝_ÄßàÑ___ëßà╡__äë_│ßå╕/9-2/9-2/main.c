//
//  main.c
//  9-2
//
//  Created by 손명빈 on 2017. 9. 26..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_STACK_SIZE 100
//////////////////////////////////////////struct
typedef struct element
{
    int id;
    char name[100];
    char address[100];
}element;
typedef struct node *nodePointer;
typedef struct node
{
    element data;
    nodePointer left, right;
    int count;
}*nodePointer;
///////////////////////////////////////////ta v
int arraysize = 1;
nodePointer malloctree;
nodePointer treemalloc[100];
///////////////////////////////////////////function
void addtree(int id, char name[100], char address[100]);
void inputnode(nodePointer node);
void iterinorder(nodePointer node);
void push(nodePointer node);
nodePointer pop(void);
///////////////////////////////////////////code
int main(void)
{
    char d[2] = "0";
    while (strcmp(d, "q") != 0)
    {
        printf("i(삽입), r(전체 읽기: inorder traversal), q(작업종료)를 선택하시오:");
        
        scanf("%s", d);
        if (strcmp(d, "i") == 0)
        {
            int id;
            char name[100], address[100];
            while (1)
            {
                printf("삽입할 자료(학번, 이름, 주소)를 입력하시오(종료시 학번 -1):");
                scanf("%d", &id);
                if(id == -1)
                {
                    break;
                }
                scanf("%s", name);
                fgets(address,100,stdin);
                
                addtree(id, name, address);
            }
        }
        else if (strcmp(d, "r") == 0)
        {
            printf("<학번, 이름, 주소> : ");
            iterinorder(treemalloc[1]);
            printf("\n");
        }
    }
}

void addtree(int id, char name[100], char address[100])
{
    nodePointer node;
    node = (nodePointer)malloc(sizeof(nodePointer));
    
    node->data.id = id;
    
    strcpy(node->data.name, name);
    strcpy(node->data.address, address);
    inputnode(node);
}
//Inorder traversal은 iterative version으로 수행되어야 한다.
int top = -1; /* initialize stack */

nodePointer stack[MAX_STACK_SIZE];

void iterinorder(nodePointer node)
{
    while (1)
    {
        
        node = node->left;
        push(node);
        
        node = pop();
        
        if (!node)
            break;
        /* empty stack */
        
        printf("< %d, %s, %s> ", node->data.id, node->data.name, node->data.address);
        
        node = node->right;
    }
}
void push(nodePointer node)
{
    if (top == -1)
    {
        stack[0] = node; top = 0;
    }
    
    else
    {
        stack[++top] = node;
    }
}

nodePointer pop(void)
{
    nodePointer a;
    
    a = stack[top--];
    return a;
}
int nodecount = 0;

void inputnode(nodePointer node)
{
    if (nodecount == 0)
    {
        malloctree = node;
        nodecount++;
        treemalloc[nodecount] = node;
    }
    else
    {
        nodecount++;
        if (nodecount % 2 == 0)
        {
            treemalloc[nodecount / 2]->left = node;
            treemalloc[nodecount] = node;
        }
        else
        {
            treemalloc[nodecount / 2]->right = node;
            treemalloc[nodecount] = node;
        }
    }
}
