//
//  main.c
//  9-2-2
//
//  Created by 손명빈 on 2017. 9. 26..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_STACK_SIZE 100
typedef struct element{
    int id;
    char name[50];
    char address[50];
}element;

int up = 0;
int down = 1;
int count = 1;

typedef struct node
{
    element data;
    struct node* left;
    struct node* right;
}node;

node *stack[MAX_STACK_SIZE];
node *idx[MAX_STACK_SIZE];
int top = 0;

void push(node *data);
node *pop(void);
node *newNode(void);
void insert(element data);
void read1(node *h);

int main(void)
{
    element data;
    char select,e;
    while(1)
    {
        printf("i(삽입), r(전체 읽기), q(작업종료)를 선택하시오 (종료시 학번 -1): ");
        
        scanf("%c%*c",&select);
        
        switch(select)
        {
        
            case 'i':
            {
                while(1)
                {
                    printf("삽입할 자료(학번, 이름, 주소)를 입력하시오: ");
                    scanf("%d",&data.id);
                
                    if(data.id == -1)
                    {
                        scanf("%c",&e);
                        break;
                    }
                
                    scanf("%s",data.name);
                    fgets(data.address,sizeof(data.address),stdin);
                
                    data.address[strlen(data.address)-1] = 0;
                    insert(data);
                }
                break;
            }
        
            case'r' :
            {
                read1(stack[0]);
                break;
            }
        
            case 'q' :
            {
                exit(0);
            }
                
            default :
            {
                printf("다시 입력하세요\n");
                break;
            }
        }
    }
}

void push(node *data)
{
    if(top >= MAX_STACK_SIZE -1)
    {
        printf("stack is full\n");
    }
    
    idx[++top] = data;
    
}
node *pop(void)
{
    if(top == -1)
        printf("stack is empty\n");
    
    return idx[top--];
}

node *newNode(void)
{
    node *nodd=(node*)malloc(sizeof(node));
    nodd->left = NULL;
    nodd->right = NULL;
    return nodd;
}
void insert(element data)
{
    if(stack[0] == NULL)
    {
        stack[0] = newNode();
        stack[0]->data = data;
    }
    else
    {
        stack[down] = newNode();
        stack[down]->data = data;
        
        if(count % 2 == 1)
        {
            stack[up]->left = stack[down];
            down++;
            count++;
        }
        else if(count % 2 == 0)
        {
            stack[up++]->right = stack[down++];
            count++;
            
        }
    }
}
void read1(node *h)
{
    node *cur = h;
    
    while(1)
    {
        while(cur != NULL)
        {
            push(cur);
            cur = cur->left;
        }
        
        cur = pop();
        if(cur == NULL)
            break;
        
        printf("id : %d, name : %s, address : %s\n",cur->data.id,cur->data.name,cur->data.address);
        
        cur = cur -> right;
    }
}


