//
//  main.c
//  19-4
//
//  Created by 손명빈 on 2017. 11. 22..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MALLOC(p, s) \
if (!((p) = malloc(s)))\
{ \
fprintf(stderr, "Insufficient memory"); \
exit(EXIT_FAILURE); \
}
typedef struct hash *hashpointer;

typedef struct hash
{
    int num;
    char *name;
    hashpointer next;
}hash;

typedef struct
{
    char major[60];
    int idx;
    char name[60];
    
}info;

hash *ht[13];
int h = 13;

info data[41];

int find_compare = 0;
int findcount = 0;
int del_compare = 0;
int del_count = 0;
int insert_compare = 0;
int chain[13] = {0, };
int chain_sum = 0;

unsigned int stringToint(char *key);
int hash_function(char *name);
void initial();
void insert(int num, char *name, int idx);
void print_ht();
void find(char *name);
void delete();

int main(void)
{
    int i = 0, count = 0;
    int idx;
    char *name;
    char findname[30];
    
    printf("정보를 입력하세요>>>(종료시 -1 -1 -1 입력)\n");
    while(1)
    {
        scanf("%s",data[i].major);
        scanf("%d",&data[i].idx);
        scanf("%s%*c",data[i].name);
        if(data[i].idx == -1)
            break;
        i++;
    }
    
    i = 0;
    printf("입력된 배열을 출력합니다.\n");
    while(1)
    {
        printf("<%s, %d, %s>\n", data[i].major, data[i].idx, data[i].name);
        
        i++;
        if(data[i].idx == -1)
            break;
    }
    initial();
    
    while(1)
    {
        idx = data[count].idx;
        name = data[count].name;
        if(data[count].idx == -1)
            break;
        insert(idx, name, data[count].idx);
        count++;
    }
    printf("\n\n삽입시 비교횟수의 전체평균 = %.3f\n\n", ((float)insert_compare)/40.0);
    
    print_ht();
    printf("\n");
    
    count = 0;
    while(1)
    {
        printf("<Ht[%d]'s chain length:%d>\n", count, chain[count]);
        chain_sum += chain[count];
        count++;
        if(count == 13)
            break;
    }
    printf("\nchain length의 전체평균 = %.3f\n\n", ((float)chain_sum)/((float)h));
    
    while(1)
    {
        printf("탐색할 학생 성명 입력:(종료시 quit 입력)\n");
        scanf("%s", findname);
        if(strcmp("quit", findname) == 0)
            break;
        find(findname);
        printf("\n");
    }
    printf("\n탐색시 비교횟수의 전체평균 = %.3f\n\n", ((float)find_compare)/((float)findcount));
    
    for (i = 0;; i++){
        printf("삭제할 학생 성명 입력:(종료시 quit입력)\n ");
        scanf("%s", name);
        if (strcmp(name, "quit") == 0)
            break;
        delete(name);
    }
    printf("삭제를 완료하였습니다.\n");
    printf("삭제시 비교횟수의 전체평균 = %.3f\n\n", ((float)del_compare)/((float)del_count));
    
    print_ht();
}

void initial()
{
    int count = 0;
    while(count != h)
    {
        ht[count] = NULL;
        count++;
    }
}

int hash_function(char *name)
{
    return stringToint(name) % h;
}

void insert(int num, char *name, int idx)
{
    hash *new, *cur;
    int i;
    int compare = 0;
    i = hash_function(name);
    
    
    if(ht[i] == NULL)
    {
        MALLOC(new, sizeof(hash));
        new->num = num;
        new->name = name;
        new->next = NULL;
        ht[i] = new;
        printf("(%2d(학번). 비교횟수:%2d) ", idx, compare);
        insert_compare += compare;
        chain[i]++;
    }
    else
    {
        cur = ht[i];
        while(1)
        {
            if(cur->next == NULL)
            {
                MALLOC(new, sizeof(hash));
                new->num = num;
                new->name = name;
                new->next = NULL;
                cur->next = new;
                insert_compare += compare;
                printf("(%2d(학번). 비교횟수:%2d) ",idx, compare);
                compare = 0;
                chain[i]++;
                break;
            }
            else
                cur = cur->next;
            
            compare++;
        }
    }
}

void print_ht()
{
    hash *cur;
    int count = 0;
    
    while(1)
    {
        printf("Ht[%d]: ", count);
        cur = ht[count];
        while(1)
        {
            if(cur == NULL)
                break;
            
            printf("<%d, %s> ", cur->num, cur->name);
            cur = cur->next;
        }
        count++;
        printf("\n");
        if(count == h)
            break;
    }
}

void find(char *name)
{
    hash *cur;
    int count = hash_function(name);
    int findnum = -1;
    int compare = 0;
    
    while(1)
    {
        cur = ht[count];
        while(1)
        {
            if(cur == NULL)
                break;
            if(strcmp(cur->name,name) == 0)
            {
                printf("학생정보:index = %d, <컴학, %d, %s>, (비교횟수:%d)\n", count, cur->num, cur->name, compare);
                findnum++;
                findcount++;
            }
            cur = cur->next;
            compare++;
        }
        count++;
        if(count == h)
            break;
    }
    if(findnum == -1)
        printf("학생정보:없음 (비교횟수:%d)\n", compare);
    
    find_compare += compare;
}

void delete(char* name)
{
    int count = 0, n = hash_function(name);
    hash *cur = ht[n], *pre = cur;
    int compare = 0;
    
    while (1)
    {
        if (cur == NULL && count == 0)
        {
            printf("학생정보 : 없음 (비교횟수:%d)\n", compare);
            del_compare += compare;
            compare = 0;
            del_count++;
            break;
        }
        if (cur == NULL)
            break;
        else if (strcmp(name, cur->name) == 0)
        {
            printf("index = %d에서 %s를 삭제하였습니다. (비교횟수:%d)\n", cur->num, name, compare);
            del_count++;
            del_compare += compare;
            compare = 0;
            
            if (cur == ht[n])
                ht[n] = cur->next;
            else
                pre->next = cur->next;
            free(cur);
            count++;
            cur = ht[n];
            pre = cur;
        }
        else
        {
            pre = cur;
            cur = cur->next;
        }
        compare++;
        
    }
}
unsigned int stringToint(char *key)
{
    int number = 0;
    
    while (*key)
        number += *key++;
    
    return number;
}
