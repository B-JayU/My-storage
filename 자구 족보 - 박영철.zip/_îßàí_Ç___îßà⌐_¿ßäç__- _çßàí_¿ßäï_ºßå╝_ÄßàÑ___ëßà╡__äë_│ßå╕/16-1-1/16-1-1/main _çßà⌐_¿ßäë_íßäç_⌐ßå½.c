//
//  main.c
//  16-1-1
//
//  Created by 손명빈 on 2017. 11. 6..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#define MAX_SIZE 10000
#define element int
#define SWAP(x,y,t) ( (t) = (x), (x) = (y), (y) = (t))


void selectionSort(int [],int);
void quickSort(element a[], int left, int right);
void examtime(int a[], int n, void sort());
void insertionSort(element a[], int n);
void insert(element e, element a[], int i);
void quickSort_median(element a[], int left, int right);
void examtime_quick(int a[], int n ,void sort(),int left,int right);

int main()
{
    int i,n = MAX_SIZE;
    int a[MAX_SIZE];
    int b[MAX_SIZE];
    double duration;
    clock_t start;
    /*timesforn=0,10,..., 100,200,...,1000*/

    
    printf("Enter the number of numbers to generate: ");
   // scanf ("%d", &n);
    n=MAX_SIZE;
    if( (n < 1) || (n >MAX_SIZE))
    {
        fprintf(stderr, "Improper value of n\n");
        exit(EXIT_FAILURE);
    }
    for (i = 0; i < n; i++)
    {/*randomly generate numbers*/
        a[i] =rand() % 1000;
//        printf("%d ", a[i]);
    }
    
    for(i=0; i<MAX_SIZE; i++)
    {
        b[i] = a[i];
    }
    

    printf("\n\n Sorted array wl selection sort:\n ");
    
    examtime(a,n,selectionSort);
    
    
    
    
    for(i=0; i<MAX_SIZE; i++)
    {
        a[i] = b[i];
    }
    
    
    printf("\n\n Sorted array wl insertion sort:\n ");
    
    examtime(a, n, insertionSort);

//    for (i = 1; i < n+1; i++) /* print out sorted numbers */
//        printf("%d ", a[i]);
//    printf ( "\n");
    
    
    
    
    for(i=0; i<MAX_SIZE; i++)
    {
        a[i] = b[i];
    }
    
    printf("\n\n Sorted array wl quick sort:\n ");

    start= clock( );
    quickSort(a, 0, MAX_SIZE-1);
    
    duration= ((double) (clock() -start)) / CLOCKS_PER_SEC;
    printf(" %f \n", duration);
    
//    for (i = 0; i < n; i++) /* print out sorted numbers */
//        printf("%d ", a[i]);
//    printf ( "\n");
    
    for(i=0; i<MAX_SIZE; i++)
    {
        a[i] = b[i];
    }
    
    printf("\n\n Sorted array wl quick sort using median-of-three:\n ");
    printf(" n time\n");
    start= clock( );
    quickSort_median(a, 0, MAX_SIZE-1);
    duration= ((double) (clock() -start)) / CLOCKS_PER_SEC;
    printf(" %f \n", duration);
    

    //    for (i = 0; i < n; i++) /* print out sorted numbers */
    //        printf("%d ", a[i]);
    //    printf ( "\n");
    
    exit(0);
}



void selectionSort(int a[], int n)
{
    int i, j, min, temp;
    for (i = 0; i < n-1; i++)
    {
        min = i;
        
        for (j = i+1; j < n; j++)
            if (a[j] < a[min]) min = j;
        
        if (min != i)
            SWAP(a[i],a[min],temp);
    }
}

void insertionSort(element a[], int n)
{
    /* sort a[l:n] into nondecreasing order */
    int j;
    for (j = 2; j <= n; j++)
    {
        element temp= a[j];
        insert(temp, a, j-1);
    }
}

void insert(element e, element a[], int i)
{
    /* insert e into the ordered list a[l:i] such that the resulting list a[l:i+l] is also ordered, the array a
     must have space allocated for at least i+2 elements */
    a[0] = e;
    
    while (a[i] > e)
    {
        a[i+1] = a[i];
        i--;
    }
    a[i+1] = e;
}



int sequentialSearch(element a[], int k, int n)
{
    /*search a[l:n]; return the least i such that a[i].key = k; return 0, if k is not in the array */ int i;
    for (i = 1; i <= n && a[i] != k; i++) ;
    if (i > n) return 0;
    return i;
}

void quickSort(element a[], int left, int right)
{
    /* sort a[left:right] into nondecreasing order on the key field; a[left].key is arbitrarily chosen as the pivot key; it is assumed that a[left].key <= a[right+l].key */
    int pivot,i,j;
    element temp;
    if (left < right)
    {
        i = left;
        j = right + 1;
        pivot = a[left];
        
        do {/* search for keys from the left and right sublists,
             swapping out-of-order elements 
             until the left and right boundaries cross or meet */
            do { i++; } while (a[i]< pivot);
            do { j--; } while (pivot<a[j]);
            if (i < j)
                SWAP(a[i],a[j],temp);
            } while ( i < j) ;
        SWAP(a[left],a[j],temp);
        quickSort(a,left,j-1);
        quickSort(a,j+1,right);
    }
}


void quickSort_median(element a[], int left, int right) {
    /* sort a[left:right] into nondecreasing order on the key field; a[left].key is arbitrarily chosen as the pivot key; it is assumed that a[left].key <= a[right+l].key */
    int pivot,i,j; element temp; if (left < right) {
        i = left; j = right + 1;
        pivot = a[(left+right)/2];
        do {/* search for keys from the left and right sublists,
             swapping out-of-order elements until the left and right boundaries cross or meet */
            do { i++; } while (a[i]< pivot); do { j--; } while (pivot<a[j]); if (i < j) SWAP(a[i],a[j],temp);
        } while ( i < j) ; SWAP(a[left],a[j],temp); quickSort(a,left,j-1); quickSort(a,j+1,right);
    }
}




void examtime(int a[], int n ,void sort())
{
    double duration;
    clock_t start;
    /*timesforn=0,10,..., 100,200,...,1000*/
    printf(" n time\n");
    
        start= clock( );
        sort (a, n);
        duration= ((double) (clock() -start)) / CLOCKS_PER_SEC;
        printf(" %f \n", duration);

}

//void examtime_quick(int a[], int n ,void sort,int left, int right)
//{
//    double duration;
//    clock_t start;
//    /*timesforn=0,10,..., 100,200,...,1000*/
//    printf(" n time\n");
//    
//    start= clock( );
//    sort (a,left,right);
//    duration= ((double) (clock() -start)) / CLOCKS_PER_SEC;
//    printf(" %f \n", duration);
//    
//}














