//
//  main.c
//  18-2
//
//  Created by 손명빈 on 2017. 11. 13..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#define INT_NUM 2000000
#define BLOCK_SIZE 1024
#define RUN_SIZE 5120
#define SWAP(x,y,t) ((t) = (x), (x) = (y), (y) = (t))

#include <stdio.h>
#include <stdlib.h>

void makedata(FILE *f);

void setbtree(int find_num);
int selectNext(int run_num, int idx);
int selectWinner(int rightChild, int leftChild);

void merge4way(FILE *f, int* result, int* run1, int* run2, int* run3, int* run4, int runsize);
void selectionsort(int [5120], int );
void initrun(int* run, int runsize);

void read5block(int run[RUN_SIZE], FILE *f);
void readandwrite(FILE* read, FILE* write, int runsize);

int* run1;
int* run2;
int* run3;
int* run4;

int runnum = 0;

int btree[8] = {0};

int idx1=0, idx2=0, idx3=0, idx4=0;

int* mergeresult;

int main()
{
    FILE *origin,*temp1,*temp2;
    int i,j;
    int runsize = RUN_SIZE;
    
    int temp[BLOCK_SIZE];
    int run[RUN_SIZE];
    int fish[400*RUN_SIZE-INT_NUM];
    int* a1,a2,a3;
    
    for(i=0; i<400*RUN_SIZE-INT_NUM; i++)
    {
        fish[i] = -1;
    }
    
    origin = fopen("origin.dat","wb+");
    
    makedata(origin);

    temp1 = fopen("temp1.dat","wb");
    temp2 = fopen("temp2.dat","wb");
    
    for(j=0; j<INT_NUM/BLOCK_SIZE; j++)
    {
        for(i=0; i<BLOCK_SIZE; i++)
        {
            temp[i] = rand()%INT_NUM;
        }
        
        fwrite(temp, sizeof(int)*BLOCK_SIZE, 1, origin);
    }
    
    for(i=0; i<128; i++)
    {
        temp[i] = rand()%INT_NUM;
    }
    
    fwrite(temp,sizeof(int)*128,1,origin);
    
    for(i=0; i<400*RUN_SIZE-INT_NUM; i++)
    {
        fish[i] = -1;
    }
    
    fwrite(fish,sizeof(int)*48000,1,origin);
    
    rewind(origin);
    
    for(j=0; j<400; j++)
    {
        fread(run, sizeof(int)*RUN_SIZE, 1, origin);
            
        selectionsort(run, RUN_SIZE);
        
        fwrite(run,sizeof(int)*RUN_SIZE,1,temp1);
    }
    
    for(i=0; i<100; i++)
    {
        readandwrite(temp1, temp2, runsize);
    }
    
    fclose(temp1);
    fclose(temp2);
    
    temp1 = fopen("temp1.dat","rb");
    temp2 = fopen("temp1.dat","wb");
    
    runsize = runsize*4;
    
    for(i=0; i<25; i++)
    {
        readandwrite(temp2, temp1, runsize);
    }
    
    fclose(temp1);
    fclose(temp2);
    
    temp1 = fopen("temp1.dat","wb");
    temp2 = fopen("temp2.dat","rb");
    
    runsize = runsize*4;
    
    for(i=0; i<6; i++)
    {
        readandwrite(temp1, temp2, runsize);
    }
    
    fread(a1, runsize*sizeof(int), 1, temp1);
    
    
    
}

void makedata(FILE *f)
{
    int i,temp;
    
    for(i=0; i<INT_NUM; i++)
    {
        temp = rand()%INT_NUM;
        
        fprintf(f,"%d ",temp);
    }
    
}

void setbtree(int find_num)
{
    int i;
    int select;
    
    for(i=4; i<8; i++)
    {
        if(btree[i] == find_num)
        {
            select = i - 3;
            break;
        }
    }
    
    if(select == 1)
    {
        idx1++;
        btree[i] = selectNext(select,idx1);
    }
    
    else if(select == 2)
    {
        idx2++;
        btree[i] = selectNext(select,idx2);
    }
    
    else if(select == 3)
    {
        idx3++;
        btree[i] = selectNext(select,idx3);
    }
    
    else if(select == 4)
    {
        idx4++;
        btree[i] = selectNext(select,idx4);
    }
    
}

int selectNext(int run_num, int idx)
{
    int nextnum = 0;
    
    if(run_num == 1)
    {
        nextnum = run1[idx];
    }
    
    else if(run_num == 2)
    {
        nextnum = run2[idx];
    }
    
    else if(run_num == 3)
    {
        nextnum = run3[idx];
    }
    
    else if(run_num == 4)
    {
        nextnum = run4[idx];
    }
    
    return nextnum;
}

int selectWinner(int rightChild, int leftChild)
{
    int parent;
    
    if(rightChild < leftChild)
        parent = rightChild;
    
    else
        parent = leftChild;
    
    return parent;
}

void merge4way(FILE *f, int* result, int* run1, int* run2, int* run3, int* run4, int runsize)
{
    int i;
    int cnt = 0;
    
    btree[4] = run1[0];
    btree[5] = run2[0];
    btree[6] = run3[0];
    btree[7] = run4[0];
    
    for(i=0; i<runsize; i++)
    {
        
        btree[2] = selectWinner(btree[4], btree[5]);
        btree[3] = selectWinner(btree[6], btree[7]);
        
        btree[1] = selectWinner(btree[2], btree[3]);
        
        if(btree[i] == -1)
            break;
        
        result[cnt] = btree[1];
        
        setbtree(btree[1]);

        if(cnt ==1023)
        {
            fwrite(result, sizeof(int)*1024, 1, f);
            cnt = -1;
        }
        
        cnt++;
    }
    
}

void initblock(int block[BLOCK_SIZE])
{
    int i;
    
    for(i=0; i<BLOCK_SIZE; i++)
    {
        block[i] = -1;
    }
}

void selectionsort(int list[], int n)
{
    int i,j,min,temp;
    
    for(i=0; i<n-1; i++)
    {
        min = i;
        
        for(j=i+1; j<n; j++)
            if(list[j] < list[min]) min = j;
        
        SWAP(list[i], list[min], temp);
    }
}


void read5block(int run[RUN_SIZE], FILE *f)
{
    int i;
    
    for(i=0; i<5; i++)
    {
        fread(run,sizeof(int)*BLOCK_SIZE,1,f);
    }
    
}

void readandwrite(FILE* read, FILE* write, int runsize)
{
    initrun(mergeresult,runsize);
    
    read5block(run1, read);
    fseek(read, sizeof(int)*runsize, SEEK_CUR);
    
    read5block(run2, read);
    fseek(read, sizeof(int)*runsize, SEEK_CUR);
    
    read5block(run3, read);
    fseek(read, sizeof(int)*runsize, SEEK_CUR);
    
    read5block(run4, read);
    fseek(read, sizeof(int)*runsize, SEEK_CUR);
    
    merge4way(read, mergeresult, run1, run2, run3, run4, runsize);
    
    fwrite(mergeresult, sizeof(int), runsize*4, write);
}

void initrun(int* run, int runsize)
{
    int i;
    
    for(i=0; i<runsize*4; i++)
    {
        run[i] = -1;
    }
}















