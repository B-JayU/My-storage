//
//  main.c
//  18-3
//
//  Created by 손명빈 on 2017. 11. 13..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <memory.h>
#include <string.h>
#include "Sort.h"
#include "WinnerTree.h"

#define MAX_NUMBER_OF_RUN 1000
 //DataCount개의 난수를 생성하여 파일에 저장하는 함수.
void Step1(int datnum)
{
    srand((unsigned int)time(0));
    
    int rand1;
    int rand2;
    int i;
    int randomNum;
    
    int Data = { 0 };
    
    FILE *fp;
    
    //파일 열기
    fp = fopen("origin.txt", "wb");
    
    //파일을 여는데 실패했을 경우
    if (fp == NULL)
    {
        printf("Access Error!\n");
        exit(0);
    }
    
    //0~DataCount의 난수를 생성하여 파일에 쓰기
    for (i = 0; i <= datnum; i++)
    {
        rand1 = rand();
        rand2 = rand();
        randomNum = rand()%2000000;
        
        Data = randomNum;
        
        fwrite(&Data, sizeof(int), 1, fp);
    }
    
    //사용한 파일 닫기
    fclose(fp);
}

void Step2(int datnum, int InitRunNumber)
{
    //Run의 key개수만큼 데이터를 저장할 수 있는 임시 배열을 생성.
    int EachRunSize = datnum / InitRunNumber;
    int *tempArr = (int*)malloc(sizeof(int)*EachRunSize);
    
    //하나의 Run의 끝을 나타낼 Data
    int DefaultData = { -1 };
    
    //정렬되지 않은 데이터가 있는 파일을 읽기 모드로 열기.
    FILE *fp_origin;
    fp_origin = fopen("origin.txt", "rb");
    
    if (fp_origin == NULL)
    {
        printf("Access Error!\n");
        exit(0);
    }
    
    //각각 정렬된 Run을 저장할 파일 temp1.dat을 쓰기 모드로 열기
    FILE *fp_temp;
    
    fp_temp = fopen("temp1.dat", "wb");
    
    if (fp_temp == NULL)
    {
        printf("Can not open the file %s\n", "temp1.dat");
        exit(0);
    }
    
    //Run Size만큼 데이터를 읽어서 정렬한 후 temp1.dat에 저장.
    for (int i = 0; i < InitRunNumber; i++)
    {
        //정렬 되지 않은 파일에서 Run Size 만큼 데이터를 읽어옴.
        fread(tempArr, sizeof(int)*EachRunSize, 1, fp_origin);
        
        //데이터를 정렬   `
        MergeSort(tempArr, 0, EachRunSize - 1);
    
        fwrite(tempArr, sizeof(int)*EachRunSize, 1, fp_temp);
        
        //run 끝은 -1
        fwrite(&DefaultData, sizeof(int), 1, fp_temp);
        
    }
    
    fclose(fp_origin);
    fclose(fp_temp);
}

//Run을 줄여나가며 하나의 Run으로 만든다.
void Step3(int datnum, int NumberOfRun, char finalFileName[])
{
    FILE *fp_StartsOfRun[MAX_NUMBER_OF_RUN] = { 0 };
    
    //값 갯수 = 총갯수 / Run갯수
    int KeyCount = datnum / NumberOfRun;
    
    //WinnerTree만드는데 필요한 변수
    Wtree WinnerTreePtr;
    
    WinnerTreeInit(&WinnerTreePtr, NumberOfRun);
    
    for (int i = 0; i < NumberOfRun; i++)
    {
        fp_StartsOfRun[i] = fopen("temp1.dat", "rb");
        
        fseek(fp_StartsOfRun[i], sizeof(int)*(KeyCount + 1)*i, 0);
    }
    
    MakeWinnerTree(&WinnerTreePtr, fp_StartsOfRun, NumberOfRun, KeyCount, finalFileName);
}

void Step4(char finalFileName[])
{
    FILE *fp_final;
    int getData = { 0 };
    int i = 0;
        
    fp_final = fopen(finalFileName, "rb");
    
    while (!feof(fp_final))
    {
        fread(&getData, sizeof(int), 1, fp_final);
        printf(" %d %5d\n", i,getData);
        i++;
    }
}

int main()
{
    char finalFileName[30] = "final";
    
    //Data개수
    int datcount = 2000000;
    
    //처음 Run 개수
    int InitialRunNumber = 2000000/1024/5;
    
    Step1(datcount);
    
    Step2(datcount, InitialRunNumber);
    
    Step3(datcount, InitialRunNumber, finalFileName);
    
    Step4(finalFileName);
    
    
    
}
