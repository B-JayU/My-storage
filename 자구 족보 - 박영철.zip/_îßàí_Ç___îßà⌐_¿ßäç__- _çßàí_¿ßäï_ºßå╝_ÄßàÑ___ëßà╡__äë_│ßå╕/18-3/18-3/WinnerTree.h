//
//  Header.h
//  18-3
//
//  Created by 손명빈 on 2017. 11. 13..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#ifndef Header_h
#define Header_h


#endif /* Header_h */

#pragma once
#pragma once
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "Sort.h"

#define MAX_TREE_SIZE 10000
#define MAX_INTEGER 2147000000

typedef struct WinnerTreeNode
{
    int num;
    int runNumber;
}WtreeNode;

typedef struct WinnerTree
{
    WtreeNode WtreeArray[MAX_TREE_SIZE];
}Wtree;

int getPowerOf2(int NumbeOfWay)
{
    int log2OfWay = (int)log2(NumbeOfWay);
    int ClosedNumber = (int)pow(2, log2OfWay + 1);
    return ClosedNumber;
}

void WinnerTreeInit(Wtree *pWtree, int k)
{
    int fish = getPowerOf2(k);
    int ClosedNumber = 4;
    int i;
    
    //run의 번호 : 0~k
    for (i = 0; i<ClosedNumber; i++)
    {
        pWtree->WtreeArray[i + ClosedNumber].runNumber = i;
    }
    
}

int GetLeftChildIndex(int ParentIndex)
{
    return 2 * ParentIndex;
}

int GetRightChildIndex(int ParentIndex)
{
    return 2 * ParentIndex + 1;
}


void MakeWinnerTree(Wtree *pWtree, FILE *fpArray[], int NumberOfWay, int KeyCount, char finalFileName[])
{
    int i;
    int LeftChild, RightChild;
    //int ClosedNumber = getPowerOf2(NumberOfWay);
    int ClosedNumber = 4;
    int block[1024];
    int cnt = 0;
    
    
    FILE *fp_final;
    fp_final = fopen(finalFileName, "wb");
    
    //시작할 때 key값 초기화
    for (i = ClosedNumber; i <= 2 * ClosedNumber - 1; i++)
    {
        //초기값 할당
        if (i - ClosedNumber < NumberOfWay)
        {
            //pWtree->WtreeArray[i].key = getw(fpArray[i - ClosedNumber]);
            fread(&pWtree->WtreeArray[i].num, sizeof(int), 1, fpArray[i - ClosedNumber]);
        }
        else
        {
            pWtree->WtreeArray[i].num = -1;
        }
    }
    
    while (1)
    {
        for (i = ClosedNumber - 1; i >= 1; i--)
        {
            //왼쪽, 오른쪽 자식의 인덱스
            LeftChild = GetLeftChildIndex(i);
            RightChild = GetRightChildIndex(i);
            
            //왼쪽, 오른쪽 자식의 key값
            int LeftChildNode = pWtree->WtreeArray[LeftChild].num;
            int RightChildNode = pWtree->WtreeArray[RightChild].num;
            
            //왼쪽 자식이 이겼으면
            if (LeftChildNode < RightChildNode)
            {
                //result값이 -1
                if (LeftChildNode == -1)
                {
                    pWtree->WtreeArray[i] = pWtree->WtreeArray[RightChild];
                }
                
                else
                {
                    pWtree->WtreeArray[i] = pWtree->WtreeArray[LeftChild];
                }
            }
            //오른쪽 자식이 이겼으면
            else
            {
                //-1이라서 이긴거면
                if (RightChildNode == -1)
                {
                    pWtree->WtreeArray[i] = pWtree->WtreeArray[LeftChild];
                }
                
                else
                {
                    pWtree->WtreeArray[i] = pWtree->WtreeArray[RightChild];
                }
            }
        }
        
        //루트가 -1
        if (pWtree->WtreeArray[1].num == -1)
        {
            break;
        }
        
        fwrite(&pWtree->WtreeArray[1].num, sizeof(int), 1, fp_final);
        
        //setwinner함수랑 같은거야! run의 끝까지 갔으면 -1
        int runIndex = pWtree->WtreeArray[1].runNumber;
        int temp;
        
        fread(&temp, sizeof(int), 1, fpArray[runIndex]);
        
        pWtree->WtreeArray[runIndex + ClosedNumber].num = temp;
        
        cnt++;
    }
    
    fclose(fp_final);
}
