//
//  Header.h
//  18-3
//
//  Created by 손명빈 on 2017. 11. 13..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#ifndef Header_h
#define Header_h

#pragma once

#include <stdlib.h>

#define SWAP(x, y, t) ((t) = (x), (x) = (y), (y) = (t))


void SelectionSort(int arr[], int size)
{
    int minidx;
    int temp;
    
    for (int i = 0; i < size - 1; i++)
    {
        minidx = i;
        for (int j = i + 1; j < size; j++)
        {
            if (arr[minidx] > arr[j])
                minidx = j;
        }
        SWAP(arr[i], arr[minidx], temp);
    }
}

void MergeTwoArea(int arr[], int left, int mid, int right)
{
    int front = left;
    int rear = mid + 1;
    
    int *sortArr = (int*)malloc(sizeof(int)*(right + 1));
    int SortIndex = left;
    
    while (front <= mid && rear <= right)
    {
        if (arr[front] <= arr[rear])
            sortArr[SortIndex] = arr[front++];
        else
            sortArr[SortIndex] = arr[rear++];
        
        SortIndex++;
    }
    
    if (front > mid)
    {
        for (int i = rear; i <= right; i++, SortIndex++)
            sortArr[SortIndex] = arr[i];
    }
    
    else
    {
        for (int i = front; i <= mid; i++, SortIndex++)
            sortArr[SortIndex] = arr[i];
    }
    
    for (int i = left; i <= right; i++)
        arr[i] = sortArr[i];
    
    free(sortArr);
}

void MergeSort(int arr[], int left, int right)
{
    int mid;
    
    if (left < right)
    {
        mid = (left + right) / 2;
        
        MergeSort(arr, left, mid);
        MergeSort(arr, mid + 1, right);
        
        MergeTwoArea(arr, left, mid, right);
    }
}



#endif /* Header_h */






