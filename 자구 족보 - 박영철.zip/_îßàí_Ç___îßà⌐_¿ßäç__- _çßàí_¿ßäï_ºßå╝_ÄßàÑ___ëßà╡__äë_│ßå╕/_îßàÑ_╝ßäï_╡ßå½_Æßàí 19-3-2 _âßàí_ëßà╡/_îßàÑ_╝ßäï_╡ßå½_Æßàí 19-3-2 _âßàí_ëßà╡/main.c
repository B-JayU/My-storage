//
//  main.c
//  정인하 19-3-2 다시
//
//  Created by 손명빈 on 2017. 11. 21..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define h(k) (k%13)

typedef struct student
{
    char faculty[20];
    int number;
    char name[10];
}Student;

Student a[40]={0};

typedef struct node
{
    char name[10];
    int index;
    struct node *next;
}node;

node Ht[13]={{"None",-1,NULL,},{"None",-1,NULL,},{"None",-1,NULL,},{"None",-1,NULL,},{"None",-1,NULL,},{"None",-1,NULL,},{"None",-1,NULL,},{"None",-1,NULL,},{"None",-1,NULL,},{"None",-1,NULL,},{"None",-1,NULL,},{"None",-1,NULL,},{"None",-1,NULL,}};

void init_student();
int stringToint(char *);
void insert();
void readAll();
void find(char []);
void delete(char []);
int main()
{
    
    int i;
    Student save;
    
    printf("(소속 학번 성명) 입력\n");
    
    for(i=0; i<40; i++)
    {
        scanf("%s %d %s",a[i].faculty,&a[i].number,a[i].name);
    }
    printf("a[40] 출력\n");
    for(i=0; i<40; i++)
    {
        printf("%s %d %s\n",a[i].faculty,a[i].number,a[i].name);
    }
    
    printf("\n");
    printf("a[40]의 학생 정보를 Ht[13]에 삽입\n");
    insert();
    printf("Ht[13] 출력\n");
    readAll();
    
    char n;
    char nm[10];
    
    while(1)
    {
        printf("\n");
        printf("메뉴를 고르시오 ( f : 탐색 , r : 전체읽기, d : 삭제 , q : 종료)\n");
        scanf(" %c",&n);
        
        switch(n)
        {
            case 'f' :
                printf("탐색할 성명을 입력하시오. (텍스트에서 복사후 붙이기로 입력해야함!)\n");
                scanf("%s",nm);
                find(nm);
                break;
            case 'd' :
                printf("삭제할 성명을 입력하시오. (텍스트에서 복사후 붙이기로 입력해야함!)\n");
                scanf("%s",nm);
                delete(nm);
                break;
            case 'r' :
                printf("Hash Table 출력\n");
                readAll();
                break;
            case 'q' :
                return 0;
                
        }
    }
    return 0;
}
//void init_student()
//{
//    int i=0;
//    Student save;
//
//    while(1)
//    {
//        if(i==30)
//            break;
//        scanf("%s %ld %s",save.faculty,&save.number,save.name);
//        strcpy(a[i].faculty,save.faculty);
//        a[i].number=save.number;
//        strcpy(a[i].name,save.name);
//        i++;
//    }
//
//}
int stringToint(char *key)
{
    int number = 0;
    
    while(*key)
        number+=*key++;
    
    return -number;
}
void insert()
{
    int i;
    int hIndex;
    int nameToInt;
    
    node *p;
    
    for(i=0; i<40; i++)
    {
        nameToInt=stringToint(a[i].name);
        hIndex=h(nameToInt);
        
        p=&Ht[hIndex];
        
        if(p->index==-1) //값이 하나도 안 들어있으면
        {
            node *temp;
            temp=(node*)malloc(sizeof(node));
            temp->index=i;
            strcpy(temp->name,a[i].name);
            temp->next=NULL;
            
            p->next=temp;
            p->index=-2;
            continue;
        }
        
        p=p->next;
        while(p->next!=NULL)
        {
            p=p->next;
        }
        node *temp;
        temp=(node*)malloc(sizeof(node));
        temp->index=i;
        strcpy(temp->name,a[i].name);
        temp->next=NULL;
        
        p->next=temp;
    }
}
void readAll()
{
    int i;
    
    for(i=0; i<13; i++)
    {
        node *p;
        p=&Ht[i];
        p=p->next;
        printf("Ht[%d]:",i);
        while(p!=NULL)
        {
            if(p->index==-1)
                break;
            printf("<%s,%d>  ",p->name,p->index);
            p=p->next;
        }
        printf("\n");
    }
}
void find(char name[])
{
    int i;
    
    for(i=0; i<13; i++)
    {
        node *p;
        p=&Ht[i];
        p=p->next;
        while(p!=NULL)
        {
            if(strcmp(p->name,name)==0)
            {
                printf("학생정보 : index = %d, <%s,%d,%s>\n",p->index,a[p->index].faculty,a[p->index].number,a[p->index].name);
                return;
            }
            p=p->next;
        }
    }
    printf("학생정보 : 없음.\n");
}
void delete(char name[])
{
    int i;
    node *del;
    
    for(i=0; i<13; i++)
    {
        node *p;
        p=&Ht[i];
        while(p->next!=NULL)
        {
            if(strcmp(p->next->name,name)==0)
            {
                printf("학생정보 : index = %d, <%s,%d,%s>를  Hash Table에서 삭제합니다.\n",p->next->index,a[p->next->index].faculty,a[p->next->index].number,a[p->next->index].name);
                del=p->next;
                p->next=p->next->next;
                free(del);
                return;
            }
            p=p->next;
        }
    }
    printf("%s은 hash table에 존재하지 않음.\n",name);
    
}
