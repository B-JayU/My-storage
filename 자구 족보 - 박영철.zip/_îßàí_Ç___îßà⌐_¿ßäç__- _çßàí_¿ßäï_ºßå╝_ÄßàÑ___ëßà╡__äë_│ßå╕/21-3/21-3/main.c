//
//  main.c
//  21-3
//
//  Created by 손명빈 on 2017. 11. 30..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>

typedef struct element
{
    int num;
    char alpha;
}element;

typedef struct node
{
    element data[2];
    int ld;
}node;

typedef struct node* nodepointer;

int get_mask(int ld);
int get_index(int key, int ld);
void initht();
void arrange(int num);
int changeTonum(char a, int b);
int checkState(int idx);
element changeToalpha(int temp);

int gd = 2;

nodepointer* ht;

int main()
{
    char ch;
    
    char a;
    int b;
    
    while(1)
    {
        scanf("%c",&ch);
        
        if(ch == '\n')
            continue;
            
        switch(ch)
        {
            case 'i':
            {
                printf("데이터를 입력하시오");
                
                while(1)
                {
                    scanf("%c",&a);
                    
                    if(a == '\n')
                        continue;
                    if(a == '-')
                        break;
                    
                    scanf("%d",&b);
                    
                    arrange(changeTonum(a,b));
                    
                    
                }
                
            }
            
            case 'r':
            {
                
            }
                
            case 'd':
            {
                
            }
                
            case 'q':
            {
                break;
            }
        }
    }
}

void initht()
{
    int i;
    
    ht = (nodepointer*)malloc(sizeof(nodepointer));
    
    for(i=0; i<4; i++)
    {
        ht[i]->data->alpha = '-';
        ht[i]->data->num = 1;
        ht[i]->ld = 2;
    }
}

void arrange(int num)
{
    element temp;
    int idx = get_index(num, ld);
    int state = 0;
    
    temp = changeToalpha(num);
    
    state = checkState(idx);
    
    if(state == 0 || state == 1)
    {
        ht[idx]->data[state] = temp;
    }
    
    if(state == 2)
    {
        
    }

}

int get_mask(int ld)
{
    int mask = 0x01;
    int count;
    for (count = 1; count < gd; count++) mask = (mask << 1) + 0x01;
    return mask;
}

int get_index(int key, int ld)
{
    int index, mask;
    mask = get_mask(ld);
    index = key & mask;
    return index;
}

element changeToalpha(int temp)
{
    element result;
    
    if(temp >= 48)
    {
        result.alpha = 'C';
        result.num = temp-48;
    }
    
    else if(temp >= 40)
    {
        result.alpha = 'C';
        result.num = temp-40;
    }
    
    else if(temp >= 32)
    {
        result.alpha = 'C';
        result.num = temp-32;
    }
    
    return result;
}

int changeTonum(char a, int b)
{
    int result = 0;
    
    if(a == 'A')
    {
        result+=32;
    }
    
    else if(a == 'B')
    {
        result+=40;
    }
    
    else if(a == 'C')
    {
        result+=48;
    }
    
    result+=b;
    
    return result;
}

int checkState(int idx)
{
    int state = 0;

    if(ht[idx]->data[1].alpha != '-')
    {
        state = 1;
        
        if(ht[idx]->data[0].alpha != '-')
        {
            state = 0;
        }
    }
    
    else
        state = 2;
    
    return state;
}






























