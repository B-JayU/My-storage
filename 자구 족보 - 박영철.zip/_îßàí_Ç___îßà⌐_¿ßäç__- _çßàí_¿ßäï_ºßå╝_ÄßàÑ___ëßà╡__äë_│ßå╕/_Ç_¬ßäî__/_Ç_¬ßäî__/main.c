//
//  main.c
//  과제4
//
//  Created by 손명빈 on 2017. 11. 9..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#define RUN_SIZE 300
#define MAX_INT 10000
#define FALSE  0
#define TRUE 1

struct student
{
    int id;
    char name[40];
    char address[100];
};

typedef struct student element;

void makedata(FILE *f);
void sort5block(element *run, element *block1, element *block2, element *block3, element *block4, element *block5, int runsize);

void setbtree(int find_num);
int selectNext(int run_num, int idx);
element selectWinner(element rightChild, element leftChild);
void sort(element result[300], element* block1, element* block2, element* block3, element* block4, int runsize);
element run1[RUN_SIZE], run2[RUN_SIZE], run3[RUN_SIZE], run4[RUN_SIZE];
int runnum = 0;


element entire[115][60];
element run[23][300];
element btree[8] = {0};

int idx1=0,idx2=0,idx3=0,idx4=0;

int main()
{
    FILE *test ,*sorted;
    int cnt = 0;
    
    int i,j;
    
    test = fopen("test.txt","w");
    
    makedata(test);
    
    fclose(test);
    
    test = fopen("test.txt","r");
    
    for(i=0; i<115; i++)
    {
        for(j=0; j<60; j++)
        {
            fscanf(test,"%d %s %s ", &entire[i][j].id, entire[i][j].name, entire[i][j].address);
        }
    }
    
    for(i=0; i<23; i++)
    {
        sort5block(run[i], entire[cnt], entire[cnt+1],entire[cnt+2],entire[cnt+3],entire[cnt+4],300);
        cnt++;
        
        printf("runnum : %d\n",++runnum);
        
        for(j=0; j<300; j++)
        {
            fprintf(f,"%d %dname %daddress", run[i].id, run[i].id, run[i].id);
        }
    }
    
    sorted = fopen("sorted.txt","w");
    
    
    
    fclose(sorted);
    
}

void makedata(FILE *f)
{
    int i;
    element temp;
    
    for(i=0; i<6900; i++)
    {
        temp.id = rand()%6900;
        
        fprintf(f,"%d %dname %daddress\n",temp.id,temp.id,temp.id);
        
        fprintf(stdout,"%d %dname %daddress\n",temp.id,temp.id,temp.id);

    }
    
}

void setbtree(int find_num)
{
    int i;
    int select;
    
    for(i=4; i<8; i++)
    {
        if(btree[i].id == find_num)
        {
            select = i - 3;
            break;
        }
    }
    
    if(select == 1)
    {
        idx1++;
        btree[i].id = selectNext(select,idx1);
    }
    
    else if(select == 2)
    {
        idx2++;
        btree[i].id = selectNext(select,idx2);
    }
    
    else if(select == 3)
    {
        idx3++;
        btree[i].id = selectNext(select,idx3);
    }
    
    else if(select == 4)
    {
        idx4++;
        btree[i].id = selectNext(select,idx4);
    }
    
}

int selectNext(int run_num, int idx)
{
    int nextnum = 0;
    
    if(run_num == 1)
    {
        nextnum = run1[idx].id;
    }
        
    else if(run_num == 2)
    {
        nextnum = run2[idx].id;
    }
    
    else if(run_num == 3)
    {
        nextnum = run3[idx].id;
    }
    
    else if(run_num == 4)
    {
        nextnum = run4[idx].id;
    }
    
    return nextnum;
}

element selectWinner(element rightChild, element leftChild)
{
    element parent;
    
    if(rightChild.id < leftChild.id)
        parent = rightChild;
    
    else
        parent = leftChild;
    
    return parent;
}

void sort(element *run, element* block1, element* block2, element* block3, element* block4,int runsize)
{
    int i;
    
    btree[4] = block1[0];
    btree[5] = block2[0];
    btree[6] = block3[0];
    btree[7] = block4[0];
    
    for(i=0; i<runsize; i++)
    {
        btree[2] = selectWinner(btree[4], btree[5]);
        btree[3] = selectWinner(btree[6], btree[7]);
        
        btree[1] = selectWinner(btree[2], btree[3]);
        
        run[i] = btree[1];
        
        setbtree(btree[1].id);
        
    }

}

void sort5block(element *run, element *block1, element *block2, element *block3, element *block4, element *block5, int runsize)
{
    element* temp;
    sort(temp,block1,block2,block3,block3,runsize/5*4);
    
    sort(temp,block2,block3,block4,block5,runsize);
}








