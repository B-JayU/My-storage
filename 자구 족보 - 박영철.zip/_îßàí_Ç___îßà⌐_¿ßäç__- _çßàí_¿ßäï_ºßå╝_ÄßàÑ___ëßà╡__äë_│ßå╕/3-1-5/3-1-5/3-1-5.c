//
//  main.c
//  3-1-5
//
//  Created by 손명빈 on 2017. 9. 5..
//  Copyright © 2017년 손명빈. All rights reserved.
//

int avail;
#define MAX_TERMS 100

int avail = 0;
typedef struct{
    float coe;
    int exp;
}pol;
pol terms[MAX_TERMS];

#include <string.h>
#include <stdio.h>

int COMPARE(int a,int b)
{
    if(a<b)
        return -1;
    if(a==b)
        return 0;
    else
        return 1;
}

int attach(float coe, int exp) {
    terms[avail].coe = coe;
    terms[avail++].exp = exp;
    return 0;
}

int attach_mult(int coe,int exp,int startd)
{
    int i,key;
    if(avail>=MAX_TERMS){
        return -1;
    }
    key=0;
    for(i=startd;i<avail;i++){
        if(terms[i].exp == exp){
            terms[i].coe += coe;
            key=1;
        }
    }
    if(key==0){
        terms[avail].coe = coe;
        terms[avail].exp = exp;
        avail++;
    }
    return 0;
}

void pmult(int starta,int finisha,int startb,int finishb,int *startd,int *finishd)
{
    int coe, exp, i,j;
    *startd=avail;
    
    for(i=starta;i<=finisha;i++)
        for(j=startb;j<=finishb;j++){
            coe = terms[i].coe * terms[j].coe;
            exp = terms[i].exp + terms[j].exp;
            if(coe)
                attach_mult(coe,exp,*startd);
        }
    
    *finishd=avail-1;
}


void readpoly(int *start,int *finish)
{
    int exp,coe;
    *start=avail;
    for(;;){
        scanf("%d",&exp);
        if(exp>=0)
        {
            scanf("%d",&coe);
            terms[avail].exp = exp;
            terms[avail].coe = coe;
            *finish=avail++;
        }
    }
}

void printpoly(int start,int finish){
    while(start<=finish){
        printf("(%f,%d)",terms[start].coe,terms[start].exp);
        start++;
    }
}

int main(void)
{
    int starta,finisha,startb,finishb,startd,finishd;
    
    readpoly(&starta,&finisha);
    printpoly(starta,finisha);
    printf("\n");
    readpoly(&startb,&finishb);
    printpoly(startb,finishb);
    printf("\n");
//    padd(starta,finisha,startb,finishb,&startd,&finishd);
//    printpoly(startd,finishd);
    printf("\n");
    pmult(starta,finisha,startb,finishb,&startd,&finishd);
    printpoly(startd,finishd);
    printf("\n");
    
}
