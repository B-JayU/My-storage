//
//  main.c
//  6-1
//
//  Created by 손명빈 on 2017. 9. 13..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>

#define MAX_STACK_SIZE 100
#define FALSE 0
#define TRUE 1
#define EXIT_COL 15
#define EXIT_ROW 12

typedef struct
{
    short int row; // x
    short int col; // y
    short int dir;
} element;

//행 = row 열 = col

element pop();
element stack[MAX_STACK_SIZE];
void path();
void push(element item);
element stackEmpty();
void stackFull();

int top = -1;
typedef struct {
    short int vert; // x
    short int horiz; // y
} offsets;

offsets move1[8];
    
int mark[100][100];
int maze[100][100];

//horiz = col

int main()
{
    FILE *f;
    
    move1[0].vert = -1;
    move1[0].horiz = 0;
    
    move1[1].vert = -1;
    move1[1].horiz = 1;
    
    move1[2].vert = 0;
    move1[2].horiz = 1;
    
    move1[3].vert = 1;
    move1[3].horiz = 1;
    
    move1[4].vert = 1;
    move1[4].horiz = 0;
    
    move1[5].vert = 1;
    move1[5].horiz = -1;
    
    move1[6].vert = 0;
    move1[6].horiz = -1;
    
    move1[7].vert = -1;
    move1[7].horiz = -1;


    int i,j;
    
    f = fopen("txt.txt","r");
    
    for(i=0; i<100; i++)
    {
        for(j=0; j<100; j++)
        {
            mark[i][j] = 0;
            maze[i][j] = 1;
        }
    }
    
    for(i=1; i<13; i++)
    {
        for(j=1; j<16; j++)
        {
            fscanf(f,"%d",&maze[i][j]);
        }
    }
    
    for(i=1; i<13; i++)
    {
        for(j=1; j<16; j++)
        {
            printf("%d ",maze[i][j]);
        }
        printf("\n");
    }
    
    path();
    
}

void path(void) {
    /* output a path through the maze if such a path exists */ int i, row, col, nextRow, nextCol, dir, found = FALSE; element position;
    mark[1][1] = 1;
    top = -1; position.row=1; position.col=1; position.dir=1;
    push(position);
    top= 0; stack[0].row= 1; stack[0].col =1; stack[0].dir=1;
    
    while (top >= 0 && !found) {
        position= pop();
        row = position.row; col = position.col; dir = position.dir; while (dir < 8 && !found) {
            /* move in direction dir */
            nextRow =row + move1[dir].vert;
            nextCol =col + move1[dir].horiz;
            if (nextRow == EXIT_ROW && nextCol == EXIT_COL)
                found = TRUE;
            else if ( !maze[nextRow][nextCol] && !mark[nextRow][nextCol]) {
                mark[nextRow][nextCol] = 1;
                position.row = row; position.col = col; position.dir = ++dir; push(position);
                row = nextRow; col = nextCol; dir = 0;
            }
            else ++dir; }
    }
    if (found) {
        printf("The path is:\n");
        printf("row col\n");
        for (i = 0; i <= top; i++) printf("%2d%5d\n", stack[i].row, stack[i].col); printf("%2d%5d\n", row, col);
        printf("%2d%5d\n", EXIT_ROW, EXIT_COL);
    } else
        printf("The maze does not have a path\n");
}

//void path()
//{
//    /* output a path through the maze if such a path exists */
//    int i, row = 0, col = 0, nextRow, nextCol, dir, found = FALSE;
//    
//    element position;
//    
//    mark[1][1] = 1;
//    top = -1;
//    
//    position.row=0;
//    position.col=0;
//    position.dir=0;
//
//    push(position);
//    
//    top= 0;
//    
//    stack[0].row = 0;
//    stack[0].col = 0;
//    stack[0].dir = 0;
//    
//    while (top >= 0 && !found)
//    {
//        position= pop();
//        
//        row = position.row;
//        col = position.col;
//        dir = position.dir;
//        
//        while (dir < 8 && !found)
//        {
//            /* move in direction dir */
//            
//            nextRow =row + move1[dir].row;
//            nextCol =col + move1[dir].col;
//            
//            if (nextRow == EXIT_ROW && nextCol == EXIT_COL)
//                found = TRUE;
//            
//            else if ( !maze[nextRow][nextCol] && !mark[nextRow][nextCol])
//            {
//                mark[nextRow][nextCol] = 1;
//                
//                position.row = row;
//                position.col = col;
//                position.dir = ++dir;
//                
//                push(position);
//                
//                row = nextRow;
//                col = nextCol;
//                dir = 0;
//            }
//            else ++dir;
//        }
//    }
//    
//    if (found) {
//        printf("The path is:\n");
//        printf("row col\n");
//        
//        for (i = 0; i <= top; i++)
//            printf("%2d%5d", stack[i].row, stack[i].col);
//        
//        printf("%2d%5d\n", row, col);
//        printf("%2d%5d\n", EXIT_ROW, EXIT_COL);
//    }
//    
//    else
//        printf("The maze does not have a path\n");
//}
//Program 3.12: Maze search function


element pop()
{
    /* delete and return the top element from the stack */
    
    if (top < 0)
        return stackEmpty();
    
    /*returns an error key*/
    
    return stack[top--];
    
    //Program 3.2: Delete from a stack
}

element stackEmpty()
{
    printf("Stack is empty");
    
    element a= {0};
    
    return a;
    
}


void push(element item)
{
    
    /* add an item to the global stack */
    
    if (top >= MAX_STACK_SIZE-1)
        stackFull();
    
    stack[++top] = item;
    
    //Program 3.1: Add an item to a stack
}

void stackFull()
{
    fprintf(stderr, "Stack is full, cannot add element");
    
}

