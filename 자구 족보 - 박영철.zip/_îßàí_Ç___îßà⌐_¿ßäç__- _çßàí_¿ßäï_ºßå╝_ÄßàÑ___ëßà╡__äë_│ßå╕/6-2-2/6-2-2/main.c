//
//  main.c
//  6-2-2
//
//  Created by 손명빈 on 2017. 9. 13..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#define TRUE	1
#define FALSE	0

typedef struct linked_list
{
    int data;
    struct _node * next;
} Node;

typedef struct list_Stack
{
    Node * head;
} ListStack;


typedef ListStack Stack;

void StackInit(Stack * pstack);
int SIsEmpty(Stack * pstack);
void SPush(Stack * pstack, int data);
int SPop(Stack * pstack);
int SPeek(Stack * pstack);


int GetOpPrec(char op);
int WhoPrecOp (char op1,char op2);
void ConvToRPNExp(char exp[]);
int EvalRPNExp(char exp[]);
int EvalInfixExp(char exp[]);

int main()
{
    char exp[20];
    
    scanf("%s",exp);
    
    printf("%s = %d \n",exp, EvalInfixExp(exp));
    
    return 0;
}


int GetOpPrec(char op)
{
    switch(op)
    {
        case '*':
            
        case '/':
            return 5;
            
        case '+':
            
        case '-':
            
        case '%':
            return 3;
            
        case '(':
            return 1;
            
    }
    
    return -1;
}
int WhoPrecOp (char op1,char op2)
{
    int op1Prec = GetOpPrec(op1);
    int op2Prec = GetOpPrec(op2);
    
    if(op1Prec > op2Prec)
        return 1;
    else if (op1Prec < op2Prec)
        return -1;
    else
        return 0;
    
}
void change(char exp[]) //중위 -> 후위표기
{
    unsigned long expLen = strlen(exp);
    
    Stack stack;
    
    char* convExp = (char *) malloc(expLen+ 1);
    int i, idx = 0;
    
    StackInit(&stack);
    memset(convExp, 0, expLen + 1);
    
    for(i=0; i<expLen; i++)
    {
        if (isdigit(exp[i]) == 1)
            convExp[idx++] = exp[i];
        
        else
        {
            switch(exp[i])
            {
                case '(':  //stack에 뭐가 있든 상관 없이 무조건 맨위로 push
                {
                    SPush(&stack,exp[i]);
                    break;
                }
                case ')':  // '(' 여는 소괄호가 나올때 까지 Pop하여 배열에 저장
                {
                    while(!(SPeek(&stack) == '('))
                        convExp[idx++] = SPop(&stack);
                    
                    SPop(&stack);
                    break;
                }
                case'+': case'-': case'*': case'/':case '%': //원래Stack과 우선순위 비교 ->pop&pop...->push
                {
                    while(!SIsEmpty(&stack) && (WhoPrecOp(exp[i],SPeek(&stack)) <= 0)) //맨위보다 우선순위 낮:pop ,같으면 :pop
                        convExp[idx++] = SPop(&stack);
                    SPush(&stack,exp[i]);
                }
                    
            }
        }
    }
    
    while(!SIsEmpty(&stack))
        convExp[idx++] = SPop(&stack);
    
    strcpy(exp, convExp);
}
int EvalRPNExp(char exp[]) // 후위표기법 계산
{
    Stack stack;
    int i,result;
    int num1,num2;
    
    for(i=0; i<strlen(exp); i++)
    {
        if(isdigit(exp[i]))
            SPush(&stack,exp[i] - '0'); //넣을때 문자 -'0' : 숫자 (아스키코드값!!)
        else
        {
            num2 = SPop(&stack);
            num1 = SPop(&stack);
            
            switch(exp[i])
            {
                case '+':
                {
                    SPush(&stack,num1 + num2);
                    break;
                }
                case '-':
                {
                    SPush(&stack,num1 - num2 );
                    break;
                }
                case '/':
                {
                    SPush(&stack,num1 / num2 );
                    break;
                }
                case '*':
                {
                    SPush(&stack,num1 * num2);
                    break;
                }
                case '%':
                {
                    SPush(&stack,num1 % num2);
                    break;
                }
            }
        }
    }
    result = SPop(&stack);
    return result;
}
void StackInit(Stack * pstack)
{
    pstack->head = NULL;
}

int SIsEmpty(Stack * pstack)
{
    if(pstack->head == NULL)
        return TRUE;
    else
        return FALSE;
}

void SPush(Stack * pstack, int data)
{
    Node * newNode = (Node*)malloc(sizeof(Node));
    
    newNode->data = data;
    newNode->next = pstack->head;
    
    pstack->head = newNode;
}

int SPop(Stack * pstack)
{
    int rdata;
    Node * rnode;
    
    if(SIsEmpty(pstack))
    {
        printf("Stack Memory Error!");
        exit(-1);
    }
    
    rdata = pstack->head->data;
    rnode = pstack->head;
    
    pstack->head = pstack->head->next;
    free(rnode);
    
    return rdata;
}

int SPeek(Stack * pstack)
{
    if(SIsEmpty(pstack))
    {
        printf("Stack Memory Error!");
        exit(-1);
    }
    
    return pstack->head->data;
}



//중위표기법 -> 후위표기법 -> 계산 ->return

int EvalInfixExp(char exp[]) //인자로 주어진 문자열이 변경되지 않게
{
    int result;
    char* expcpy = (char*) malloc(sizeof(strlen(exp)+1));
    strcpy(expcpy, exp);
    change(expcpy);
    printf("%s\n",expcpy);
    
    
    result = EvalRPNExp(expcpy);
    free(expcpy);
    return result;
    
}
