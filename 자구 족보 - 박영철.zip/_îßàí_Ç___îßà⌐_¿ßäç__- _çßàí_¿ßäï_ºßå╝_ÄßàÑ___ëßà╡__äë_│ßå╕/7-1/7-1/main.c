//
//  main.c
//  7-1
//
//  Created by 손명빈 on 2017. 9. 18..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#define IS_EMPTY(first) (! (first) )

typedef struct node *nodePointer;

typedef struct node {
    int id;
    char name[20];
    char address[100];
    nodePointer next;
}node;

nodePointer insertNode(nodePointer head, node data);

int main()
{
    nodePointer first = NULL;
    char mode;
    
    
    while(1)
    {
        printf("i(삽입), d(삭제), f(탐색), r(전체 읽기), q(작업종료)를 선택하시오");
        
        scanf("%c",&mode);
        
        if(mode == 'i')
        {
            
        }
        
        if(mode == 'd')
        {
            
        }
        
        if(mode == 'f')
        {
            
        }
        
        if(mode == 'r')
        {
            
        }
        
        if(mode == 'q')
        {
            break;
        }
    }
}

nodePointer insertNode(nodePointer head, node data)
{
    
    
    return data.next;
}















