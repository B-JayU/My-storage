//
//  main.c
//  13-1
//
//  Created by 손명빈 on 2017. 10. 25..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#define FALSE 0
#define TRUE 1
#define MAX_VERTICES 100

typedef struct node *nodepointer;
typedef struct node
{
    int data;
    nodepointer next;
}node;

typedef struct queue *queuePointer;
typedef struct queue {
    int data;
    queuePointer next;
}queue;

void insert(int b, int c);

//void add_queue(int add);
//int delete_queue();
void initialize_queue();

void initialize_visited();

//void process_vertex(int v);

//void bfs(int v);

void dfs(int v);
void dfs2(int v);

short visited[MAX_VERTICES];
queue *front, *rear;
nodepointer root, search;
nodepointer adjlist[100] = {0};

int main()
{
    int a,b,c;
    int i, cnt= 0;
    int max = 0;
    int start;
    
    while(1)
    {
        scanf("%d %d %d", &a, &b, &c);
        
        if(a == -1 || b == -1 || c == -1)
            break;
        
        insert(b,c);
        
        if(b > c)
            max = b;
        
        else
            max = c;
        
        cnt++;
    }
    
    
    for(i=0; i<=max; i++)
    {
        printf("%d ( ",i);
        
        search = adjlist[i];
        
        while(1)
        {
            if(search != NULL)
            printf("%d ",search->data);
            
            if(search == NULL)
                break;

            
            search = search->next;
        }
        printf(")\n");
        
    }
    
    printf("Starting Point를 입력하시오 : ");
    scanf("%d",&start);
    
    printf("DFS(recursive)의 결과: ");
    dfs(start);
    printf("\n");
    dfs2(start);

    
}

void insert(int b, int c)
{
    nodepointer new;
    nodepointer new_rev;
    
    new = (node*)malloc(sizeof(node));
    new_rev = (node*)malloc(sizeof(node));
    
    new->data = c;
    
    if(adjlist[b] == NULL)
    {
        adjlist[b] = new;
    }
    
    else
    {
        search = adjlist[b];
        
        while(search->next != NULL)
        {
            search = search->next;
        }
        
        search->next = new;
    }
    
    new_rev -> data = b;
    
    if(adjlist[c] == NULL)
    {
        adjlist[c] = new_rev;
    }
    
    else
    {
        search = adjlist[c];
        
        while(search->next != NULL)
        {
            search = search -> next;
        }
        
        search->next = new_rev;
    }

}

void dfs(int v)
{
    node *searchh;
    visited[v] = TRUE;
    
    printf("%d ",v);
    
    for (searchh = adjlist[v]; searchh; searchh = searchh->next)
    {
        if (!visited[searchh->data])
            dfs(searchh->data);
    }
}

void dfs2(int v)
{
    int stack[100] = {0};
    int top = -1;
    
    initialize_visited();
    
    stack[++top] = v;
    
    visited[v] = TRUE;
    
    search = adjlist[v];
    
    for(search = adjlist[v]; search!= NULL; )
    {
        printf("%d",v);
        
        if(visited[search->next->data] == FALSE)
        {
            search = adjlist[search->next->data];
            
            visited[search->next->data] = TRUE;
            
            stack[++top] = search->next->data;
            
            stack[top] = v;

        }
        
        else
        {
            search = adjlist[stack[--top]];
            
            search = search->next;
            
            visited[search->data] = TRUE;
            
            v = stack[top];
        }
        
    }
    
    
}

//void bfs(int v)
//{
//    node *searchh;
//    initialize_queue();
//    
//    process_vertex(v);
//    while (front)
//    {
//        v = delete_queue () ;
//        for (searchh = adjlist[v]; searchh; searchh = searchh->next)
//        {
//            if (!visited[searchh->data])
//                process_vertex(searchh->data);
//        }
//    }
//}
//
void initialize_visited()
{
    int x;
    for (x=0; x<MAX_VERTICES; x++)
        visited[x] = FALSE;
}

void initialize_queue()
{
    front = rear = NULL;
}
//
//void process_vertex(int v)
//{
//    printf("%d ",v);
//    visited[v] = TRUE;
//    add_queue(v);
//}
//
//void add_queue(int add)
//{
//    while(1)
//    {
//        
//    }
//}
//int delete_queue();
//
//
//
//
//
//
//
//
//
//
//
//
//
