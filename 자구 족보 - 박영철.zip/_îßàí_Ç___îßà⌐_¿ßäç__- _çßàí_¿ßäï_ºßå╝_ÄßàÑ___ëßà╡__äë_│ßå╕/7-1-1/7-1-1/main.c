//
//  main.c
//  7-1-1
//
//  Created by 손명빈 on 2017. 9. 18..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <string.h>
#define MAX_LIST_SIZE 100
#define IS_EMPTY(first) (first == -1)

typedef struct {
    int id;
    char name[30];
    char address[100];
} element;

typedef struct node
{
    element data;
    int next;
} node;

node emptynode = {0};

node list_array[MAX_LIST_SIZE] = {0};
int avail = -1;
int first = 0;

void insertnode(element data);

int main()
{
    char mode;
    int delete_num=0, find_num=0;
    int i = 0;
    int cur = 0,pre;
    int cnttt = 0;
    int j;
    
    element temp = {0};

    for(j=0; j<MAX_LIST_SIZE; j++)
    {
        list_array[j].next = j+1;
    }
    
    
    while(1)
    {
        mode = 0;
        
        printf("i(삽입), d(삭제), f(탐색), r(전체 읽기), q(작업종료)를 선택하시오\n");
        
        scanf(" %c",&mode);
        
        if(mode == 'i')
        {
            printf("mode i\n");
            
            while(1)
            {
                printf("학번 : ");
                scanf("%d",&temp.id);
                
                  if(temp.id < 0)
                    break;
                
                printf("이름 : ");
                scanf("%*c%s%*c",temp.name);
                
                printf("주소 : ");
                fgets(temp.address,100,stdin);
                
                
                list_array[++avail].data = temp;
//                list_array[avail].next = -1;
                
                //newInsert = list_array[newInsert].next;
                
                cur = first;
                pre = first;
                
                while(list_array[cur].next != -1)
                {
                    cur = list_array[pre].next;
                
                    if(list_array[first].data.id >= temp.id)
                    {
                        first = list_array[avail].next;
                        
                        break;
                    }
                
                    if(list_array[cur].data.id < temp.id)
                    {
                        list_array[avail].next = cur;
                    
                        list_array[pre].next = list_array[avail].next;
                        
                        break;
                    }
                
                    cur = list_array[cur].next;
                
                }
            }

        }

//        if(mode == 'd')
//        {
//            
//            printf("삭제할 자료의 학번을 입력하시오: ");
//            scanf("%d",&delete_num);
//
//              cur = first;
//              
//              while(1)
//              {
//                  cur_next = list_array[cur].next;
//
//                  if(delete_num == list_array[cur_next].data.id)
//                  {
//                      list_array[cur].next = list_array[list_array[cur_next].next].next;
//                      
//                      list_array[cur_next] = emptynode;
//                      
//                      cntt++;
//                      
//                      break;
//                  }
//                  
//              }
//              
//              if(cntt == 0)
//                  printf("삭제할 학번 %d이 존재하지 않음\n",delete_num);
//        
//        }
        
        if(mode == 'f')
        {
            printf("mode f");

            cur = first;
            
            printf("탐색할 자료의 학번을 입력하시오:\n");
            
            scanf("%d",&find_num);

            for(i=0; i<100; i++)
            {
                if(list_array[i].data.id == find_num)
                {
                    printf("%d %s %s\n",list_array[i].data.id, list_array[i].data.name, list_array[i].data.address);
                    
                    cnttt++;
                    break;

                }
                
                
                cur = list_array[cur].next;
                
                if(cnttt == 0)
                {
                    printf("탐색할 자료의 학번 %d이 존재하지 않음\n",find_num);
                    break;
                }
                
            }
        }
        
        if(mode == 'r')
        {
            cur = first;
            
            for(i=0; i<avail; i++)
            {
                printf("%d %s %s",list_array[cur].data.id, list_array[cur].data.name, list_array[cur].data.address);
                
                cur = list_array[cur].next;
            }
        }
        
        if(mode == 'q')
        {
            break;
        }
        
        else
            printf("모드를 다시 입력하세요\n");
    }
    
    return 0;
}





