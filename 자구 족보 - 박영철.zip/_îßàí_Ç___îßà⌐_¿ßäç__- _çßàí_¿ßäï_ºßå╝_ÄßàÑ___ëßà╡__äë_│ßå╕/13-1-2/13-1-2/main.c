//
//  main.c
//  13-1-2
//
//  Created by 손명빈 on 2017. 10. 27..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#define MAX_SIZE 8
#define FALSE 0
#define TRUE 1

typedef struct _node
{
    int vertex;
    struct _node * link;
}node;

node * adjList[MAX_SIZE];
node * front;
node * rear;
node * queue=NULL;
int visitedd[MAX_SIZE];
int visitedb[MAX_SIZE];
int visited[MAX_SIZE];
int visite[MAX_SIZE];

void add_queue(int v){
    node* newq;
    //node * fir;
    
    newq = (node *)malloc(sizeof(node));
    newq->vertex = v;
    newq->link = NULL;
    
    if(queue == NULL)
    {
        queue = newq;
        front = queue;
        
    }
    else{
        if(front == NULL)
            front = queue;
        queue->link = newq;
        queue = queue->link;
    }
    rear = queue;
}
int delete_queue(){
    int v;
    
    if(front == NULL){//add가 된 적 없을 때
        return -1;
    }
    else{
        v = front->vertex;
        front = front->link;
        return v;
    }
}
void initialize_queue() {
    front = NULL;
    rear = NULL;
}

void initialize_visited(){
    int x;
    for (x=0; x<MAX_SIZE; x++)
    {
        visited[x] = FALSE;
        visite[x] = FALSE;
    }
    
}

void connectList(int f, int t)
{
    node * newnode;
    node * cur = adjList[f];
    
    newnode = (node*)malloc(sizeof(node));
    newnode->vertex = t;
    
    if(adjList[f] == NULL) adjList[f] = newnode;
    else{
        while(cur->link != NULL)
        {
            cur = cur->link;
        }
        cur->link = newnode;
    }
}

void makeList(){
    printf("edge vertex vertex(exit : -1)\n");
    
    int i;
    int fromVertex, toVertex;
    
    while(1){
        scanf("%d %d %d",&i,&fromVertex,&toVertex);
        getchar();
        if(i == -1) break;
        else{
            connectList(fromVertex,toVertex);
            connectList(toVertex, fromVertex);
        }
    }
}

void printList(){
    int i;
    node * cur;
    
    for(i=0;i<MAX_SIZE;i++){
        cur = adjList[i];
        printf("%d(",i);
        while(cur != NULL){
            printf("%d",cur->vertex);
            cur = cur->link;
            if(cur != NULL)printf(",");
        }
        printf(")\n");
    }
    
}
void initialize_Visited()
{
    int x;
    for (x=0; x<MAX_SIZE; x++){
        visited[x] = FALSE;
        visite[x] = FALSE;
    }
}

void process_vertex(int v) {
    printf("%d ",v);
    visited[v] = TRUE;
    //visite[v] = TRUE;
    add_queue(v);
}

void dfsr(int v)
{
    node *search;
    visitedd[v] = TRUE;
    printf("%d ",v);
    
    for (search = adjList[v]; search; search = search->link)
    {
        if ( !visitedd[search->vertex])
            dfsr(search->vertex);
    }
}

void dfsi(int v)
{
    node *search;
    node * temp = NULL;
    
    printf("%d ",v);
    queue = NULL;
    initialize_queue();
    visited[v] = TRUE;
    search = adjList[v];
    
    while(search)
    {
        
        if(!visited[search->vertex])
        {
            visited[search->vertex] = TRUE;
            process_vertex(search->vertex);
            temp = search;
            search = adjList[search->vertex];
        }
        else
        {
            search = search->link;
            
            if(search == NULL)
            {
                search = temp->link;
            }
        }
    }
}

void bfsr(int v)
{
    node *search = adjList[v];
    
    if(visitedb[v] == TRUE)
    {
        return ;
    }
    visitedb[v] = TRUE;
    printf("%d ",v);
    
    for (search = adjList[v]; search; search = search->link)
    {
        if (!visitedb[search->vertex])
            add_queue(search->vertex);
    }
    if(front)
    {
        v = delete_queue();
        bfsr(v);
    }
}
void process_vertex2(int v){
    printf("%d ",v);
    visite[v] = TRUE;
    add_queue(v);
}

void bfsi(int v){
    node *search;
    
    initialize_queue();
    process_vertex2(v);
    while (visite[7] != 1) {
        v = delete_queue () ;
        for (search = adjList[v]; search; search = search->link) {
            if (!visite[search->vertex]) process_vertex2(search->vertex);
        }
    }
}

int main(void){
    int v;
    
    makeList();
    printList();
    
    printf("Put Starting Vertex : ");
    scanf("%d",&v);
    printf("Result of DFS(recursive version) : ");
    dfsr(v);
    printf("\nResult of DFS(iterative version) : ");
    dfsi(v);
    printf("\nResult of BFS(recursive version) : ");
    queue = NULL;
    initialize_queue();
    bfsr(v);
    printf("\nResult of BFS(iterative version) : ");
    queue = NULL;
    bfsi(v);
    printf("\n");
}
