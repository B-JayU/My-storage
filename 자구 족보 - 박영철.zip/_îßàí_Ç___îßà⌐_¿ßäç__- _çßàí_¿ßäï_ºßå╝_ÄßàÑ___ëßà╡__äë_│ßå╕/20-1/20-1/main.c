//
//  main.c
//  20-1
//
//  Created by 손명빈 on 2017. 11. 22..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define SWAP(x, y, t) ((t) = (x), (x) = (y), (y) = (t))


typedef struct node* nodepointer;
typedef struct node
{
    int bucket[2];
    int ld;
}node;

int get_index(int key);
int get_mask();
void init_ht();
void makehash(int idx, int data);
void extendhash(int idx);
void printbin(int fish);
void SelectionSort(int arr[], int size);

nodepointer* ht;
int size = 4;
int gd;

int main()
{
    char ch;
    int find,i;
    
    gd = 2;
    
    ht = (nodepointer*)malloc(sizeof(nodepointer)*size);
    
    for(i=0; i<pow(2,gd); i++)
    {
        ht[i] = (node*)malloc(sizeof(node));
    }
    
    init_ht();
    
    while(1)
    {
        printf("\n모드를 입력하시오 삽입:i 삭제:d 전체 출력:a\n");
        
        scanf("%c%*c",&ch);
        
        switch(ch)
        {
            case 'i':
            {
                printf("삽입할 숫자 입력(종료시 -1)\n");
                while(1)
                {
                
                    scanf("%d%*c",&find);
                
                    if(find == -1)
                        break;
                
                    makehash(get_index(find), find);
                }

                break;
            }
                
            case 'd':
            {
                printf("삭제할 학생 성명 입력: ");
                
                scanf("%d%*c",&find);
                

            }
                
           case 'a':
            {

                    for(i=0; i<pow(2,gd); i++)
                    {
                        printf("entry : ");
                        printbin(ht[i]->bucket[0]);
                        printf(" bucket: %d %d\n",ht[i]->bucket[0],ht[i]->bucket[1]);
                    }
                
                break;
            }
                
            default:
            {
                printf("\n모드를 다시 입력하세요!\n");
                
                break;
            }
        }
        
    }

}


int get_index(int key)
{
    int index, mask;
    
    mask = get_mask();
    
    index = key&mask;
    
    return index;
}

int get_mask()
{
    int mask = 0x01;
    int count;
    
    for(count = 1; count < gd; count++)
        mask = (mask << 1) + 0x01;
    
    return mask;
}

void init_ht()
{
    int i,j;
    
    for(i=0; i<pow(2,gd); i++)
    {
        for(j=0; j<2; j++)
        {
            ht[i]->bucket[j] = -1;
            ht[i]->ld = 2;
        }
    }
}

void makehash(int idx, int data)
{
    nodepointer sortarea[100] = {NULL};
    int temp[100];
    int cnt = 0;
    int i;
    
    for(i=0; i<100; i++)
    {
        temp[i] = -1;
    }
    
    printf("%d %d\n",ht[idx]->bucket[0],ht[idx]->bucket[1]);
    
    if(ht[idx]->bucket[0] == -1)
        ht[idx]->bucket[0] = data;

    
    else if(ht[idx]->bucket[1] == -1)
        ht[idx]->bucket[1] = data;
    
    
    else
    {
        temp[cnt++] = ht[idx]->bucket[0];
        temp[cnt++] = ht[idx]->bucket[1];
        temp[cnt++] = data;
        
        ht[idx]->bucket[0] = -1;
        ht[idx]->bucket[1] = -1;
        
        SelectionSort(temp, cnt-1);
        
        //if()
        {
            
        }
        
        //else
        {
            gd++;
        
            ht[idx]->ld = gd;
            extendhash(idx);
        
            ht[idx+(int)pow(2,gd-1)]->ld = gd;
        
            makehash(get_index(data),data);
        }
        
    }
    
}

void extendhash(int idx)
{
    int i;
    
    size*=2;
    ht = (nodepointer*)realloc(ht, size*(sizeof(nodepointer)));
    
    for(i=pow(2,gd-1); i<pow(2,gd); i++)
    {
        
        
        if(i == idx+(int)pow(2,gd-1))
        {
            ht[i] = ht[(int)(i-pow(2,gd-1))];
        }
        
        else
        {
            ht[i] = (node*)malloc(sizeof(node));
            ht[i]->bucket[0] = -1;
            ht[i]->bucket[1] = -1;
        }

    }
    
    
}

void printbin(int fish)
{
    int i;
    
    for (i=gd-1; i >= 0; --i)
    {
        printf("%d", (fish >> i) & 1);
    }
}

void SelectionSort(int arr[], int size)
{
    int minidx;
    int temp;
    
    for (int i = 0; i < size - 1; i++)
    {
        minidx = i;
        for (int j = i + 1; j < size; j++)
        {
            if (arr[minidx] > arr[j])
                minidx = j;
        }
        SWAP(arr[i], arr[minidx], temp);
    }
}


















