//
//  main.c
//  5-3
//
//  Created by 손명빈 on 2017. 9. 11..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>

#define MAX_QUEUE_SIZE 100
typedef struct element
{
    int id;
    char name[100];
    char adress[100];
} element;

void addq(element item);
element deleteq();
element queueEmpty();
void queueFull();
void copy(element* a, element* b, element* newQueue);

int front = 0;
int rear = 0;

element queue[MAX_QUEUE_SIZE];

int main()
{
    element temp;
    int cnt=0;
    int i;
    
    while(cnt != 8)
    {
        
        scanf("%d",&temp.id);
        scanf("%s",temp.name);
        fgets(temp.adress,100,stdin);
        
        addq(temp);
        
        cnt++;
    }
    
    printf("\n1번문제\n");
    
    
    for(i=front+1; i<rear; i++)
    {
        printf("<%d,%s,%s>\n",queue[i].id,queue[i].name,queue[i].adress);
    }
    
    printf("\n2번문제\n");
    
    
    for(i=0; i<3; i++)
    {
        printf("<%d,%s,%s>\n", queue[front+1].id, queue[front+1].name, queue[front+1].adress);
        
        deleteq();
    }
    
    printf("\n3번문제\n");
    
    for(i=0; i<4; i++)
    {
        scanf("%d",&temp.id);
        scanf("%s",temp.name);
        fgets(temp.adress,100,stdin);
        
        addq(temp);
    }
    
    for(i=front+1; i<rear; i++)
    {
        printf("<%d,%s,%s>\n",queue[i].id,queue[i].name,queue[i].adress);
    }
    
    printf("\n4번문제\n");
    
    for(i=0; i<6; i++)
    {
        printf("<%d,%s,%s>\n", queue[front+1].id, queue[front+1].name, queue[front+1].adress);
        
        deleteq();
    }
    
    printf("\n5번문제\n");
    
    for(i=front+1; i<rear; i++)
    {
        printf("<%d,%s,%s>\n",queue[i].id,queue[i].name,queue[i].adress);
    }
    
}

void addq(element item)
{
    /* add an item to the queue */
    rear = (rear+1) % MAX_QUEUE_SIZE;
    
    if (front == rear)
        queueFull();
    /*print error and exit*/
    queue[rear] = item; }

element deleteq()
{
    /* remove front element from the queue */
    element item;
    
    if (front == rear)
        return queueEmpty(); /* return an error key*/
    
    front = (front+1) % MAX_QUEUE_SIZE;
    
    return queue[front];
}

element queueEmpty()
{
    printf("Queue if empty");
    
    element el = {0};
    
    return el;
}

void queueFull()
{
    printf("Queue is full");
}

//void queueFull()
//{
//    /* allocate an array with twice the capacity */
//    
//    element* newQueue;
//    newQueue = (element *)malloc(2*capacity*sizeof(element)); /* copy from queue to newQueue */
//    int start = (front+1) % capacity;
//    if (start <= 1)
//    {
//        /* 좌로밀착 */
//        
//        copy(queue+start, queue+start+capacity-1, newQueue);
//    }
//    
//    else {/* queue wraps around */
//        
//            copy(queue+start, queue+capacity, newQueue);
//            copy(queue, queue+rear+1, newQueue+capacity-start);
//    }
//    
//    /* switch to newQueue */
//    front = 2 * capacity - 1;
//    rear = capacity - 2;
//    capacity *= 2;
//    free (queue);
//    
//    queue = newQueue;
//}
//
//void copy(element* a, element* b, element* c)
//{
//    
//}






