//
//  main.c
//  12-1 txt파일 생성
//
//  Created by 손명빈 on 2017. 10. 23..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>

int main()
{
    int i,j;
    int x = 0;
    
    
    FILE *f;
    
    f = fopen("txt.txt","w");
    
    while(1)
    {
        if(x > 100)
            break;
        
        for(i=0; i<8; i++)
        {
            
            if(x > 100)
                break;
            
            fprintf(f,"%d ",x);
            x++;

        }
        fprintf(f,"\n");
        
        x+=7;
        
        for(j=0; j<8; j++)
        {
            if(x > 100)
                break;
            
            fprintf(f,"%d ",x);
            x--;

        }
        
        fprintf(f,"\n");

        x+=9;
        
        
    }
    
    fclose(f);
    
    
}
