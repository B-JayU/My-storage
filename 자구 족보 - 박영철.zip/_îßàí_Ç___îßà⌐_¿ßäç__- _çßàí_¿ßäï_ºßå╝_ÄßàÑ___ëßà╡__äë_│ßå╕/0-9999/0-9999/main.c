//
//  main.c
//  0-9999
//
//  Created by 손명빈 on 2017. 9. 25..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    // insert code here...
    printf("Hello, World!\n");
    return 0;
}
