//
//  main.c
//  5-2
//
//  Created by 손명빈 on 2017. 9. 11..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>

#define MAX_QUEUE_SIZE 100 

typedef struct element
{
    int id;
    char name[100];
    char adress[100];
} element;

element queueEmpty();
void addq(element item);
element deleteq();
void queueFull();


element queue[MAX_QUEUE_SIZE];

int front = -1;
int rear = -1;

int main()
{
    element temp;
    int cnt=0;
    int i;
    
    while(cnt != 8)
    {
        
        scanf("%d",&temp.id);
        scanf("%s",temp.name);
        fgets(temp.adress,100,stdin);
        
        addq(temp);
        
        cnt++;
    }
    
    printf("\n1번문제\n");
    
    
    for(i=0; i<8; i++)
    {
        printf("<%d,%s,%s>\n",queue[i].id,queue[i].name,queue[i].adress);
    }
    
    printf("\n2번문제\n");
    
    
    for(i=0; i<3; i++)
    {
        printf("<%d,%s,%s>\n", queue[front].id, queue[front].name, queue[front].adress);
        
        deleteq();
    }
    
    printf("\n3번문제\n");
    
    for(i=0; i<4; i++)
    {
        scanf("%d",&temp.id);
        scanf("%s",temp.name);
        fgets(temp.adress,100,stdin);
        
        addq(temp);
    }
    
    for(i=0; i<9; i++)
    {
        printf("<%d,%s,%s>\n",queue[i].id,queue[i].name,queue[i].adress);
    }
    
    printf("\n4번문제\n");
    
    for(i=0; i<6; i++)
    {
        printf("<%d,%s,%s>\n", queue[front].id, queue[front].name, queue[front].adress);
        
        deleteq();
    }
    
    printf("\n5번문제\n");
    
    for(i=0; i<3; i++)
    {
        printf("<%d,%s,%s>\n",queue[i].id,queue[i].name,queue[i].adress);
    }
    
}

void addq(element item)
{
    /* add an item to the queue */
    if (rear >= MAX_QUEUE_SIZE-1)
        queueFull();
    queue[++rear] = item;
}

//Program 3.5: Add to a queue

element deleteq()
{
    /* remove element at the front of the queue */
    if (front == rear)
        return queueEmpty();
    /*return an error key*/ return queue[++front];
}

void queueFull()
{
    printf("Queue is full");
}

element queueEmpty()
{
    printf("Queue if empty");
    
    element el = {0};
    
    return el;
}



