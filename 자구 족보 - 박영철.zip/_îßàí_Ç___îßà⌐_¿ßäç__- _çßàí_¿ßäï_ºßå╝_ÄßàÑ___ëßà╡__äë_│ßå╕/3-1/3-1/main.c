//
//  main.c
//  3-1
//
//  Created by 손명빈 on 2017. 9. 4..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>


void padd(int startA, int finishA, int startB, int finishB, int *startD, int *finishD)
{/* add A(x) and B(x) to obtain D(x) */
    float coefficient;
    
    *startD = avail;
    
    while (startA <= finishA && startB <= finishB)
    {
        switch(COMPARE(terms[startA].expon, terms[startB].expon))
        {
            case -1:
                /* a expon < b expon */
                attach(terms[startB] .coef,terms[startB] .expon); startB++;
                break;
                
            case 0:
                /* equal exponents */
                coefficient= terms[startA] .coef + terms[startB] .coef; if (coefficient) attach(coefficient,terms[startA].expon);
                
                startA++;
                startB++;
                break;
                
            case 1:
                /* a expon > b expon */ attach(terms[startA].coef,terms[startA].expon); startA++;
        }
    }
    /* add in remaining terms of A(x) */
    for(; startA <= finishA; startA++)
        attach(terms[startA].coef,terms[startA].expon); /* add in remaining terms of B(x) */
    
    for( ; startB <= finishB; startB++)
        attach(terms[startB].coef, terms[startB].expon);
    
    *finishD = avail-1;
}
