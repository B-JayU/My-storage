//
//  main.c
//  19-1
//
//  Created by 손명빈 on 2017. 11. 20..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#define MAX_SIZE 7

typedef struct hash * hashPointer;

typedef struct hash
{
    int data;
    hashPointer next;
}hash;

void inserthash(hash* ht, int data);
void selecthash(int idx, hash* ht, int data);
void printList (hash *head);
void findList(hash *head, int data);
int find_num(hash *ht, int n);
void delete_hash(hash* ht, int n);

int main()
{
    int i,temp;
    hash ht[7];
    int find;
    
    for(i=0; i<7; i++)
    {
        ht[i].next = NULL;
        ht[i].data = 0;
    }
    
    printf("입력하시오(종료 시 -1 입력) :\n");
    
    while(1)
    {
        scanf("%d",&temp);
        
        if(temp == -1)
        {
            break;
        }
        
        inserthash(ht, temp);
        
    }
    
    for(i=0; i<7; i++)
    {
        printf("Ht[%d] : ",i);
        
        printList(&ht[i]);
        
        printf("\n");
    }
    
    
    while(1)
    {
        printf("탐색할 수(종료 시 -1): \n");
    
        scanf("%d",&find);
        
        if(find == -1)
            break;
    
        find_num(ht, find);
    }
    
    while(1)
    {
        printf("삭제할 수(종료 시 -1): \n");
        
        scanf("%d",&find);
        
        if(find == -1)
            break;
        
        delete_hash(ht, find);
    }
    
    
}

void inserthash(hash* ht, int data)
{
    int nmg;
    
    nmg = data % 7;

    selecthash(nmg, ht, data);
}

void selecthash(int idx, hash* ht, int data)
{
    hash *cur,*new;
    
    new = (hash*)malloc(sizeof(hash));
    
    new->data = data;
    new->next = NULL;
    
    cur = &ht[idx];
    
    while(cur->next != NULL)
    {
        cur = cur->next;
    }
    
    cur->next = new;
    
}

void printList (hash *head)
{
    hash *p;
    
    p=head;
    
    while(p!=NULL)
    {
        if(p->data != 0)
            printf("%d", p->data);
        
        if(p->next!=NULL)
            printf(" ");
        p=p->next;
    }
}

void findList(hash *head, int data)
{
    hash *p;
    
    p=head;
    
    while(p!=NULL)
    {
        if(p->data != 0)
            printf("%d", p->data);
        
        if(p->next!=NULL)
            printf(" ");
        p=p->next;
    }
}

int find_num(hash *ht, int n)
{
    hashPointer search;
    int cnt = 0;
    
    int i, r = 0; //없음
    for (i = 0; i < MAX_SIZE; i++)
    {
        search = &ht[i];
        while (search != NULL)
        {
            cnt++;
            
            if (search->data == n)
            {
                r = 1; //있음
                break;
            }
            
            if(r == 1)
                break;
            
            search = search->next;
        }
    }
    
    if(r == 0)
        printf("%d는 ht의 %d 엔트리의 레코드 %d 입니다",n,i,cnt);
    
    else
        printf("%d는 hash table에 존재하지 않습니다",n);
    
    return r;
}

void delete_hash(hash* ht, int n)
{
    int i, result;
    hashPointer search;
    hashPointer prev;
    hashPointer temp;
    result = find_num(ht, n);
    
    if (result == 0)
        printf("%d을 hash table에 존재하지 않습니다.\n", n);
    
    else
    {
        //find_hash(n);
        //printf("삭제합니다.\n");
        for (i = 0; i < MAX_SIZE; i++)
        {
            
            search = &ht[i];
            prev = search;
            while (search != NULL)
            {
                if (search->data == n)
                {
                    if (search->next == NULL)
                        ht[i].next = NULL;
                    
                    temp = search->next;
                    prev->next = temp;
                    break;
                    
                }
                prev = search;
                search = search->next;
            }
        }
    }
}





















