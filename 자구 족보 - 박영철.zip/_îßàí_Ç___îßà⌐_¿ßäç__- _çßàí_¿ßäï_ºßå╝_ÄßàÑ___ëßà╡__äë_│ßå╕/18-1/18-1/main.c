//
//  main.c
//  18-1
//
//  Created by 손명빈 on 2017. 11. 8..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#define INT_NUM 2000000

#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *f,*fname;
    FILE *ff[200];
    int i,j;
    char dataname[50];
    int temp;
    
    
    fname = fopen("fname.txt","w");
    
    for(i=1; i<=200; i++)
    {
        fprintf(fname,"temp");
        fprintf(fname,"%d\n",i);
    }
    
    fclose(fname);
    
    f = fopen("origin.txt","w");
    fname = fopen("fname.txt","r");

    for(i=1; i<=INT_NUM; i++)
    {
        fprintf(f,"%d ",rand()%INT_NUM);
    }
    
    for(i=0; i<200; i++)
    {
        fscanf(fname,"%s",dataname);
        ff[i] = fopen(dataname,"w");
        
        for(j=0; j<10000; j++)
        {
            fscanf(f,"%d",&temp);
            
            fprintf(ff[i],"%d ",temp);
        }
    }
    
    fclose(f);
    fclose(fname);

}
