//
//  main.c
//  8-2-2
//
//  Created by 손명빈 on 2017. 9. 22..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define IS_EMPTY(first) (!(frist))

typedef struct
{
    int id;
    char name[20];
    char address[100];
} element;

typedef struct node *nodePointer;

typedef struct node
{
    element data;
    nodePointer prev;
    nodePointer next;
} node;

nodePointer first = NULL;

nodePointer  find_prev_node(nodePointer first, nodePointer current)
{
    nodePointer  prev, idx;
    prev = NULL;
    idx = first;
    while (1)
    {
        if (idx == NULL) break;
        if (idx->data.id > current->data.id)
            break;
        prev = idx;
        idx = idx->next;
    }
    return prev;
}

void insert(element item)
{
    nodePointer search, current;
    
    current = (nodePointer)malloc(sizeof(node));
    current->data = item;
    current->prev = NULL;
    current->next = NULL;
    
    search = find_prev_node(first, current);
    
    if (first == NULL)
        first = current;
    //search = current;
    
    else
    {
        if (first->data.id <= current->data.id)
        {
            if (first->next == NULL)
            {
                search->next = current;
                current->prev = search;
            }
            
            else
            {
                current->next = search->next;
                search->next->prev = current;
                search->next = current;
                current->prev = search;
            }
        }
        
        else // first->data.id > cuurent->data.id : search = NULL
        {
            first->prev = current;
            current->next = first;
            first = current;
        }
    }
}

void input()
{
    element item;
    char str[100];
    char* ptoken;
    
    while (1)
    {
        printf("삽입할 자료(학번, 이름, 주소) 를 입력하시오: ");
        
        fgets(str, 100, stdin);
        
        if (feof(stdin))   break;
        
        ptoken = strtok(str, " ");
        item.id = atoi(ptoken);
        
        ptoken = strtok(NULL, " ");
        strcpy(item.name, ptoken);
        
        ptoken = strtok(NULL, "\n");
        strcpy(item.address, ptoken);
        
        /*
         scanf("%d", &item.id);
         
         if (feof(stdin))   break;
         
         scanf("%s", item.name);
         */
        
        /*
         if (scanf("%d %s", &item.id, item.name) == EOF)
         break;
         */
        
        
        //gets(item.address);
        
        insert(item);
        
    }
}

void delete()
{
    nodePointer search;
    search = first;
    int num;
    
    printf("삭제할 자료의 학번을 입력하시오 : ");
    scanf("%d", &num);
    
    while (search->next != NULL)
    {
        if (search->data.id == num)
        {
            if (search == first) //맨 앞 숫자 지울 때
            {
                printf("<학번, 이름, 주소> = <%d %s %s>이 삭제되었습니다.\n", search->data.id, search->data.name, search->data.address);
                first = search->next;
                search->next->prev = NULL;
                free(search);
                break;
            }
            
            else
            {
                printf("<학번, 이름, 주소> = <%d %s %s>이 삭제되었습니다.\n", search->data.id, search->data.name, search->data.address);
                search->prev->next = search->next;
                search->next->prev = search->prev;
                free(search);
                break;
            }
        }
        
        else
        {
            search = search->next;
            if (search->data.id != num)
            {
                printf("<학번, 이름, 주소> = <%d, null, null>\n", num);
                break;
            }
        }
    }
}

void read1()
{
    nodePointer head;
    head = first;
    
    while (head != NULL)
    {
        printf("<학번, 이름, 주소> : ");
        printf("<");
        printf("%d %s %s", head->data.id, head->data.name, head->data.address);
        printf(">");
        printf("\n");
        head = head->next;
    }
}
void find()
{
    nodePointer head;
    head = first;
    int num;
    
    printf("탐색할 자료의 학번을 입력하시오. : ");
    scanf("%d", &num);
    
    while (1)
    {
        if (head->data.id == num)
        {
            printf("<학번, 이름, 주소> = <%d, %s, %s>\n", num, head->data.name, head->data.address);
            break;
        }
        else
            head = head->next;
    }
}
int main(void)
{
    char n;
    
    while (1)
    {
        printf("i(삽입), d(삭제), f(탐색), r(전체읽기), q(작업종료)를 선택하시오: ");
        
        scanf("c%c", &n);
        while (getchar() != '\n');
        
        switch (n)
        {
            case 'i':
                input();
                break;
                
            case 'd':
                delete();
                while (getchar() != '\n');
                break;
            case 'r':
                read1();
                break;
            case 'f':
                find();
                while (getchar() != '\n');
                break;
            case 'q':
                exit(0);
            default : printf("다시 입력하시오");
        }
    }
}
