//
//  main.c
//  19-3
//
//  Created by 손명빈 on 2017. 11. 20..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_SIZE 13

typedef struct
{
    int idx;
    int key;
    char name[30];
    char address[30];
} element;

typedef struct node *nodepointer;
typedef struct node
{
    element data;
    nodepointer next;
}node;

void make_hash(element k);
int find_name(char* name, int pri);
void delete_hash(char* find);
void find_hash(int n);

nodepointer ht[MAX_SIZE];

int main()
{
    FILE *f;
    int i;
    char temp[100];
    char ch;
    
    element new;
    char find[100];
    
    nodepointer search;
    
    search = (nodepointer)malloc(sizeof(element));
    
    f = fopen("data.txt","r");
    
    while(!feof(f))
    {
        fgets(temp, 100, f);
        printf("%s",temp);
    }
    
    fclose(f);
    f = fopen("data.txt","r");
    
    for(i=0; i<40; i++)
    {
        fscanf(f,"%s",new.address);
        fscanf(f,"%d",&new.key);
        fscanf(f,"%s",new.name);
        new.idx = i;
        
        make_hash(new);
    }
    
    while(1)
    {
        
        printf("\n모드를 입력하시오 탐색:f 삭제:d 전체 출력:a\n");
        
        scanf("%c%*c",&ch);
        
        switch(ch)
        {
            case 'f':
            {
                printf("탐색할 학생 성명 입력: ");
                
                scanf("%s%*c",find);
                
                find_name(find, 1);
                
                break;
            }
                
            case 'd':
            {
                printf("삭제할 학생 성명 입력: ");
                
                scanf("%s%*c",find);
                
                delete_hash(find);
                
                break;
            }
                
            case 'a':
            {
                for (i = 0; i < MAX_SIZE; i++)
                {
                    search = ht[i];
                    
                    while (search != NULL)
                    {
                        printf("학생정보 인덱스 : %d\t<%s %d %s>\n",search->data.idx, search->data.address, search->data.key, search->data.name);
                        search = search -> next;
                    }
                }
                
                break;
            }
                
            default:
            {
                printf("\n모드를 다시 입력하세요!\n");
                
                break;
            }
        }
        
    }
    
    
}

void make_hash(element k)
{
    int i = k.key % MAX_SIZE;
    
    nodepointer temp;
    nodepointer search;
    
    temp = (nodepointer)malloc(sizeof(element));
    search = (nodepointer)malloc(sizeof(element));
    
    temp->data = k;
    temp->next = NULL;
    
    if (ht[i] == NULL)
    {
        ht[i] = temp;
    }
    
    else
    {
        search = ht[i];
        
        while (search->next != NULL)
        {
            search = search->next;
        }
        
        search->next = temp;
    }
}

int find_name(char* name, int pri)
{
    nodepointer search;
    
    int i, count;
    int temp = 0;
    
    for (i = 0; i < MAX_SIZE; i++)
    {
        search = ht[i];
        count = 1;
        
        while (search != NULL)
        {
            if (strcmp(search->data.name, name) == 0 && pri == 1)
            {
                printf("학생정보 : index = %d <%s,%d,%s>\n",search->data.idx, search->data.address, search->data.key, search->data.name);
                temp++;
                break;
            }
            count++;
            search = search -> next;
        }
    }
    
    if (temp == 0 && i == 13 && pri == 1)
    {
        printf("%s이(가) hash table에 존재하지 않습니다.\n", name);
        return 0;
    }
    
    return 1;
    
}

void delete_hash(char* find)
{
    int i, result;
    nodepointer search;
    nodepointer prev;
    
    result = find_name(find, 1);
    
    
    
    
    search = (node*)malloc(sizeof(node));
    
    if (result == 0)
        return;
    
    else
    {
        printf("삭제합니다.\n");
        
        for (i = 0; i < MAX_SIZE; i++)
        {
            search = ht[i];
            prev = search;
            
            while (1)
            {
                
                if (strcmp(search->data.name, find) == 0)
                {
                    if (search->next == NULL)
                    {
                        if(search == ht[i]) //case1 : ht에서 첫번째 자료이며 마지막 자료
                        {
                            ht[i] = NULL;
                            free(search);
                            break;
                        }
                        
                        else //case2 : ht에서 첫번째 자료는 아니고 마지막 자료
                        {
                            prev->next = NULL;
                            free(search);
                            break;
                        }
                    }
                    
                    else
                    {
                        if(search == ht[i]) //case3 : ht에서 첫번째 자료이며 마지막 자료는 아님
                        {
                            ht[i] = search->next;
                            free(search);
                            break;
                        }
                        
                        else //case4 : ht에서 첫번째 자료도 아니고 마지막 자료도 아님
                        {
                            prev->next = search->next;
                            free(search);
                            break;
                        }
                    }
                    
                    
                }
                
                prev = search;
                
                search = search->next;
                
                if(search == NULL)
                    break;
                
            }
        }
    }
}

void find_hash(int n)
{
    nodepointer search;
    
    int i, count;
    int temp = 0;
    
    for (i = 0; i < MAX_SIZE; i++)
    {
        search = ht[i];
        count = 1;
        
        while (search != NULL)
        {
            if (search->data.key == n)
            {
                printf("%d은 hash table의 %d번째 엔트리의 레코드 %d입니다.\n", n, i, count);
                temp++;
                break;
            }
            count++;
            search = search -> next;
        }
    }
    
    if (temp == 0 && i == 7)
        printf("%d이(가) hash table이 존재하지 않습니다.\n", n);
    
}
