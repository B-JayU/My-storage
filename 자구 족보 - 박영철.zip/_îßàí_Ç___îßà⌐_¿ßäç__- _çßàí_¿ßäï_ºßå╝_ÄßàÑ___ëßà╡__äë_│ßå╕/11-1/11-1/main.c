//
//  main.c
//  11-1
//
//  Created by 손명빈 on 2017. 10. 11..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>

typedef struct data
{
    int id;
    char name[30];
    char address[100];
}element;

typedef struct node
{
    element data;
    struct node* rightChild;
    struct node* leftChild;
}node;

void insertBST(node **rootPtr, element x);
int searchParent(node *root, int key, node **parentPtr);
int deleteBST(node **rootPtr, int key);
int searchParentTargetToDelete(node *root, int k);
void searchSmallestAmongLargerNodes(node *target, int k, node **parentSmallPtr, node **smallPtr);
void cPrint(node* parent);
void inorder(node* ptr);

node* rootPtr = NULL;
node* parentPtr = NULL;
node* searchPtr = NULL;

int main()
{
    char select,e;
    element data;
    int findc, findf,findd,delete_id;
    int found = 0;
    
    while(1)
    {
        printf("i(삽입), d(삭제), f(탐색), r(전체 읽기), c(자식들 읽기), q(작업종료)를 선택하시오: \n");
        
        scanf("%c%*c",&select);
        
        switch(select)
        {
                
            case 'i':
            {
                printf("삽입할 자료(학번, 이름, 주소)를 입력하시오(종료 시 -1 입력): \n");

                while(1)
                {
                    scanf("%d",&data.id);
                    
                    if(data.id == -1)
                    {
                        scanf("%c",&e);
                        break;
                    }
                    
                    scanf("%s",data.name);
                    fgets(data.address,sizeof(data.address),stdin);
                    
                    insertBST(&rootPtr, data);
                }
                break;
            }
                
            case 'd':
            {
                printf("삭제할 자료의 학번을 입력하시오: \n");
                scanf("%d%*c",&delete_id);
                
                found = searchParentTargetToDelete(rootPtr, delete_id);

                if(found == 0)
                {
                    printf("자료를 찾을 수 없습니다\n");
                }
                
                else
                    deleteBST(&rootPtr, delete_id);
                
                break;
            }
                
            case 'f':
            {
                printf("탐색할 자료의 학번을 입력하시오: \n");
                scanf("%d%*c",&findf);
                
                found = searchParent(rootPtr, findf, &parentPtr);
                
                if(found == 0)
                    printf("자료를 찾을 수 없습니다\n");
                
                else
                    printf("%d %s %s", searchPtr->data.id, searchPtr->data.name, searchPtr->data.address);
            
                break;
            }
                
            case 'c':
            {
                printf("탐색할 자료의 학번을 입력하시오: \n");
                scanf("%d%*c",&findc);
                
                found = searchParent(rootPtr, findc, &parentPtr);
                
                if(found == 0)
                    printf("자료를 찾을 수 없습니다\n");
                
                else
                {
                    if(parentPtr == NULL)
                    {
                        printf("오른쪽 자식: 없음\n왼쪽 자식: 없음\n");
                    }
                    
                    else
                        cPrint(searchPtr);
                }
                
                break;
            }
                
            case'r' :
            {
                inorder(rootPtr);
                break;
            }
                
            case 'q' :
            {
                exit(EXIT_SUCCESS);
            }
                
            default :
            {
                printf("다시 입력하세요\n");
                break;
            }
        }
    }

}

void insertBST(node **rootPtr, element x)
{
    node *ptr, *parent;
    
    int found = 0;
    
    found = searchParent(*rootPtr, x.id, &parent);
    
    if (found == 1)
    {
        printf("이미 그 자료가 있습니다!\n");
    }
    
    else
    { /* x.key is not in the tree */
        ptr = (node *)malloc(sizeof(node));
        
        ptr->data = x;
        ptr->leftChild = ptr->rightChild = NULL;
        
        if (*rootPtr == NULL)
        {
           *rootPtr = ptr;
        }
        
        else
        { /* insert ptr as a child of the parent */
                if (x.id < parent->data.id)
                    parent->leftChild = ptr;
                
                else parent->rightChild = ptr;
        }
    }
}

int deleteBST(node **rootPtr, int key)
{
    node *root, *parentSmall, *searchSmall;
    root = *rootPtr;
    
        if (searchParentTargetToDelete(root, key) == 0)
        {
            printf("자료가 없어!\n");
            return(0);
            // NOT FOUND
        }
    
    
        /* case 1. Deletion of a leaf node. */
        if ((searchPtr->leftChild == NULL) && (searchPtr->rightChild == NULL))
        {
            if(searchPtr->data.id == (*rootPtr)->data.id )
            {
                *rootPtr = NULL;
                return(1);
            }
                
            if(searchPtr == parentPtr->rightChild)
            {
                parentPtr->rightChild = NULL;
                free(searchPtr);
                return(1);
            }
            
            else
            {
                parentPtr->leftChild = NULL;
                free(searchPtr);
                return(1);
            }
            
        }
    
        /* Case 2. Deletion of a nonleaf node that has only one child. */
        if ((searchPtr->leftChild == NULL) && (searchPtr->rightChild != NULL))
        {
            if(parentPtr == NULL)
            {
                *rootPtr = (searchPtr->rightChild);
                free(searchPtr);
                return(1);
            }
            
            if(parentPtr->rightChild == searchPtr)
            {
                parentPtr->rightChild = searchPtr->rightChild;
                free(searchPtr);
                return(1);
            }
            
            if(parentPtr->leftChild == searchPtr)
            {
                parentPtr->leftChild = searchPtr->rightChild;
                free(searchPtr);
                return(1);

            }
        }
    
        if ((searchPtr->leftChild != NULL) && (searchPtr->rightChild == NULL))
        {
            if(parentPtr == NULL)
            {
                *rootPtr = (searchPtr->leftChild);
                free(searchPtr);
                return(1);
            }

            if(parentPtr->rightChild == searchPtr)
            {
                parentPtr->rightChild = searchPtr->leftChild;
                free(searchPtr);
                return(1);
            }
        
            if(parentPtr->leftChild == searchPtr)
            {
                parentPtr->leftChild = searchPtr->leftChild;
                free(searchPtr);
                return(1);
            }
        }

    
    /* Case 3. Deletion of a nonleaf node that has two children. */
        if ((searchPtr->leftChild != NULL) && (searchPtr->rightChild != NULL))
        {
//             find the smallest among the larger than the key 
            searchSmallestAmongLargerNodes(searchPtr, key, &parentSmall, &searchSmall);
            
            if(parentPtr == NULL)
            {
                *rootPtr = (searchPtr->rightChild);
                (searchPtr->rightChild)->leftChild = searchPtr->leftChild;
                free(searchPtr);
                return(1);
            }

            if(parentPtr->rightChild == searchPtr)
            {
                parentPtr->rightChild = searchSmall;
                searchSmall->leftChild = searchPtr->leftChild;
                free(searchPtr);
                return(1);
            }
            
            else
            {
                parentPtr->rightChild = searchSmall;
                searchSmall->leftChild = searchPtr->leftChild;
                free(searchPtr);
                return(1);
            }
        }
        else
            return(0);
}

int searchParent(node *root, int key, node **parentPtr)
{
    int found = 0;
    node *parent = root, *search = root;
    
    while (search != NULL)
    {
        if (key == search->data.id)
        {
            found = 1;
            searchPtr = search;
            break;
        }
        
        else
        {
            parent = search;
            
            if (key < search->data.id)
                search = search->leftChild;
            
            else
                search = search->rightChild;
        }
    }
    *parentPtr = parent;
    searchPtr = search;
    
    return found;
}

//tree에 key k가 없으면 0을 return.
//그렇지 않으면, k를 가진 노드의 주소를 *searchPtr,
//그 노드의 부모 노드의 주소를 *parentPtr에 보관한 후 1을 return한다.
int searchParentTargetToDelete(node *root, int delete_id)
{
    int found = 0;
    node *parent = NULL, *search = root;
    
    while (search != NULL)
    {
        if (delete_id == search->data.id)
        {
            found = 1;
            break;
        }
        
        else
        {
            parent = search;
            
            if (delete_id < search->data.id)
                search = search->leftChild;
            
            else
                search = search->rightChild;
            
        }
    }
    
    parentPtr = parent;
    searchPtr = search;
    
   return found;

}

//삭제할 노드 search의 the smallest one in its right subtree를 small이라 하고 그 노드의 부 모 노드를 parentSmall이라 하자.
void searchSmallestAmongLargerNodes(node *target, int k, node **parentSmallPtr, node **smallPtr)
{
    parentSmallPtr = &target;
    
    while((*parentSmallPtr)->leftChild != NULL)
    {
        (parentSmallPtr) = &(*parentSmallPtr)->leftChild;
    }

}

void cPrint(node* parent)
{
    if(parent->leftChild == NULL)
    {
        printf("왼쪽 자식:없음 \n");
    }
    
    else
    {
        printf("왼쪽 자식: %d %s %s",parent->leftChild->data.id, parent->leftChild->data.name, parent->leftChild->data.address);
    }
    
    if(parent-> rightChild == NULL)
    {
        printf("오른쪽 자식:없음 \n");
    }
    
    else
    {
        printf("오른쪽 자식: %d %s %s",parent->rightChild->data.id, parent->rightChild->data.name, parent->rightChild->data.address);
    }

}

void inorder(node* ptr)
{
    /* inorder tree traversal */
    
    if (ptr != NULL)
    {
        inorder(ptr->leftChild);
        printf("%d %s %s",ptr->data.id, ptr->data.name, ptr->data.address);
        inorder(ptr->rightChild);
    }
}





