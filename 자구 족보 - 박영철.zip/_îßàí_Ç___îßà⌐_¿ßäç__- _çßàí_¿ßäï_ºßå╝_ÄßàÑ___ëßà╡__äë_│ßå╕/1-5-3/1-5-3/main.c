//
//  main.c
//  1-5-3
//
//  Created by 손명빈 on 2017. 8. 29..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>


void func(int bit_arr[], int curidx, int num, int elementNum);

void printfunc(int bit_arr[], int num);


int main(void) {
    int bit_arr[1000];
    
    //test #1
    func(bit_arr, 0, 5, 3);
    
    //test #2
    func(bit_arr, 0, 7, 4);
}


void func(int bit_arr[], int curidx, int num, int elementNum) {
    int i;
    
    if (curidx >= num) {
        if(elementNum <= 0)
            printfunc(bit_arr, num);
        return;
    }
    
    
    else {
        if (elementNum > 0) {
            bit_arr[curidx] = 1;
            func(bit_arr, curidx + 1, num, elementNum - 1);
        }
        
        bit_arr[curidx] = 0;
        func(bit_arr, curidx + 1, num, elementNum);
    }
}

void printfunc(int bit_arr[], int num)
{
    char alphabets[26];
    int i;
    
    //alphabets 에 알파뱃들 넣기(초기화)
    for (i = 0; i < 26; i++)
        alphabets[i] = 'a' + i;
    
    //print
    printf("{");
    
    for (i = 0; i < num; i++) {
        if(bit_arr[i] == 1)
            printf("%c ", alphabets[i]);
    }
    
    printf("}\n");
}
