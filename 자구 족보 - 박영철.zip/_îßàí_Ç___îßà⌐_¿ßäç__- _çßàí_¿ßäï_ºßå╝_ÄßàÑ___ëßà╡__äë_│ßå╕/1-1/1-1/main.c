//
//  main.c
//  1-1
//
//  Created by 손명빈 on 2017. 8. 28..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <math.h>

void print(int b);

int main()
{
    int n;
    int i;
    
    scanf("%d",&n);
        
    for(i=0; i<=n; i++)
    {
        print(i);
    }
}

void print(int b)
{
    int i;
    
    for(i=0; i<b; i++)
    {
        printf("<");

        while(1)
        {

            if(i % 2 == 1)
                printf("true ");
            
            if(i % 2 == 0)
                printf("false ");
            
            i = i/2;
            
            if(i == 0)
                break;
        }
        
        printf(">");

    }
    
}
