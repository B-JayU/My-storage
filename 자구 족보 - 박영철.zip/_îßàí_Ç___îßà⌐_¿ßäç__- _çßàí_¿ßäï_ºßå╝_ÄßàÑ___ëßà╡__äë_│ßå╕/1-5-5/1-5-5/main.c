//
//  main.c
//  1-5-5
//
//  Created by 손명빈 on 2017. 8. 29..
//  Copyright © 2017년 손명빈. All rights reserved.
//


#include <stdio.h>

void printPowerset(int arry[],int i,int n);

int main()
{
    int insert;
    int line[100];

    scanf("%d",&insert);

    printPowerset(line,0,insert);
}

void printPowerset(int line[],int i,int n)
{
    int j;

    if( i == n )
    {
        printf("{");
        for(j=0; j<n; j++)
        {
            if(j+1 != n)
            {
                if (line[j] == 1)
                    printf("%c ",97+j);
            }

            else
            {
                if (line[j] == 1)
                    printf("%c ",97+j);
            }
            
            
        }
        printf("} ");
        return;
    }


    line[i] = 1;
    printPowerset(line,i+1,n);
    
    line[i] = 0;
    printPowerset(line,i+1,n);
}
