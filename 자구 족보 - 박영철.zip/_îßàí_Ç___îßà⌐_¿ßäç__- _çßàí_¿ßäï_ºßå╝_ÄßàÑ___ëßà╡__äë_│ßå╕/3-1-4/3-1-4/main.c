//
//  main.c
//  3-1-4
//
//  Created by 손명빈 on 2017. 9. 5..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>

#define MAX_TERMS 100 /*다항식의 최대 차수 + 1 */
#define COMPARE(x,y) ( ( (x)<(y) ) ? -1 : ( (x)==(y) ) ? 0 : 1)

typedef struct {
    int coef; //계수
    int expon; //지수
} polynomial;

polynomial terms[MAX_TERMS];
int avail=0;
void readpoly(int *start, int *finish);
void printpoly(int start, int finish);
void attach(int coefficient, int exponent);
void attach_mult(int coefficient, int exponents, int startd);
void padd(int starta,int finisha,int startb,int finishb,int *startd,int *finishd);
void pmult(int starta, int finisha, int startb, int finishb,int *startd, int *finishd);

int main() {
    int starta = 0, finisha = 0, startb = 0, finishb = 0, startd, finishd;
    int no;
    
Start: printf("\nChoice the menu\n");
    printf(" *** MENU *** \n");
    printf(" 1) Input \n");
    printf(" 2) Output \n");
    printf(" 3) Add \n");
    printf(" 4) Multiply \n");
    printf(" 5) Exit\n\n");
    
    printf("-> ");
    scanf("%d", &no);
    
    switch(no){
        case 1 : { printf("\nEnter the first polynomial \n");
            readpoly(&starta, &finisha);
            printf("\nEnter the second polynomial \n");
            readpoly(&startb, &finishb);
            goto Start; }
            
        case 2 : { printf("first poly : ");
            printpoly(starta, finisha);
            printf("second poly : ");
            printpoly(startb, finishb);
            goto Start; }
            
        case 3 : { padd(starta, finisha, startb, finishb, &startd, &finishd);
            printf("Add : ");
            printpoly(startd, finishd);
            goto Start; }
            
        case 4 : { pmult(starta, finisha, startb, finishb, &startd, &finishd);
            printpoly(startd, finishd);
            goto Start; }
            
        case 5 : { printf("\n -Thank you- \n\n");
            break; }
    }
}

void readpoly(int *start, int *finish) {
    
    int exp, coeff;
    
    *start = avail;
    
    for( ; ; )
    {
        scanf("%d %d", &coeff, &exp);
        
            terms[avail].expon =exp;
            terms[avail].coef=coeff;
            
            *finish = avail++;
        

    }
}


void padd(int starta,int finisha,int startb,int finishb,int *startd,int *finishd)
{
    /*A(x)와 B(x)를 더하여 D(x)를 생성한다.*/
    *startd=avail;
    
    while (starta<=finisha && startb<=finishb)
        switch (COMPARE (terms[starta].expon, terms[startb].expon)) {
            case -1: /*a의 expon이 b의 expon보다 작은 경우*/
                attach (terms[startb].coef, terms[startb].expon);
                startb++;
                break;
            case 0: /*지수가 같은 경우*/
                coefficient=terms[starta].coef + terms[startb].coef;
                if (coefficient)
                    attach(coefficient, terms[starta].expon);
                starta++;
                startb++;
                break;
            case 1: /*a의 expon이 b의 expon보다 큰 경우*/
                attach (terms[starta].coef, terms[starta].expon);
                starta++;
        }
    /*A(x)의 나머지 항들을 첨가한다.*/
    for( ; starta <= finisha; starta++)
        attach(terms[starta].coef, terms[starta].expon);
    /*B(x)의 나머지 항들을 첨가한다.*/
    for( ; startb <= finishb; startb++)
        attach(terms[startb].coef, terms[startb].expon);
    
    *finishd=avail-1;
}

void pmult(int starta,int finisha,int startb,int finishb,int *startd,int *finishd)
{
    int coefficient, exponents, i, j;
    
    *startd=avail;
    
    for(i=starta; i<=finisha; i++)
        for(j=startb; j<=finishb; j++) {
            coefficient = terms[i].coef * terms[j].coef;
            exponents = terms[i].expon + terms[j].expon;
            
            if(coefficient)
                attach_mult(coefficient, exponents, *startd); }
    
    *finishd=avail-1;
}

void attach(int coefficient, int exponent)
{
    /*새로운 항을 다항식에 첨가한다.*/
    
    terms[avail].coef=coefficient;
    terms[avail].expon=exponent; 
    
    avail++; 
} 

void attach_mult(int coefficient, int exponents, int startd) { 
    
    int i, key;
    
    key = 0; //newterm을 만들기 위한 조건 
    
    for ( i=startd; i<avail; i++) { 
        if (terms[i].expon == exponents) { 
            terms[i].coef += coefficient; 
            key = 1; // 새로운 term을 만드는 것을 skip 한다. 
        } 
    } 
    
    if (key == 0) { 
        terms[avail].coef=coefficient; 
        terms[avail].expon=exponents; 
        avail++; 
    } 
} 

void printpoly(int start, int finish) {/*다항식 출력 */ 
    while(start<=finish) { 
        if(terms[start].expon==0) /*지수가 0일경우 X^을 출력하지 않는다.*/ 
            printf("%d", terms[start].coef); 
        else 
            printf("%dX^", terms[start].coef); 
        
        if(terms[start].expon==0) /*지수가 0일경우 출력하지 않는다.*/ 
            printf(""); 
        else 
            printf("%d", terms[start].expon); 
        
        if(start==finish) 
            printf("\n"); 
        else 
            printf(" + "); 
        
        start++; 
    } 
} 

