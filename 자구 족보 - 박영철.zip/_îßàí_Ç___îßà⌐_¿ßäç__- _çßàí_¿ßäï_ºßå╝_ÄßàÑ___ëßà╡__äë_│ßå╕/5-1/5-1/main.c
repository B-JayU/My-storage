//
//  main.c
//  5-1
//
//  Created by 손명빈 on 2017. 9. 11..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>

#define MAX_STACK_SIZE 100

typedef struct element
{
    int id;
    char name[100];
    char adress[100];
} element;


element stack[MAX_STACK_SIZE];
int top = -1;

element pop();
void push(element item);
void stackFull();
element stackEmpty();

int main()
{
    element temp;
    int cnt=0;
    int i;
    
    while(cnt != 8)
    {
        
        scanf("%d",&temp.id);
        scanf("%s",temp.name);
        fgets(temp.adress,100,stdin);
        
        push(temp);
        
        cnt++;
    }
    
    printf("\n1번문제\n");

    
    for(i=0; i<8; i++)
    {
        printf("<%d,%s,%s>\n",stack[i].id,stack[i].name,stack[i].adress);
    }
    
    printf("\n2번문제\n");
    
    
    for(i=0; i<3; i++)
    {
        printf("<%d,%s,%s>\n", stack[top].id, stack[top].name, stack[top].adress);
        
        pop();
    }
    
    printf("\n3번문제\n");
    
    for(i=0; i<4; i++)
    {
        scanf("%d",&temp.id);
        scanf("%s",temp.name);
        fgets(temp.adress,100,stdin);
        
        push(temp);
    }

    for(i=0; i<9; i++)
    {
        printf("<%d,%s,%s>\n",stack[i].id,stack[i].name,stack[i].adress);
    }
    
    printf("\n4번문제\n");
    
    for(i=0; i<6; i++)
    {
        printf("<%d,%s,%s>\n", stack[top].id, stack[top].name, stack[top].adress);
        
        pop();
    }

    printf("\n5번문제\n");

    for(i=0; i<3; i++)
    {
        printf("<%d,%s,%s>\n",stack[i].id,stack[i].name,stack[i].adress);
    }
    
}

void push(element item)
{

    /* add an item to the global stack */
    
    if (top >= MAX_STACK_SIZE-1)
        stackFull();
    
    stack[++top] = item;
    
//Program 3.1: Add an item to a stack
}

element pop()
{
/* delete and return the top element from the stack */
    
    if (top < 0)
        return stackEmpty();
    
    /*returns an error key*/
    
    return stack[top--];
    
//Program 3.2: Delete from a stack
}

element stackEmpty()
{
    printf("Stack is empty");
    
    element a= {0};
    
    return a;
    
}
    
void stackFull()
{
    fprintf(stderr, "Stack is full, cannot add element");
    
}
