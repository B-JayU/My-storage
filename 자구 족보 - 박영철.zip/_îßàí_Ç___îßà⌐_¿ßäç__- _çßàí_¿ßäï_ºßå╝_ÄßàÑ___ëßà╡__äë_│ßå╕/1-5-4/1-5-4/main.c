//
//  main.c
//  1-5-4
//
//  Created by 손명빈 on 2017. 8. 29..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#define MAX 100

void print(int arr[], int arridx);
void printperm(int arr[], int n, int arridx,int cur_size);
int main(void)
{
    int n;
    int i;
    int arr[MAX];
    
    printf("숫자 입력 : ");
    scanf("%d", &n);
    
    printperm(arr, n, 0, 0);
    
    
}

void print(int arr[], int arridx)
{
    int i;
    
    for (i = 0; i < arridx; i++)
        printf("%c ", arr[i]+'a');
    printf("\n");
}

void printperm(int arr[], int n, int arridx, int cur_size)
{
    
    if (arridx == n)
    {
        print(arr, cur_size);
        return;
    }
    
    printperm(arr, n, arridx + 1,cur_size);
    arr[cur_size] = arridx;
    printperm(arr, n, arridx + 1, cur_size + 1);
}
