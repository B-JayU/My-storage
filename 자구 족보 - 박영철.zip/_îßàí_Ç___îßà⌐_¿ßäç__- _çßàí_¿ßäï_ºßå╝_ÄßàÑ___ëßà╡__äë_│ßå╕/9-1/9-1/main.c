//
//  main.c
//  9-1
//
//  Created by 손명빈 on 2017. 9. 26..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#define MAX_SIZE 8
typedef struct{
    int id;
    char name[20];
    char address[100];
}data;


data bt[MAX_SIZE];
data stack[MAX_SIZE];

int top = 0;
int count = 0;

void insertFunc()
{
    data person;
    
    //    printf("Put element(id, name, address):");
    while(1)
    {
        printf("Put element(id, name, address):");
        
        scanf("%d%*c",&person.id);
        
        if(person.id == 0)
        {
            scanf("%*c");
            break;
        }
        
        scanf("%s",person.name);
        fgets(person.address, 50, stdin);
        count++;
        
        bt[count] = person;
    }
}

int push(data item)
{
    if (top > MAX_SIZE)
        return -1;
    
    stack[++top] = item;
    
    return 0;
}

data pop()
{
    /* delete and return the top element from the stack */
    if (top == 0)
        exit(-1);
    /*returns an error key*/
    
    return stack[top--];
    
}



void iterinorder()
{
    //int top = -1; /* initialize stack */
    int i=1;
    int j=0;
    data tmp;
    int temp[MAX_SIZE] = {0};
    
    while (1) {
        for(;i<=count; i=i*2)
        {
            push(bt[i]);
            
            temp[j++] = i;
        }
        if (top == 0)
            break;/* empty stack */
        
        tmp = pop();
        
        i = temp[j-1];
        j--;
        
        //        printf("<id, name, address> :");
        printf("id : %d, name : %s, address : %s",tmp.id,tmp.name,tmp.address);
        
        i = i*2+1;
    }
}


int main()
{
    char menu;
    
    while(1)
    {
        printf("i(삽입), r(전체 읽기), q(작업종료)를 선택하시오 (종료시 학번 -1): ");
        
        scanf("%c",&menu);
        if(menu == 'q') break;
        
        switch (menu)
        {
            case 'i':
                insertFunc();
                break;
                
            case 'r':
                iterinorder();
                break;
                
            default:
                printf("다시 입력하세요\n");
                break;
        }
    }
}
