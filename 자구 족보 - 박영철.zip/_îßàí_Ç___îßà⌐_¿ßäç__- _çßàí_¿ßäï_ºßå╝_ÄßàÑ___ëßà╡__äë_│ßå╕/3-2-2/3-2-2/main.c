//
//  main.c
//  3-2-2
//
//  Created by 손명빈 on 2017. 9. 5..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int row;
    int col;
    int value;
}mat;

void readMatrix(mat *matrix);
void printMatrix(mat *matrix);
mat* madd (mat *matrix1, mat *matrix2);
mat* mmult (mat *matrix1, mat *matrix2);

int main()
{
    mat mat1[36], mat2[36];
    
    readMatrix(mat1);
    readMatrix(mat2);
    
    printMatrix(mat1);
    printMatrix(mat2);
    
    printMatrix(madd(mat1,mat2));
}

void readMatrix(mat *matrix)
{
    int cnt = 0;
    mat matr[36];
    
    while(1)
    {
        scanf("%d %d %d", &matr[cnt].row, &matr[cnt].col, &matr[cnt].value);
        
        if(cnt == 36)
            break;
        
        cnt++;
    }
    
}

void printMatrix(mat *matrix)
{
    int matr[6][6] = {0};
    int i,j;
    
    for(i=0; i<36; i++)
    {
        matr[matrix[i].row][matrix[i].col] = matrix[i].value;
    }
    
    for(j=0; j<6; j++)
    {
        for(i=0; i<6; i++)
        {
            printf("%d ",matr[j][i]);
        }
    }
    
}

mat* madd (mat *matrix1, mat *matrix2)
{
    int i;
    mat *matrix;
    
    for(i=0; i<36; i++)
    {
        matrix[i].value = matrix1[i].value + matrix2[i].value;
    }
    return matrix;
}

mat* mmult (mat *matrix1, mat *matrix2)
{
    mat* matrix;
    
    int ary1[6][6];
    int ary2[6][6];
    
    
    int i,j;
    
    for(i=0; i<36; i++)
    {
        matrix
    }
    
    return matrix;
}















