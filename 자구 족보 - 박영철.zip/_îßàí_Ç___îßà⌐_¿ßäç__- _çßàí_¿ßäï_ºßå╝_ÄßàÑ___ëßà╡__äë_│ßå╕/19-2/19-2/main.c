//
//  main.c
//  19-2
//
//  Created by 손명빈 on 2017. 11. 20..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#define MAX_SIZE 7

typedef struct
{
    int key;
} element;

typedef struct node *nodepointer;
typedef struct node
{
    element data;
    nodepointer next;
}node;

nodepointer ht[MAX_SIZE];

void make_hash(element k);
void print_hash();
void find_hash(int n);
int find_num(int n);
void delete_hash(int n);

int main(void)
{
    element item;
    int f;
    
    //initial_hash();
    
    printf("숫자를 입력하세요(-1 입력시 종료) : \n");
    
    while(1)
    {
        scanf("%d", &item.key);
        
        if (item.key == -1)
            break;
        make_hash(item);
    }
    print_hash();
    
    while (1)
    {
        printf("탐색할 키를 입력하시오(-1 입력시 종료) : ");
        scanf("%d", &f);
        
        if (f == -1)
            break;
        
        find_hash(f);
    }
    
    while (1)
    {
        printf("삭제할 키를 입력하시오(-1 입력시 종료) : ");
        scanf("%d", &f);
        
        if (f == -1)
            break;
        
        delete_hash(f);
    }
    
    print_hash();
}



void make_hash(element k)
{
    int i = k.key % MAX_SIZE;
    nodepointer temp;
    nodepointer search;
    
    temp = (nodepointer)malloc(sizeof(element));
    
    temp->data = k;
    temp->next = NULL;
    
    if (ht[i] == NULL)
    {
        ht[i] = temp;
    }
    
    else
    {
        search = ht[i];
        while (search->next != NULL)
            search = search->next;
        search->next = temp;
    }
}

void print_hash()
{
    int i;
    nodepointer search;
    
    
    for (i = 0; i < MAX_SIZE; i++)
    {
        search = ht[i];
        
        printf("ht[%d]: ",i);
        
        while (search != NULL)
        {
            printf("%d ", search->data.key);
            search = search->next;
        }
        printf("\n");
}
    
    printf("\n");
}

void find_hash(int n)
{
    nodepointer search;
    
    int i, count;
    int temp = 0;
    
    for (i = 0; i < MAX_SIZE; i++)
    {
        search = ht[i];
        count = 1;
        
        while (search != NULL)
        {
            if (search->data.key == n)
            {
                printf("%d은 hash table의 %d번째 엔트리의 레코드 %d입니다.\n", n, i, count);
                temp++;
                break;
            }
            count++;
            search = search -> next;
        }
    }
    
    if (temp == 0 && i == 7)
        printf("%d이(가) hash table이 존재하지 않습니다.\n", n);
    
}

int find_num(int n)
{
    nodepointer search;
    int i, r = 0; //없음
    for (i = 0; i < MAX_SIZE; i++)
    {
        search = ht[i];
        while (search != NULL)
        {
            if (search->data.key == n)
            {
                r = 1; //있음
                break;
            }
            search = search->next;
        }
    }
    
    return r;
}

void delete_hash(int n)
{
    int i, result;
    nodepointer search;
    nodepointer prev;
    nodepointer temp;
    result = find_num(n);
    
    if (result == 0)
        printf("%d이 hash table에 존재하지 않습니다.\n", n);
    
    else
    {
        find_hash(n);
        printf("삭제합니다.\n");
        
        for (i = 0; i < MAX_SIZE; i++)
        {
            
            search = ht[i];
            prev = search;
            while (search != NULL)
            {
                if (search->data.key == n)
                {
                    if (search->next == NULL) ht[i] = NULL;
                    temp = search->next;
                    prev->next = temp;
                    break;
                    
                }
                prev = search;
                search = search->next;
            }
        }
    }
}
