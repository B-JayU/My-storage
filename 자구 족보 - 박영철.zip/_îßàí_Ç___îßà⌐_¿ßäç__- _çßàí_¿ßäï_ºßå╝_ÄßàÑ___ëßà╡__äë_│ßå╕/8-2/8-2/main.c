//
//  main.c
//  8-2
//
//  Created by 손명빈 on 2017. 9. 20..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct
{
    int id;
    char name[20], address[50];
}element;

typedef struct node
{
    element data;
    struct node *next;
    struct node *prev;
}node;

typedef struct node *nodePointer;

node *first = NULL;

void delete();
void insert();
void printList();
void find();

int main()
{
    char ch;
    
    
    while(1)
    {
        printf("i(삽입), d(삭제), f(탐색), r(전체 읽기), q(작업종료)를 선택하시오:\n");
        scanf(" %c",&ch);
        
        switch(ch)
        {
            case 'i':
                insert();
                break;
            case 'f':
                find();
                break;
            case 'r':
                printList();
                break;
            case 'd':
                
                delete();
                break;
            case 'q':
                return 0;
        }
    }
    return 0;
}

void printList()
{
    node *p;
    p=first;
    while(p->next)
    {
        printf("%d %s %s",p->next->data.id,p->next->data.name,p->next->data.address);
        p=p->next;
    }
}


void insert()
{
    int cnt = 0;
    printf("입력->id ,name ,address:\n");
    
    node* p = NULL;
    node* q = NULL;
    
    while (1)
    {
        node *temp;
        
        temp=(node*)malloc(sizeof(node));
        
        scanf("%d %s", &temp->data.id, temp->data.name);
        
        if (temp->data.id == -1)
        {
            break;
        }
        
        fgets(temp->data.address,100,stdin);
        
        p = first;
        q = first;
        
        p = temp;
        
        if(first==NULL)
            first = temp;
        else
        {
            
        while(1)
        {
            if(p->data.id > temp->data.id)
                break;
            
            q=p;
            
            if(p->next == NULL)
                break;
            
            p = p->next;
            
        }
        
        if(p == first)
        {
            first ->prev = temp;
            temp->next = first;
            first = temp;
        }
        
        else
        {
            p->prev = temp;
            temp->next = p;
            q->next = temp;
            temp->prev = q;
        }
        }
    }
}


void delete()
{
    int num;
    
    node *p, *del;
    
    printf("삭제할 자료의 학번을 입력하시오:\n");
    
    scanf("%d",&num);
    
    p=first;
    
    while(p->next)
    {
        if(p->next->data.id==num)
        {
            printf("삭제 : %d %s %s",p->next->data.id,p->next->data.name,p->next->data.address);
            
            del=p->next;
            p->next=p->next->next;
            (p->next->next)->prev = p;
            
            free(del);
            
            return;
        }
        p=p->next;
    }
    printf("삭제할 학번%d가 존재하지 않음.\n",num);
}


void find()
{
    int num;
    
    node *p;
    
    printf("탐색할 자료의 학번을 입력하시오:\n");
    
    scanf("%d",&num);
    
    p=first;
    
    while(p->next)
    {
        if(p->next->data.id==num)
        {
            printf("%d %s %s",p->next->data.id,p->next->data.name,p->next->data.address);
            
            return;
        }
        p=p->next;
    }
    printf("탐색할 학번%d가 존재하지 않음.\n",num);
}



