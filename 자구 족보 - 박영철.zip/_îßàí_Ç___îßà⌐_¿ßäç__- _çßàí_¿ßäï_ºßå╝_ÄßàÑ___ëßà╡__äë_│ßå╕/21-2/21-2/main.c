//
//  main.c
//  21-2
//
//  Created by 손명빈 on 2017. 11. 28..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef struct{
    int a;
    int b;
}bucket;

typedef struct{
    int ld;
    bucket* bucket_ptr;
}ht;

int get_mask(int gd);
int get_index(int key, int gd);
void bucketInitial(int i);
void renitial();
void initial();
int checkBucket(int ind);
int returnKey();
void rearay(int i, int ind);
void makeHash();
void minusGd(int i, int ind, int sibling);
void delete();
void printbin(int fish);
void print();
void changeToalpha(int temp);

int gd = 2;
ht * h;
int size = 4;

int main(void)
{
    int i;
    
    printf("Insert 6 num\n");
    initial();
    for(i=0; i<6;i++)
    {
        makeHash();
    }
    print();//1번
    
    for(i=0;i<3;i++)
    {
        printf("Insert 1 num\n");

        makeHash();
        printf("gd = %d\n",gd);
        print();//C5,C1,A4
    }
    
    for(i=0;i<3;i++)
    {
        printf("Delete 1 num\n");

        delete();
        printf("gd = %d\n",gd);
        print();
    }
}

int get_mask(int gd)
{
    int mask = 0x01;
    int count;
    for (count = 1; count < gd; count++) mask = (mask << 1) + 0x01;
    return mask;
}

int get_index(int key, int gd)
{
    int index, mask;
    mask = get_mask(gd);
    index = key & mask;
    return index;
}

void bucketInitial(int i)
{
    
    h[i].bucket_ptr = (bucket*)malloc(sizeof(bucket));
    h[i].bucket_ptr->a = -1;
    h[i].bucket_ptr->b = -1;
}

void renitial()
{
    int i;
    
    h = (ht*)realloc(h, sizeof(ht)*size);
    
    for(i=size/2;i<size;i++)
    {
        h[i].ld = 2;
        h[i].bucket_ptr = h[i-(size/2)].bucket_ptr;
    }
}

void initial()
{
    int i;
    
    h = (ht*)malloc(sizeof(ht)*size);
    for(i=0;i<size;i++){
        h[i].ld = 2;
        bucketInitial(i);
        
    }
}
int checkBucket(int ind)
{
    if(h[ind].bucket_ptr->a == -1 || h[ind].bucket_ptr->b == -1) return 0;
    return 1;
}

int returnKey()
{
    char in[2];
    int key;
    
    scanf("%c%c%*c",&in[0],&in[1]);
    
    key = in[0] - 'A' + 4;
    key = key<<3;
    key = key + atoi(&in[1]);
    
    return key;
}

void rearay(int i, int ind)
{
    
    int temp_idx, a,b,a_idx,b_idx;
    bucket * newbucket;
    
    h[ind].ld++;
    
    temp_idx = get_index(i, gd-1);
    
    if(h[temp_idx].ld < gd)
    {
        h[temp_idx].ld++;
    }
    
    //버켓에 담겨있던 숫자들을 변수에 저장하고 버켓은 초기화 한다
    a = h[temp_idx].bucket_ptr->a;
    b = h[temp_idx].bucket_ptr->b;
    
    h[temp_idx].bucket_ptr->a = -1;
    h[temp_idx].bucket_ptr->b = -1;
    
    a_idx = get_index(a, h[ind].ld);
    b_idx = get_index(b, h[ind].ld);
    
    newbucket = (bucket*)malloc(sizeof(bucket));
    
    newbucket->a = -1;
    newbucket->b = -1;
    
    
    if(a_idx != b_idx)
    {
        if(a_idx == ind)
        {
            newbucket->a = b;
            
            h[b_idx].bucket_ptr = newbucket;
            
            h[b_idx].ld = h[ind].ld;
            
            h[a_idx].bucket_ptr->a = a;
            
            h[ind].bucket_ptr->b = i;
        }
        
        else
        {
            newbucket->a = a;
            
            h[a_idx].bucket_ptr = newbucket;
            h[a_idx].ld++;
            
            h[b_idx].bucket_ptr->a = b;
            
            h[ind].bucket_ptr->b = i;
        }
        
    }
    
    else
    {
        
        newbucket->a = i;
        h[ind].bucket_ptr = newbucket;
        h[a_idx].bucket_ptr->a = a;
        h[b_idx].bucket_ptr->b = b;
    }
    
}



void makeHash()
{
    
    int i,ind,a,b;
    int c1,c2;
    int a_idx,b_idx,temp_idx;
    
    bucket * newbucket;
    
    i = returnKey();
    ind = get_index(i, gd);
    
    if(checkBucket(ind) == 0)
    {//맨처음저장
        if(h[ind].bucket_ptr->a == -1)
            h[ind].bucket_ptr->a = i;
        
        else h[ind].bucket_ptr->b = i;
    }
    else
    {
        if(gd < 3){//두번째 입력 gd=4
            gd++;
            size *= 2;
            
            renitial();
            
            ind = get_index(i, gd);
            
            bucketInitial(ind);
            
            if(h[ind].bucket_ptr->a == -1)
                rearay(i,ind);
        }
        
        else
        {
            
            if(gd == h[ind].ld){//gd = 4
                gd++;
                size *= 2;
                renitial();
                ind = get_index(i, gd);
                
                rearay(i,ind);
            }
            
            else
            {//gd > ld
                h[ind].ld++;
                a = h[ind].bucket_ptr->a;
                b = h[ind].bucket_ptr->b;
                
                ind = get_index(i, h[ind].ld);
                a_idx = get_index(a, h[ind].ld);
                b_idx = get_index(b, h[ind].ld);
                
                temp_idx = get_index(i, h[ind].ld-1);
                
                c1 = ind+size/2;
                c2 = a_idx+size/2;
                
                h[temp_idx].ld++;
                h[c1].ld++;
                h[c2].ld++;
                
                if(c1 == c2)
                {
                    
                    
                    h[c1].ld++;
                }
                
                else
                {
                    
                    
                    h[c1].ld++;
                    h[c2].ld++;
                }
                
                a_idx = get_index(a, h[ind].ld);
                b_idx = get_index(b, h[ind].ld);
                
                ind = get_index(i, h[ind].ld);
                
                h[a_idx].bucket_ptr->a = a;
                h[b_idx].bucket_ptr->b = b;
                
                newbucket = (bucket*)malloc(sizeof(bucket));
                
                newbucket->a = i;
                newbucket->b = -1;
                
                h[ind].bucket_ptr = newbucket;
                
                h[c1].bucket_ptr = h[ind].bucket_ptr;
                h[c2].bucket_ptr = h[a_idx].bucket_ptr;
                
            }
        }
    }
}
void minusGd(int i, int ind, int sibling)
{
    int temp_idx,r,check=0;
    int parent;
    
    temp_idx = ind;
    
    if(h[ind].bucket_ptr->a == i)
    {
        if(ind > size/2){
            h[ind].bucket_ptr->a = -1;
            h[ind].ld--;
            gd--;
        }
        
        else
        {
            if(h[ind].ld > 2)
            {
                parent = ind - size/gd;
                
                h[ind].ld--;
                h[sibling].ld--;
                h[ind].bucket_ptr = h[parent].bucket_ptr;
                h[sibling].bucket_ptr = h[parent].bucket_ptr;
            }
            
        }
    }
    else h[ind].bucket_ptr->b = -1;
    
    for(r = 0;r<size/2;r++)
    {
        if(h[r].ld >= gd) check++;
    }
    if(check == 0) gd--;
    
    
}
void delete()
{
    int i,ind;
    int sibling;
    
    i = returnKey();
    ind = get_index(i, gd);
    
    if(h[ind].ld == 2){
        if(h[ind].bucket_ptr->a == i) h[ind].bucket_ptr->a = -1;
        else h[ind].bucket_ptr->b = -1;
    }
    
    else
    {
        if(ind > size/2)
        {
            sibling = ind-size/2;
            minusGd(i,ind,sibling);
        }
        
        else
        {
            sibling = ind+size/2;
            minusGd(i,ind,sibling);
        }
    }
}

void printbin(int fish)
{
    int i;
    
    for (i=gd-1; i >= 0; --i)
    {
        printf("%d", (fish >> i) & 1);
    }
}

void print()
{
    
    for(int i=0;i<pow(2,gd);i++)
    {
        if(h[i].bucket_ptr != NULL)
        {
            printf("entry : ");

            printbin(i);
            
            printf(" | local depth: ");

            printf("%d |",h[i].ld);
            
            printf(" bucket :");
            
            changeToalpha(h[i].bucket_ptr->a);

            changeToalpha(h[i].bucket_ptr->b);
            
            printf("\n");

//          printf(" %d %d\n",h[i].bucket_ptr->a,h[i].bucket_ptr->b);
        }
    }
}

void changeToalpha(int temp)
{
    if(temp >= 48)
    {
        printf("C%d ",temp-48);
    }
    
    else if(temp >= 40)
    {
        printf("B%d ",temp-40);
        
    }
    
    else if(temp >= 32)
    {
        printf("A%d ",temp-32);
    }
    
    else
    {
        printf("-1 ");
    }
}










