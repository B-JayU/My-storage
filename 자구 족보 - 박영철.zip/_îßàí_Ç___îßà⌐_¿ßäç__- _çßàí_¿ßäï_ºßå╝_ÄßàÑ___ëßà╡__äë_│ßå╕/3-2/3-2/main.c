//
//  main.c
//  3-2
//
//  Created by 손명빈 on 2017. 9. 5..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>

typedef struct
{
    int row;
    int col;
    int value;
}ent;

ent* readMatrix();
void printMatrix(ent* matrix);

int main()
{
    ent* mat1 = {0};
    ent* mat2 = {0};
    
    mat1 = readMatrix();
    mat2 = readMatrix();
    
    printMatrix(mat1);
    printMatrix(mat2);
    
}

ent* readMatrix()
{
    ent* mat = {0};
    int cnt = 0;
    
    mat = (ent*)malloc(sizeof(ent)*100);
    
    while(1)
    {
        scanf("%d %d %d", &mat[cnt].row, &mat[cnt].col, &mat[cnt].value);
        
        if (mat[cnt].value == 0)
            break;
        
        cnt++;
    }
    
    return mat;

}

void printMatrix(ent* matrix)
{
    int i,j;
    int row_max=0, col_max=0;
    
    for(i=0; i<100; i++)
    {
        if(row_max < matrix[i].row)
            row_max = matrix[i].row;
    }
    
    for(i=0; i<100; i++)
    {
        if(col_max < matrix[i].col)
            col_max = matrix[i].col;
    }
    
    for(i=0; i<col_max; i++)
    {
        if(matrix[i].col == i)
        {
            for(j=0; j<row_max; j++)
            {
                if(matrix[i].row == j)
                    printf("%d ",matrix[i].value);
                
                else
                    printf("0 ");
            }
            printf("\n");
        }
    }
    
    
}

















