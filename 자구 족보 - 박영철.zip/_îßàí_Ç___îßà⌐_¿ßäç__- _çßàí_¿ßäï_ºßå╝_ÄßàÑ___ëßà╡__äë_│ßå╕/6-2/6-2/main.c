//
//  main.c
//  6-2
//
//  Created by 손명빈 on 2017. 9. 13..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>

#define MAX_STACK_SIZE 100 /* maximum stack size */
#define MAX_EXPR_SIZE 100 /* max size of expression */

static int isp[] = { 0, 19, 12, 12, 13, 13, 13, 0 };
static int icp[] = { 20, 19, 12, 12, 13, 13, 13, 0 };

typedef enum precedence
{ lparen, rparen, plus,minus, times1, divide, mod, eos, operand } precedence;

void push(precedence item);
void postfix(void);
void stackFull();
precedence pop();
precedence stackEmpty();
precedence getToken(char *tokenChar_ptr, int *tokenIndex_ptr);
precedence stack[MAX_STACK_SIZE];
printToken(pop());

char expr[MAX_EXPR_SIZE]; /* global input string (a postfix expression)*/

int stack_top = 0;

int eval(void) {
    /* evaluate a postfix expression, expr, maintained as a global variable. '\0' is the end of the expression. The stack and top of the stack are global variables. getToken is used to return the token type and the character symbol. Operands are assumed to be single character digits */
    precedence tokenType;
    char tokenChar;
    int opdl, opd2;
    int tokenIndex = 0; /* counter for the expression string */
    while (1)
    {
        tokenType= getToken(&tokenChar, &tokenIndex);
        if (tokenType == eos)
            break;
        
        if (tokenType == operand)
            push(tokenChar - '0');
        else {
            /* pop two operands, perform operation, and push result to the stack */
            opd2 = pop();
            opdl = pop();
            switch(tokenType) {
                case plus:
                    push(opdl+opd2);
                    break;
                case minus:
                    push(opdl-opd2);
                    break;
                case times1:
                    push(opdl*opd2);
                    break;
                case divide:
                    push(opdl/opd2);
                    break;
                case mod:
                    push(opdl%opd2);
            }
        }
    }
    return pop(); }

void push(precedence item)
{
    
    /* add an item to the global stack */
    
    if (stack_top >= MAX_STACK_SIZE-1)
        stackFull();
    
    stack[++stack_top] = item;
    
    //Program 3.1: Add an item to a stack
}

precedence getToken(char *tokenChar_ptr, int *tokenIndex_ptr)
{
//    get the next token, symbol is the character representation, which is returned, the token is represented by its enumerated value, which is returned in the function name
    
     *tokenChar_ptr= expr[(*tokenIndex_ptr)++];
     switch (*tokenChar_ptr) {
     case '(' : return lparen;
     case ')' : return rparen;
     case '+' : return plus;
     case '-' : return minus;
     case '/' : return divide;
     case '*' : return times1;
     case '%' : return mod;
     case ' ' : return eos;
     default : return operand;
     }
}

void postfix(void)
{/* output the postfix of the expression.
  The expression string, the stack, and top are global */ char tokenChar;
    precedence tokenType;
    int tokenIndex = 0;
    stack_top = 0; stack[0] = eos; while(1) {
        tokenType= getToken(&tokenChar, &tokenIndex); if (tokenType == eos) break;
        if (tokenType == operand) printf("%c", tokenChar); else if (tokenType == rparen) {
            /* unstack tokens until left parenthesis */
            while (stack[stack_top] != lparen)
            {
                printToken(pop());
                pop(); /* discard the left parenthesis */
            }
        }
        else
        {
            /* remove and print symbols whose isp is greater than or equal to the current token's icp */
            while(isp[stack[stack_top]] >= icp[tokenType])
                printToken(pop());
            push(tokenType);
        } }
    while ((tokenType= pop()) != eos)
        printToken(tokenType);
    printf("\n");
}

precedence pop()
{
    /* delete and return the top element from the stack */
    
    if (stack_top < 0)
        return stackEmpty();
    
    /*returns an error key*/
    
    return stack[stack_top--];
    
    //Program 3.2: Delete from a stack
}

precedence stackEmpty()
{
    printf("Stack is empty");
    
    precedence a= {0};
    
    return a;
    
}

void stackFull()
{
    fprintf(stderr, "Stack is full, cannot add element");
    
}

printToken()
{
    
}


