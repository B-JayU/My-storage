//
//  main.c
//  12-1
//
//  Created by 손명빈 on 2017. 10. 23..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#define MAX_INT 100

void print12(int ary[12]);
void print13(int ary[13]);
void setbtree(int find_num);
int selectNext(int run_num, int num);
int selectWinner(int rightChild, int leftChild);

int run0[13], run1[13], run2[13], run3[13], run4[13], run5[12], run6[12], run7[12];
int result[200];
int btree[16] = {0};

int main()
{
    int i = 0;
    
    FILE *f;
        
    f = fopen("txt.txt","r");
    
    while(!feof(f))
    {
        fscanf(f,"%d",&run0[i]);
        fscanf(f,"%d",&run1[i]);
        fscanf(f,"%d",&run2[i]);
        fscanf(f,"%d",&run3[i]);
        fscanf(f,"%d",&run4[i]);
        fscanf(f,"%d",&run5[i]);
        fscanf(f,"%d",&run6[i]);
        fscanf(f,"%d",&run7[i]);
        
        i++;
    }
    
    printf("run0 : ");
    print13(run0);
    
    printf("run1 : ");
    print13(run1);
    
    printf("run2 : ");
    print13(run2);

    printf("run3 : ");
    print13(run3);

    printf("run4 : ");
    print13(run4);

    printf("run5 : ");
    print12(run5);

    printf("run6 : ");
    print12(run6);

    printf("run7 : ");
    print12(run7);
    
    printf("\n");
    
    btree[8] = run0[0];
    btree[9] = run1[0];
    btree[10] = run2[0];
    btree[11] = run3[0];
    btree[12] = run4[0];
    btree[13] = run5[0];
    btree[14] = run6[0];
    btree[15] = run7[0];

    
    for(i=0; i<=100; i++)
    {
        btree[4] = selectWinner(btree[9], btree[8]);
        btree[5] = selectWinner(btree[11], btree[10]);
        btree[6] = selectWinner(btree[13], btree[12]);
        btree[7] = selectWinner(btree[15], btree[14]);
        
        btree[2] = selectWinner(btree[5], btree[4]);
        btree[3] = selectWinner(btree[7], btree[6]);
        
        btree[1] = selectWinner(btree[3], btree[2]);
        
        result[i] = btree[1];
        
        setbtree(btree[1]);
    
    }
    
    for(i=0; i<=100; i++)
        printf("%d ",result[i]);
}

void print12(int ary[12])
{
    int i;
    for(i=0; i<12; i++)
    {
        printf("%d ", ary[i]);
    }
    
    printf("\n");
}

void print13(int ary[13])
{
    int i;
    for(i=0; i<13; i++)
    {
        printf("%d ",ary[i]);
    }
    
    printf("\n");

}

void setbtree(int find_num)
{
    int i;
    int select;
    
    for(i=8; i<16; i++)
    {
        if(btree[i] == find_num)
        {
            select = i - 8;
            break;
        }
    }
    
    btree[i] = selectNext(select,find_num);
    
}

int selectNext(int run_num, int num)
{
    int nextnum = 0;
    int i;
    
    
        if(run_num == 0)
        {
            for(i=0; i<13; i++)
            {
                if(num == run0[i])
                {
                    if(i != 12)
                    {
                        nextnum = run0[i+1];
                        break;
                    }
                    
                    else
                    {
                        nextnum = MAX_INT;
                    }
                }
            }
        }
            
    if(run_num == 1)
        {
            for(i=0; i<13; i++)
            {
                if(num == run1[i])
                {
                    if(i != 12)
                    {
                        nextnum = run1[i+1];
                        break;
                    }
                    
                    else
                    {
                        nextnum = MAX_INT;
                    }
                }
            }

        }
            
    if(run_num == 2)
        {
            for(i=0; i<13; i++)
            {
                if(num == run2[i])
                {
                    if(i != 12)
                    {
                        nextnum = run2[i+1];
                        break;
                    }
                    
                    else
                    {
                        nextnum = MAX_INT;
                    }
                }
            }

        }
            
    if(run_num == 3)
        {
            for(i=0; i<13; i++)
            {
                if(num == run3[i])
                {
                    if(i != 12)
                    {
                        nextnum = run3[i+1];
                        break;
                    }
                    
                    else
                    {
                        nextnum = MAX_INT;
                    }
                }
            }

        }
            
    if(run_num == 4)
        {
            for(i=0; i<13; i++)
            {
                if(num == run4[i])
                {
                    if(i != 12)
                    {
                        nextnum = run4[i+1];
                        break;
                    }
                    
                    else
                    {
                        nextnum = MAX_INT;
                    }
                }
            }

        }
            
    if(run_num == 5)
        {
            for(i=0; i<12; i++)
            {
                if(num == run5[i])
                {
                    if(i != 11)
                    {
                        nextnum = run5[i+1];
                        break;
                    }
                    
                    else
                    {
                        nextnum = MAX_INT;
                    }
                }
            }

        }
            
    if(run_num == 6)
        {
            for(i=0; i<12; i++)
            {
                if(num == run6[i])
                {
                    if(i != 11)
                    {
                        nextnum = run6[i+1];
                        break;
                    }
                    
                    else
                    {
                        nextnum = MAX_INT;
                    }
                }
            }

        }
            
    if(run_num == 7)
        {
            for(i=0; i<12; i++)
            {
                if(num == run7[i])
                {
                    if(i != 11)
                    {
                        nextnum = run7[i+1];
                        break;
                    }
                    
                    else
                    {
                        nextnum = MAX_INT;
                    }
                }
            }

        }
    
    
    return nextnum;
}

int selectWinner(int rightChild, int leftChild)
{
    int parent;
    
    if(rightChild < leftChild)
        parent = rightChild;
    
    else
        parent = leftChild;
    
    return parent;
}








