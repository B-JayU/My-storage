//
//  main.c
//  1-5
//
//  Created by 손명빈 on 2017. 8. 28..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <math.h>

void printPowerSet(char *set, int set_size)
{

    unsigned int pow_set_size = pow(2, set_size);
    int counter, j;
    
    for(counter = 0; counter < pow_set_size; counter++)
    {
        for(j = 0; j < set_size; j++)
        {
            if(counter & (1<<j))
                printf("%c", set[j]);
        }
        printf("\n");
    }
}

int main()
{
    int set[100] = {};
    int num = 0;
    int i;
    
    while(1)
    {
        
        scanf("%d", &set[num]);
        
        if(set[num] == 0)
            break;
        
        num++;
        
    }
    
    num--;
    for(i=0; i<num; i++)
        printPowerSet(set, i);
    
    getchar();
    return 0;
}
