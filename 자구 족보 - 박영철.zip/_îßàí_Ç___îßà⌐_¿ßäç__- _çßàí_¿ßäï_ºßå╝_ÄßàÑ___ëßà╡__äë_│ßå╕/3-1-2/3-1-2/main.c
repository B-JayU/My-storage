//
//  main.c
//  3-1-2
//
//  Created by 손명빈 on 2017. 9. 4..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>

typedef struct poly
{
    int coe;
    int exp;
}pol;

pol* readPoly();
void printPoly(pol *ary);
pol* padd(pol *ary1, pol *ary2);
pol* pmult(pol* ary1, pol* ary2);


int main()
{
    
    pol *line1 = {0};
    pol *line2 = {0};
    
    
    line1 = readPoly();
    line2 = readPoly();
    
    
    printPoly(padd(line1,line2));
    printf("\n");
    printPoly(pmult(line1,line2));
    
    return 0;
}

void printPoly(pol *ary)
{
    
    int i;
    
    for(i=0; i<100; i++)
    {
        if(ary[i].coe == 0 && ary[i].exp == 0)
            break;
        
        else if (ary[i].exp == 0)
            printf("%d",ary[i].coe);
        
        else
            printf("%dx^%d ",ary[i].coe, ary[i].exp);

        if(ary[i].coe != 0 && ary[i].exp != 0)
            printf("+ ");
    }

}


pol* readPoly()
{
    int i;

    pol *ply;
    
    ply = (pol*)malloc(sizeof(pol)*100);
    
    for(i=0; i<100; i++)
    {
        scanf("%d %d", &ply[i].coe, &ply[i].exp);
        
        if(ply[i].coe == 0 && ply[i].exp == 0)
            break;
    }
    
    return ply;
}

pol* padd(pol* ary1, pol* ary2)
{
    pol* padd = {0};
    int idx1=0, idx2=0, idx3=0;
    
    padd = (pol*)malloc(sizeof(pol)*100);

    
    while(1)
    {
        if(ary1[idx1].exp == ary2[idx2].exp )
        {
            padd[idx3].coe = ary1[idx1].coe + ary2[idx2].coe;
            padd[idx3].exp = ary1[idx1].exp;
            
            idx1++;
            idx2++;
            idx3++;
        }
        
        if(ary1[idx1].exp > ary2[idx2].exp )
        {
            padd[idx3].coe = ary1[idx1].coe;
            padd[idx3].exp = ary1[idx1].exp;
            
            idx1++;
            idx3++;
        }
        
        if(ary1[idx1].exp < ary2[idx2].exp )
        {
            padd[idx3].coe = ary2[idx2].coe;
            padd[idx3].exp = ary2[idx2].exp;
            
            idx2++;
            idx3++;
        }
        
        if(ary1[idx1].coe == 0 && ary2[idx2].coe == 0)
            break;
    }
    
    return padd;
}



//pol* pmult(pol* ary1, pol* ary2)
//{
//    pol* pmult = {0};
//    
//    int i,j,k;
//    int temp=0;
//    
//    pmult = (pol*)malloc(sizeof(pol)*100);
//
//    
//    for(i=0; i<100; i++)
//    {
//        for(k=0; k<100; k++)
//        {
//            temp = ary1[i].exp + ary2[k].exp;
//        
//            for(j=0; j<i; j++)
//            {
//                if(pmult[j].exp == temp)
//                {
//                    pmult[j].coe += ary1[i].coe * ary2[k].coe;
//                }
//                
//                else
//                {
//                    pmult[j].coe = ary1[i].coe * ary2[k].coe;
//                    pmult[j].exp = ary1[i].exp + ary2[k].exp;
//                }
//            }
//        }
//        
//    }
//    return pmult;
//}




//pol* padd(pol *ary1, pol *ary2)
//{
//    int i,j;
//    int cnt = 0;
//    
//    pol *padd = ary1;
//    
//    padd = (pol*)malloc(sizeof(pol)*100);
//    
//    for(i=0; i<100; i++)
//    {
//        for(j=0; j<100; j++)
//        {
//            if(ary1[i].exp == ary2[j].exp)
//            {
//                padd[i].coe = ary1[i].coe + ary2[j].coe;
//                cnt++;
//            }
//            
//            else
//            {
//                padd[i].coe = ary1[i].coe;
//                padd[i].exp = ary1[i].exp;
//                cnt++;
//            }
//            
//        }
//    }
//    return padd;
//}

//pol* padd(pol *ary1, pol *ary2)
//{
//    
//    pol* padd = {0};
//    int i,j,k;
//    
//    padd = (pol*)malloc(sizeof(pol)*100);
//
//    
//    int ar1[100] = {0};
//    int ar2[100] = {0};
//    int add[100] = {0};
//    
//    for(i=0; i<100; i++)
//    {
//        for(j=0; j<100; j++)
//            if(ary1[j].exp == i)
//                ar1[i] = ary1[j].coe;
//    }
//    
//    for(j=0; j<100; j++)
//    {
//        for(i=0; i<100; i++)
//            if(ary2[i].exp == j)
//                ar2[j] = ary2[i].coe;
//    }
//    
//    for(k=0; k<100; k++)
//    {
//        add[k] = ar1[k] + ar2[k];
//    }
//    
//    for(k=0; k<100; k++)
//    {
//        if(add[k] != 0)
//        {
//            padd[k].coe = add[k];
//            padd[k].exp = k;
//        }
//    }
//    
//    return padd;
//}











