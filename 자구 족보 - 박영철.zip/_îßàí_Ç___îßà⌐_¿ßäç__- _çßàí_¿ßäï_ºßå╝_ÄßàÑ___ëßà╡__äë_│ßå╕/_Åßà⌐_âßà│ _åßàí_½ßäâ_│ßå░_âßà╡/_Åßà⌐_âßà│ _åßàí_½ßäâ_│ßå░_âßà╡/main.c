//
//  main.c
//  코드 만듥디
//
//  Created by 손명빈 on 2017. 9. 5..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>

int main()
{
    int i,j;
    for(i=0; i<3; i++)
    {
        for(j=0; j<)
    }
}
