//
//  main.c
//  15-1
//
//  Created by 손명빈 on 2017. 11. 1..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#define FALSE 0
#define TRUE 1
#define MAX_VERTICES 100
#define INF 10000

int cost[MAX_VERTICES][MAX_VERTICES]; // cost is the adjacency matrix
int distance[MAX_VERTICES]; // distance[x] represents the distance of the shortest path from vertex start_vertex to x int parent[MAX_VERTICES];
short found[MAX_VERTICES]; // found[x] is 0 if the shortest path from vertex start_vertex to x has not been found and a 1 if it has
int parent[MAX_VERTICES];
int total_vertex_count = 0;

void update_distance_parent(int new_vertex);
int choose_min_distance_vertex();
void shortestPath(int start_vertex);
void initcost(int ary[MAX_VERTICES][MAX_VERTICES]);

int main()
{
    
    int i;

    for(i=0; i<MAX_VERTICES; i++)
    {
        parent[i] = -1;
    }
    int start_vertex = 0;
    int start,costt,arrive;
    
    printf("그래프를 입력하시오 : \n");
    
    initcost(cost);
    
    while(1)
    {
        scanf("%d %d %d", &start, &arrive, &costt);
        
        if(start == -1 && arrive == -1 && costt == -1)
            break;
        
        if(start > total_vertex_count)
            total_vertex_count = start+1;
        
        if(arrive > total_vertex_count)
            total_vertex_count = arrive+1;
            
        cost[start][arrive] = costt;
        
    }
    
    printf("source를 입력하시오: ");
    scanf("%d",&start_vertex);
    
    shortestPath(start_vertex);
    
}

void shortestPath(int start_vertex)
{
    int i,temp;
    int x, new_vertex;
    
    for (x = 0; x < total_vertex_count; x++)
    {
        found[x] = FALSE;
        distance[x] = cost[start_vertex][x];
        parent[x] = start_vertex;
    }
    
    found[start_vertex] = TRUE;
    distance[start_vertex] = 0;
    
    for (x = 0; x < total_vertex_count; x++)
    {
        new_vertex = choose_min_distance_vertex();
        found[new_vertex] = TRUE;
        
        update_distance_parent(new_vertex);

        if(distance[x] != 0 && distance[x] != 10000)
        {
            printf("length = %d\tpath = %d ", distance[x],x);
            temp = parent[x];

            while(1)
            {
                printf("%d ",temp);
                if(temp == start_vertex)
                    break;
                temp = parent[temp];
                
            }
            printf("\n");
        }
        
    }
    
}

void update_distance_parent(int new_vertex)
{
    int x;
    int new_distance;
    
    for (x = 0; x < total_vertex_count; x++)
    {
        if (!found[x])
        {
            new_distance = distance[new_vertex] + cost[new_vertex][x];
            
            if (new_distance < distance[x])
            {
                distance[x] = new_distance;
                parent[x] = new_vertex;
            }
        }
    }
}

int choose_min_distance_vertex()
{
    /* find the smallest distance not yet checked */
    int x, min, minpos;
    min = 10000;
    minpos = -1;
    
    for (x = 0; x < total_vertex_count; x++)
    {
        if (!found[x] && distance[x] < min)
        {
            min= distance[x];
            minpos = x;
        }
    }
    return minpos;
}


void initcost(int ary[MAX_VERTICES][MAX_VERTICES])
{
    int i,j;
    
    for(i=0 ;i<MAX_VERTICES; i++)
    {
        for(j=0; j<MAX_VERTICES; j++)
        {
            ary[i][j] = 10000;
        }
    }
}













