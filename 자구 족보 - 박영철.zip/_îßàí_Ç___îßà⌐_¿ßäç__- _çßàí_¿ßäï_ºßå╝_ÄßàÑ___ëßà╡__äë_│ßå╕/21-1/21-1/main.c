//
//  main.c
//  21-1
//
//  Created by 손명빈 on 2017. 11. 27..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef struct data
{
    char alpha;
    int num;
}data;

typedef struct node
{
    data bucket[2];
    struct node *next;
}node;

typedef struct
{
    int ld;
    node *Bucket_addr;
}nodepointer;

int get_mask (int gd);
int get_index(int key, int gd);
void printbin(int fish);
void printht();
void init_ht();
int changeToNum(char alpha, int num);

node *temp_bucket;
int gd = 2;

nodepointer *ht;

int main()
{
    int k,num, changedNum;
    int temp;
    int j;
    char alpha;
    int delete_temp0, delete_temp1;
    
    init_ht();
    
    //첫번째 추가
    
    printf("추가할 자료를 입력하세요(종료 시 D0): \n");
    
    while (1)
    {
        scanf("%c", &alpha);
        scanf("%d", &num);
        
        changedNum = changeToNum(alpha, num);
        
        if(num == 0 && alpha == 'D')
            break;

        if(ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].num == -1)
        {
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].alpha = alpha;
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].num = num;
        }
        
        else
        {
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].alpha = alpha;
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].num = num;
        }
    }
    
    printht();
    
    //두번째 추가
    printf("추가할 자료를 입력하세요(종료 시 -1): \n");
    
    while (1)
    {
        scanf("%c%d",&alpha,&num);
       // scanf("%d ", &num);
        
        changedNum = changeToNum(alpha, num);
        
        if(alpha == '\n')
            continue;
        
        if(num == 0 && alpha == 'D')
            break;

        
        if(ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].num == -1)
        {
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].alpha = alpha;
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].num = num;
        }
        
        if(ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].num == -1)
        {
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].alpha = alpha;
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].num = num;
        }
        
        if(ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].num != -1)
        {
            ht[get_index(changedNum, gd)].ld++;
            
            ht = (nodepointer *)realloc(ht,pow(2,++gd)*sizeof(nodepointer));
            
            temp = pow(2,gd-1);
            
            for (k = 0; k<temp; k++)
            {
                ht[k+temp] = ht[k];
            }
            
            
            temp_bucket = (node*)malloc(sizeof(node));
            temp_bucket->bucket[0].num = -1;
            temp_bucket->bucket[1].num = -1;
            
            ht[get_index(changedNum, gd)].Bucket_addr = temp_bucket;
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].alpha = alpha;
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].num = num;
        }
        
    }
    
    printht();
    
    //세번째 추가
    printf("추가할 자료를 입력하세요(종료 시 -1): \n");
    
    while (1)
    {
        scanf("%c%d",&alpha,&num);
        // scanf("%d ", &num);
        
        changedNum = changeToNum(alpha, num);
        
        if(alpha == '\n')
            continue;
        
        if(num == 0 && alpha == 'D')
            break;
        
        
        if(ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].num == -1)
        {
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].alpha = alpha;
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].num = num;
        }
        
        if(ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].num == -1)
        {
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].alpha = alpha;
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].num = num;
        }
        
        if(ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].num != -1)
        {
            ht[get_index(changedNum, gd)].ld++;
            
            ht = (nodepointer *)realloc(ht,pow(2,++gd)*sizeof(nodepointer));
            
            temp = pow(2,gd-1);
            
            for (k = 0; k<temp; k++)
            {
                ht[k+temp] = ht[k];
            }
            
            
            temp_bucket = (node*)malloc(sizeof(node));
            temp_bucket->bucket[0].num = -1;
            temp_bucket->bucket[1].num = -1;
            
            ht[get_index(changedNum, gd)].Bucket_addr = temp_bucket;
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].alpha = alpha;
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].num = num;
        }
        
    }
    
    printht();
    
    //네번째 추가
    printf("추가할 자료를 입력하세요(종료 시 -1): \n");
    
    while (1)
    {
        scanf("%c%d",&alpha,&num);
        // scanf("%d ", &num);
        
        changedNum = changeToNum(alpha, num);
        
        if(alpha == '\n')
            continue;
        
        if(num == 0 && alpha == 'D')
            break;
        
        
        if(ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].num == -1)
        {
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].alpha = alpha;
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].num = num;
        }
        
        if(ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].num == -1)
        {
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].alpha = alpha;
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].num = num;
        }
        
        if(ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].num != -1)
        {
            ht[get_index(changedNum, gd)].ld++;
            
//            ht = (nodepointer *)realloc(ht,pow(2,++gd)*sizeof(nodepointer));
            
            temp = pow(2,gd);
            
            for (k = 0; k<temp; k++)
            {
                ht[k+temp] = ht[k];
            }
            
            
            temp_bucket = (node*)malloc(sizeof(node));
            
            temp_bucket->bucket[0].num = -1;
            temp_bucket->bucket[1].num = -1;
            
            ht[get_index(changedNum, gd)].Bucket_addr = temp_bucket;
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].alpha = alpha;
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].num = num;
        }
        
    }
    
    printht();
    
    //첫번째 삭제
    printf("삭제할 자료를 입력하세요(종료 시 -1): \n");
    
    while (1)
    {
        scanf("%c%d",&alpha,&num);
        // scanf("%d ", &num);
        
        changedNum = changeToNum(alpha, num);
        
        if(alpha == '\n')
            continue;
        
        if(num == 0 && alpha == 'D')
            break;
        
        delete_temp0 = changeToNum( ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].alpha, ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].num);
        delete_temp1 = changeToNum( ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].alpha, ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].num);
        
        
        if(delete_temp0 == changedNum)
        {
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].num = -1;
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].alpha = '0';
        }
        
        if(delete_temp1 == changedNum)
        {
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].num = -1;
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].alpha = '0';
        }
        
        if (ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].num == -1 && ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].num == -1)
        {
            ht[get_index(changedNum, gd)].Bucket_addr = ht[get_index(changedNum, gd)+(int)pow(2,gd-1)].Bucket_addr;
            ht[get_index(changedNum, gd)].ld--;
            
            ht[get_index(changedNum, gd)+(int)pow(2,gd-1)].ld--;
            
            for (j=0; j<4; j++)
            {
                if (ht[get_index(changedNum, gd)].ld >= gd)
                    break;
            }
            
            if (j == 4)
            {
                gd--;
                
                ht = (nodepointer *)realloc(ht, pow(2,gd)*sizeof(nodepointer));
            }
        }
        
    }
    
    printht();
    
    //두번째 삭제
    printf("삭제할 자료를 입력하세요(종료 시 -1): \n");
    
    while (1)
    {
        scanf("%c%d",&alpha,&num);
        // scanf("%d ", &num);
        
        changedNum = changeToNum(alpha, num);
        
        if(alpha == '\n')
            continue;
        
        if(num == 0 && alpha == 'D')
            break;
        
        delete_temp0 = changeToNum( ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].alpha, ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].num);
        delete_temp1 = changeToNum( ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].alpha, ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].num);
        
        
        if(delete_temp0 == changedNum)
        {
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].num = -1;
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].alpha = '0';
        }
        
        if(delete_temp1 == changedNum)
        {
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].num = -1;
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].alpha = '0';
        }
        
        if (ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].num == -1 && ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].num == -1)
        {
            ht[get_index(changedNum, gd)].Bucket_addr = ht[get_index(changedNum, gd)+(int)pow(2,gd-1)].Bucket_addr;
            ht[get_index(changedNum, gd)].ld--;
            
            ht[get_index(changedNum, gd)+(int)pow(2,gd-1)].ld--;
            
            for (j=0; j<4; j++)
            {
                if (ht[get_index(changedNum, gd)].ld >= gd)
                    break;
            }
            
            if (j == 4)
            {
                gd--;
                
                ht = (nodepointer *)realloc(ht, pow(2,gd)*sizeof(nodepointer));
            }
        }
        
    }
    
    printht();
    

    //세번째 삭제
    printf("삭제할 자료를 입력하세요(종료 시 -1): \n");
    
    while (1)
    {
        scanf("%c%d",&alpha,&num);
        // scanf("%d ", &num);
        
        changedNum = changeToNum(alpha, num);
        
        if(alpha == '\n')
            continue;
        
        if(num == 0 && alpha == 'D')
            break;
        
        delete_temp0 = changeToNum( ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].alpha, ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].num);
        delete_temp1 = changeToNum( ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].alpha, ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].num);
        
        
        if(delete_temp0 == changedNum)
        {
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].num = -1;
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].alpha = '0';
        }
        
        if(delete_temp1 == changedNum)
        {
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].num = -1;
            ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].alpha = '0';
        }
        
        if (ht[get_index(changedNum, gd)].Bucket_addr->bucket[0].num == -1 && ht[get_index(changedNum, gd)].Bucket_addr->bucket[1].num == -1)
        {
            ht[get_index(changedNum, gd)].Bucket_addr = ht[get_index(changedNum, gd)+(int)pow(2,gd-1)].Bucket_addr;
            ht[get_index(changedNum, gd)].ld--;
            
            ht[get_index(changedNum, gd)+(int)pow(2,gd-1)].ld--;
            
            for (j=0; j<4; j++)
            {
                if (ht[get_index(changedNum, gd)].ld >= gd)
                    break;
            }
            
            if (j == 4)
            {
                gd--;
                
                ht = (nodepointer *)realloc(ht, pow(2,gd)*sizeof(nodepointer));
            }
        }
        
    }
    
    printht();
    

}

int get_mask (int gd)
{
    int mask = 0x01;
    int count;
    
    for(count=1; count<gd; count++)
        mask = (mask << 1) + 0x01;
    
    return mask;
}

int get_index(int key, int gd)
{
    int index, mask;
    mask = get_mask(gd);
    index = key & mask;
    return index;
}

void printht ()
{
    int i;
    int cnt = 0;
    int cnt2 = 0;
    
    for (i =0; i<pow(2,gd); i++)
    {
        cnt2 = 0;
        
        while (1)
        {
            if (cnt2 == 1)
                break;
            
            else
            {
                cnt2++;

                printf("entry : ");
                //                printbin(ht[i].Bucket_addr->data[0]);
                printbin(cnt++);
                printf(" | local depth: ");
                printf("%d |",ht[i].ld);
                
                printf(" bucket : ");
                
                if(ht[i].Bucket_addr->bucket[0].alpha != '0')
                    printf("%c", ht[i].Bucket_addr->bucket[0].alpha);
                printf("%d ", ht[i].Bucket_addr->bucket[0].num);
                
                if(ht[i].Bucket_addr->bucket[1].alpha != '0')
                    printf("%c", ht[i].Bucket_addr->bucket[1].alpha);
                printf("%d ", ht[i].Bucket_addr->bucket[1].num);
            
                //
            }
            printf("\n");
        }
    }
}

void init_ht()
{
    int i;
    
    ht = (nodepointer *) malloc(4*sizeof(nodepointer));
    
    for (i=0; i<4; i++)
    {
        temp_bucket = (node*)malloc(sizeof(node));
        
        temp_bucket->bucket[0].alpha = '0';
        temp_bucket->bucket[0].num = -1;
        temp_bucket->bucket[1].alpha = '0';
        temp_bucket->bucket[1].num = -1;
        
        ht[i].ld = 2;
        ht[i].Bucket_addr = temp_bucket;
        
    }
    
}


void printbin(int fish)
{
    int i;
    
    for (i=gd-1; i >= 0; --i)
    {
        printf("%d", (fish >> i) & 1);
    }
}

int changeToNum(char alpha, int num)
{
    int result = 0;
    
    //100
    if(alpha == 'A')
    {
        result+=32;
    }
    
    //101
    else if(alpha == 'B')
    {
        result+=40;
    }
    
    //110
    else if(alpha == 'C')
    {
        result+=48;
    }
    
    result+=num;
    
    return result;
}





















