//
//  main.c
//  1-3-3
//
//  Created by 손명빈 on 2017. 8. 29..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>


int main(void){
    
    int i, num;
    int a1=0,a2=0,a3=1;
    
    scanf("%d" , &num) ;
    
    for(i=0; i<num; i++)
    {
        printf("%d " , a1);
        
        a2 = a1+a3;
        
        a1 = a3;
        
        a3 = a2;
        
    }
    printf("\n");
    
    return 0 ;
    
}
