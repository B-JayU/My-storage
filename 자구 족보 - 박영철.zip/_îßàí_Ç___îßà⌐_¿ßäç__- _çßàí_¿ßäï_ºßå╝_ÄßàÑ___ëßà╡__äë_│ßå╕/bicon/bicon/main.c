//
//  main.c
//  bicon
//
//  Created by 손명빈 on 2017. 12. 3..
//  Copyright © 2017년 손명빈. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#define FALSE 0
#define TRUE 1
#define MAX_VERTICES 100
#define MIN2(x, y) ( (x) < (y) ? (x) : (y))
short int dfn[MAX_VERTICES];
short int low[MAX_VERTICES];
int num;

typedef struct node* nodepointer;
typedef struct node
{
    int data;
    nodepointer next;
}node;

void insert(int b, int c);

void init(void);

void dfnlow(int me, int parent);

void bicon(int me, int parent);

void push(int m, int c);

int pop();

int pop2();


short visited[MAX_VERTICES];
nodepointer root, search;
nodepointer adjlist[12] = {0};

int top1 = -1;
int top2 = -1;
int stack1[MAX_VERTICES];
int stack2[MAX_VERTICES];

int main()
{
    int a,b,c;
    int i;
    int max = 0;
    
    while(1)
    {
        scanf("%d %d", &b, &c);
        
        if(a == -1 || b == -1 || c == -1)
            break;
        
        insert(b,c);
        
        if(b > c)
            max = b;
        
        else
            max = c;
        
    }
    
    init();
    bicon(3,-1);
  
    
    printf("vertex : ");
    for(i=0; i<10; i++)
    {
        printf("%d ",i);
    }
    
    printf("\n");
    
    printf("dfn : ");
    for(i=0; i<10; i++)
    {
        printf("%d ",dfn[i]);
    }
    
    printf("\n");
    
    printf("low : ");
    for(i=0; i<10; i++)
    {
        printf("%d ",low[i]);
    }
   
    init();
    while(1)
    {
        scanf("%d %d", &b, &c);
        
        if(a == -1 || b == -1 || c == -1)
            break;
        
        insert(b,c);
        
        if(b > c)
            max = b;
        
        else
            max = c;
        
    }
     bicon(3,-1);
    printf("vertex : ");
    for(i=0; i<10; i++)
    {
        printf("%d ",i);
    }
    
    printf("\n");
    
    printf("dfn : ");
    for(i=0; i<10; i++)
    {
        printf("%d ",dfn[i]);
    }
    
    printf("\n");
    
    printf("low : ");
    for(i=0; i<10; i++)
    {
        printf("%d ",low[i]);
    }
    
  
   
    
    
}

void insert(int b, int c)
{
    nodepointer new;
    nodepointer new_rev;
    
    new = (node*)malloc(sizeof(node));
    new_rev = (node*)malloc(sizeof(node));
    
    new->data = c;
    
    if(adjlist[b] == NULL)
    {
        adjlist[b] = new;
    }
    
    else
    {
        search = adjlist[b];
        
        while(search->next != NULL)
        {
            search = search->next;
        }
        
        search->next = new;
    }
    
    new_rev -> data = b;
    
    if(adjlist[c] == NULL)
    {
        adjlist[c] = new_rev;
    }
    
    else
    {
        search = adjlist[c];
        
        while(search->next != NULL)
        {
            search = search -> next;
        }
        
        search->next = new_rev;
    }
    
}

void init(void)
{
    int i;
    for (i = 0; i < MAX_VERTICES; i++)
    {
        visited[i] = FALSE;
        dfn[i] = low[i] = -1;
    }
    num = 0;
}


void dfnlow(int me, int parent)
{
    /* compute dfn and low while performing a dfs search beginning at vertex me. parent is the parent of me (if any) */
    nodepointer ptr;
    int child;
    dfn[me] = low[me] = num++;
    for (ptr = adjlist[me]; ptr; ptr = ptr->next)
    {
        child = ptr->data;
        
        if (dfn[child] < 0)
        {/* child is an unvisited vertex */
            dfnlow(child, me);
            low[me] = MIN2(low[me],low[child]);
        }
        
        else if (child != parent) // a back-edge is found
            low[me] = MIN2(low[me],dfn[child]);
    }
}

void bicon(int me, int parent)
{
    /* compute dfn and low, and output the edges of G by their
     biconnected components, v is the parent (if any) of u
     in the resulting spanning tree. It is assumed that all
     entries of dfn[] have been initialized to -1, num is
     initially to 0, and the stack is initially empty */
    nodepointer ptr;
    int child, x, y;
    dfn[me] = low[me] = num++;
    for (ptr = adjlist[me]; ptr; ptr = ptr->next) {
        child = ptr->data;
        if (parent != child && dfn[child] < dfn[me]) {// 이 부분이 교재의 오류
            // either an edge to an unvisited vertex or a back-edge
            push(me, child); /*add edge to stack*/
        }
        if (dfn[child] <0) { /* child has not been visited */
            bicon(child, me);
            low[me] = MIN2(low[me], low[child]);
            if (low[child] >= dfn[me]) {
                printf("New biconnected component: ");
                do { /* delete edge from stack */
                    x = pop();
                    y = pop2();
                    printf(" <%d,%d>", x, y);
                } while (!((x == me) && (y == child)));
                printf("\n");
            }
        }
        else if (child != parent) // a back-edge is found
            low[me] = MIN2(low[me], dfn[child]);
    }
}

void push(int m, int c)
{
    if (top1 >= MAX_VERTICES)
        printf("stack is full\n");
    
    stack1[++top1] = m;
    stack2[++top2] = c;
}

int pop()
{
    
    if (top1 < 0)
        printf("stack is empty\n");
    return stack1[top1--];
}

int pop2()
{
    if (top2 < 0)
        printf("stack is empty\n");
    return stack2[top2--];
}



